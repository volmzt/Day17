# DAY17 (Godot 4.3, Android)
Сборка: ZIP в корень репозитория + .github/workflows/build-apk.yml -> Actions соберёт APK (Releases).
Обновления: patch-001.zip, patch-002.zip ... поверх базы; APK подписан одним ключом (signing/day17.keystore).
Цель: починить машину (канистра, предохранитель, аккумулятор) и выбраться по дороге на восток -> дома вдоль дороги.

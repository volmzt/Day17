# DAY17 (Godot 4.3, Android)
Сборка: положить ZIP в корень репозитория + .github/workflows/build-apk.yml -> Actions соберёт APK (Releases).
Обновления: заливайте patch-001.zip, patch-002.zip ... (только изменённые файлы, распаковываются поверх базы),
APK подписывается одним ключом (signing/day17.keystore) и ставится поверх старой версии.
Модель существа: models/creature.glb (ноги и щупальца анимируются шейдером).

extends Node
const WorldS = preload("res://scripts/world.gd")
const SAVE_PATH := "user://day17_save.json"
var layer: CanvasLayer
var quality := 1
var q_btn: Button

func _ready() -> void:
	DisplayServer.screen_set_keep_on(true)
	_menu()

func _menu() -> void:
	layer = CanvasLayer.new()
	add_child(layer)
	var bg := ColorRect.new()
	bg.color = Color(0.03, 0.04, 0.045)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	layer.add_child(bg)
	var cc := CenterContainer.new()
	cc.set_anchors_preset(Control.PRESET_FULL_RECT)
	layer.add_child(cc)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 18)
	cc.add_child(box)
	var title := Label.new()
	title.text = "DAY17"
	title.add_theme_font_size_override("font_size", 90)
	title.add_theme_color_override("font_color", Color(0.65, 0.72, 0.7))
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(title)
	_btn(box, "Новая игра", func(): _start(false))
	var cont := _btn(box, "Продолжить", func(): _start(true))
	cont.disabled = not FileAccess.file_exists(SAVE_PATH)
	q_btn = _btn(box, "Графика: средняя", _cycle_q)
	_btn(box, "Выход", func(): get_tree().quit())
	var rain := AudioStreamPlayer.new()
	rain.stream = preload("res://scripts/synth.gd").noise(3.0, 0.5, 0.4, 0.0, true)
	rain.volume_db = -24.0
	rain.name = "MenuRain"
	add_child(rain)
	rain.play()

func _btn(parent: Node, text: String, cb: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(420, 70)
	b.add_theme_font_size_override("font_size", 30)
	b.pressed.connect(cb)
	parent.add_child(b)
	return b

func _cycle_q() -> void:
	quality = (quality + 1) % 3
	q_btn.text = "Графика: " + ["низкая", "средняя", "высокая"][quality]

func _start(load_game: bool) -> void:
	layer.queue_free()
	get_node("MenuRain").queue_free()
	var w := WorldS.new()
	add_child(w)
	w.start(load_game, quality)

extends Node
const WorldS = preload("res://scripts/world.gd")
const MenuS = preload("res://scripts/menu.gd")
const Settings = preload("res://scripts/settings.gd")
var menu
var world

func _ready() -> void:
	DisplayServer.screen_set_keep_on(true)
	Settings.load_settings()
	Settings.apply(get_viewport())
	_show_main()

func _show_main() -> void:
	menu = MenuS.new()
	menu.mode = "main"
	add_child(menu)
	menu.new_game.connect(func(): _start(false))
	menu.continue_game.connect(func(): _start(true))
	menu.quit_game.connect(func(): get_tree().quit())

func _start(load_game: bool) -> void:
	menu.show_loading()
	await get_tree().process_frame
	await get_tree().process_frame
	menu.queue_free()
	menu = null
	world = WorldS.new()
	add_child(world)
	world.start(load_game)
	world.pause_requested.connect(_on_pause)

func _on_pause() -> void:
	if menu != null:
		return
	get_tree().paused = true
	menu = MenuS.new()
	menu.mode = "pause"
	add_child(menu)
	menu.resume.connect(_resume)
	menu.to_main.connect(_to_main)
	menu.settings_changed.connect(func(): world.apply_live())

func _resume() -> void:
	Settings.save_settings()
	menu.queue_free()
	menu = null
	get_tree().paused = false

func _to_main() -> void:
	get_tree().paused = false
	menu.queue_free()
	world.queue_free()
	world = null
	_show_main()

extends Node
# Загрузчик с самодиагностикой: никаких preload — всё грузится через load() и проверяется.
const SCRIPTS := ["settings", "synth", "builder", "items", "saves", "interactable", "touch_ui", "map_canvas", "inv_ui", "player", "creature", "world", "menu"]
const LOG_PATH := "user://logs/godot.log"
var menu
var world
var failed: Array = []
var settings_s
var menu_s
var world_s
var diag_layer: CanvasLayer
var diag_label: Label
var diag_root: Control
var log_btn: Button
var fallback_layer: CanvasLayer

func _ready() -> void:
	DisplayServer.screen_set_keep_on(true)
	var loaded := {}
	for n in SCRIPTS:
		var s = load("res://scripts/%s.gd" % n)
		if s == null or not s.can_instantiate():
			failed.append(n)
		else:
			loaded[n] = s
	_make_log_button()
	if loaded.has("settings"):
		settings_s = loaded["settings"]
		settings_s.load_settings()
		settings_s.apply(get_viewport())
	menu_s = loaded.get("menu")
	world_s = loaded.get("world")
	if menu_s == null:
		_fallback_menu()
	else:
		_show_main()
	if failed.size() > 0:
		_show_diag()

func _make_log_button() -> void:
	var l := CanvasLayer.new()
	l.layer = 200
	add_child(l)
	log_btn = Button.new()
	log_btn.text = "ЛОГ"
	log_btn.position = Vector2(560, 6)
	log_btn.custom_minimum_size = Vector2(110, 44)
	log_btn.focus_mode = Control.FOCUS_NONE
	log_btn.pressed.connect(_toggle_diag)
	l.add_child(log_btn)

func _log_tail() -> String:
	if not FileAccess.file_exists(LOG_PATH):
		return "(лог-файл не найден: " + LOG_PATH + ")"
	var f := FileAccess.open(LOG_PATH, FileAccess.READ)
	if f == null:
		return "(не удалось открыть лог)"
	var txt := f.get_as_text()
	var lines := txt.split("\n")
	var keep: Array = []
	for ln in lines:
		var u := String(ln)
		if u.contains("ERROR") or u.contains("SCRIPT") or u.contains("Parse") or u.contains("WARNING") or u.contains("at:"):
			var cut := u.substr(0, 170)
			if not keep.has(cut):
				keep.append(cut)
	if keep.size() == 0:
		keep = Array(lines.slice(maxi(0, lines.size() - 25)))
	return "\n".join(keep.slice(maxi(0, keep.size() - 40)))

func _build_diag_text() -> String:
	var t := "ДИАГНОСТИКА DAY17\n"
	if failed.size() > 0:
		t += "НЕ ЗАГРУЗИЛИСЬ СКРИПТЫ: " + ", ".join(failed) + "\n"
	else:
		t += "Все скрипты загружены.\n"
	t += "--- лог ---\n" + _log_tail()
	return t

func _toggle_diag() -> void:
	if diag_layer != null and is_instance_valid(diag_layer):
		diag_layer.queue_free()
		diag_layer = null
	else:
		_show_diag()

func _show_diag() -> void:
	if diag_layer != null and is_instance_valid(diag_layer):
		diag_layer.queue_free()
	diag_layer = CanvasLayer.new()
	diag_layer.layer = 150
	add_child(diag_layer)
	diag_root = Control.new()
	diag_root.mouse_filter = Control.MOUSE_FILTER_STOP
	diag_layer.add_child(diag_root)
	var bg := ColorRect.new()
	bg.color = Color(0, 0, 0, 0.88)
	bg.size = Vector2(1280, 720)
	diag_root.add_child(bg)
	diag_label = Label.new()
	diag_label.text = _build_diag_text()
	diag_label.position = Vector2(16, 56)
	diag_label.size = Vector2(1240, 640)
	diag_label.autowrap_mode = TextServer.AUTOWRAP_ARBITRARY
	diag_label.add_theme_font_size_override("font_size", 13)
	diag_label.add_theme_color_override("font_color", Color(1, 0.85, 0.7))
	diag_root.add_child(diag_label)

func _process(_delta: float) -> void:
	var vs := get_viewport().get_visible_rect().size
	if log_btn != null:
		log_btn.position = Vector2(vs.x * 0.5 - 55.0, 6.0)
	if diag_root != null and is_instance_valid(diag_root) and diag_root.get_child_count() > 1:
		var bgc: ColorRect = diag_root.get_child(0)
		bgc.size = vs
		diag_label.size = Vector2(vs.x - 32.0, vs.y - 64.0)

# --- запасное меню (если основное не загрузилось) ---
func _fallback_menu() -> void:
	fallback_layer = CanvasLayer.new()
	add_child(fallback_layer)
	var box := VBoxContainer.new()
	box.position = Vector2(80, 120)
	fallback_layer.add_child(box)
	var l := Label.new()
	l.text = "DAY17 (запасное меню)"
	l.add_theme_font_size_override("font_size", 40)
	box.add_child(l)
	var b := Button.new()
	b.text = "НОВАЯ ИГРА"
	b.custom_minimum_size = Vector2(380, 70)
	b.pressed.connect(_on_new_game.bind(1))
	box.add_child(b)

func _show_main() -> void:
	menu = menu_s.new()
	menu.mode = "main"
	add_child(menu)
	menu.new_game.connect(_on_new_game)
	menu.continue_game.connect(_on_continue)
	menu.quit_game.connect(_on_quit)

func _on_new_game(slot: int) -> void:
	_start(false, slot)

func _on_continue(slot: int) -> void:
	_start(true, slot)

func _on_quit() -> void:
	get_tree().quit()

func _on_save_to(slot: int) -> void:
	if world != null:
		world.save_to_slot(slot)

func _on_settings_changed() -> void:
	if world != null:
		world.apply_live()

func _start(load_game: bool, slot: int) -> void:
	if world_s == null:
		_show_diag()
		return
	if menu != null:
		menu.show_loading()
	await get_tree().process_frame
	await get_tree().process_frame
	if menu != null:
		menu.queue_free()
		menu = null
	if fallback_layer != null:
		fallback_layer.queue_free()
		fallback_layer = null
	world = world_s.new()
	add_child(world)
	world.start(load_game, slot)
	world.pause_requested.connect(_on_pause)

func _on_pause() -> void:
	if menu != null:
		return
	get_tree().paused = true
	menu = menu_s.new()
	menu.mode = "pause"
	add_child(menu)
	menu.resume.connect(_resume)
	menu.to_main.connect(_to_main)
	menu.settings_changed.connect(_on_settings_changed)
	menu.save_to.connect(_on_save_to)

func _resume() -> void:
	if settings_s != null:
		settings_s.save_settings()
	menu.queue_free()
	menu = null
	get_tree().paused = false

func _to_main() -> void:
	get_tree().paused = false
	menu.queue_free()
	world.queue_free()
	world = null
	_show_main()

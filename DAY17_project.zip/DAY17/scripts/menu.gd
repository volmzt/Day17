extends CanvasLayer
# Собственное меню DAY17: силуэт леса и существа в тумане, без стандартных кнопок Godot.
const Settings = preload("res://scripts/settings.gd")
const Synth = preload("res://scripts/synth.gd")
const Saves = preload("res://scripts/saves.gd")
signal new_game(slot: int)
signal continue_game(slot: int)
signal save_to(slot: int)
signal resume
signal to_main
signal quit_game
signal settings_changed

const PAGES := [
	["ГРАФИКА", [
		["preset", "Пресет", ["Низкие", "Средние", "Высокие", "Свои"]],
		["shadows", "Тени", ["Выкл", "Низкие", "Средние", "Высокие"]],
		["shadow_dist", "Дальность теней", ["Близко", "Средне", "Далеко"]],
		["view", "Дальность прорисовки *", ["Близко", "Средне", "Далеко"]],
		["veg", "Плотность растительности *", ["Мало", "Средне", "Много"]],
		["poly", "Детализация деревьев *", ["Низкая", "Средняя", "Высокая"]],
	]],
	["ЭФФЕКТЫ", [
		["fog", "Качество тумана *", ["Базовый", "Густой", "Максимум"]],
		["rain", "Дождь *", ["Лёгкий", "Обычный", "Ливень"]],
		["res", "Разрешение 3D", ["60%", "75%", "100%"]],
		["aa", "Сглаживание", ["Выкл", "2x", "4x"]],
		["aniso", "Фильтрация текстур", ["Выкл", "4x", "16x"]],
		["fps", "Лимит кадров", ["30", "45", "60", "90"]],
		["pixel", "Пиксельный режим", ["Выкл", "Мягкий", "Жёсткий"]],
	]],
	["ЗВУК", [
		["vol_master", "Общая громкость", ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10"]],
		["vol_ambient", "Окружение (дождь, ветер)", ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10"]],
		["vol_creature", "Существо", ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10"]],
	]],
	["УПРАВЛЕНИЕ", [
		["sens", "Чувствительность камеры", ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10"]],
		["camfx", "Покачивание камеры", ["Нет", "Слабое", "Обычное", "Сильное"]],
	]],
]

var mode := "main"
var root: Control
var bg
var box: VBoxContainer
var fv: FontVariation
var title_l: Label
var page := 0
var in_settings := false
var loading := false
var t := 0.0
var menu_rain: AudioStreamPlayer
var upd_btn: Button
var upd_label: Label
var upd_url := ""
var http: HTTPRequest

class Bg extends Control:
	var t := 0.0
	var pause := false
	var rng := RandomNumberGenerator.new()
	var trees := []
	var blob: GradientTexture2D
	var vig: GradientTexture2D
	func _ready() -> void:
		rng.seed = 5
		for i in 46:
			trees.append([rng.randf(), rng.randf_range(0.5, 1.0), rng.randi() % 2])
		var g := Gradient.new()
		g.offsets = PackedFloat32Array([0.0, 0.5, 1.0])
		g.colors = PackedColorArray([Color(1, 1, 1, 0.6), Color(1, 1, 1, 0.22), Color(1, 1, 1, 0.0)])
		blob = GradientTexture2D.new()
		blob.gradient = g
		blob.fill = GradientTexture2D.FILL_RADIAL
		blob.fill_from = Vector2(0.5, 0.5)
		blob.fill_to = Vector2(1.0, 0.5)
		blob.width = 128
		blob.height = 128
		var g2 := Gradient.new()
		g2.offsets = PackedFloat32Array([0.0, 0.6, 1.0])
		g2.colors = PackedColorArray([Color(0, 0, 0, 0.0), Color(0, 0, 0, 0.25), Color(0, 0, 0, 0.92)])
		vig = GradientTexture2D.new()
		vig.gradient = g2
		vig.fill = GradientTexture2D.FILL_RADIAL
		vig.fill_from = Vector2(0.5, 0.5)
		vig.fill_to = Vector2(1.0, 0.9)
		vig.width = 256
		vig.height = 256

	func _process(delta: float) -> void:
		t += delta
		queue_redraw()

	func _taper(pts: Array, w0: float, w1: float, col: Color) -> void:
		for i in pts.size() - 1:
			var k := float(i) / (pts.size() - 1)
			var w := lerpf(w0, w1, k)
			draw_line(pts[i], pts[i + 1], col, w)
			draw_circle(pts[i + 1], w * 0.5, col)

	func _pine(x: float, base: float, h: float, col: Color) -> void:
		var w := h * 0.32
		for i in 6:
			var k := float(i) / 6.0
			var y := base - h * (0.12 + k * 0.78)
			var ww := w * (1.0 - k * 0.8)
			draw_colored_polygon(PackedVector2Array([Vector2(x, y - h * 0.22), Vector2(x + ww, y + h * 0.04), Vector2(x - ww, y + h * 0.04)]), col)
		draw_rect(Rect2(x - h * 0.015, base - h * 0.15, h * 0.03, h * 0.15), col)

	func _draw() -> void:
		var w := size.x
		var h := size.y
		if pause:
			draw_rect(Rect2(0, 0, w, h), Color(0.02, 0.03, 0.035, 0.82))
			return
		for i in 24:
			var k := float(i) / 23.0
			draw_rect(Rect2(0, h * i / 24.0, w, h / 24.0 + 1.0), Color(0.05, 0.06, 0.065).lerp(Color(0.2, 0.225, 0.24), k * k))
		var s := minf(w, h)
		var sil := Color(0.035, 0.04, 0.045, 0.96)
		# существо в тумане
		var sx := w * 0.0 + w
		var neck := [Vector2(0.66, 0.37), Vector2(0.58, 0.29), Vector2(0.545, 0.17), Vector2(0.58, 0.08), Vector2(0.66, 0.065), Vector2(0.705, 0.12), Vector2(0.71, 0.2)]
		var np := []
		for p in neck:
			np.append(Vector2(p.x * w, p.y * h))
		_taper([Vector2(0.9 * w, 0.43 * h), Vector2(0.8 * w, 0.39 * h), np[0]], s * 0.06, s * 0.085, sil)
		_taper(np, s * 0.085, s * 0.03, sil)
		var tip: Vector2 = np[np.size() - 1]
		for i in 9:
			var ox := (i - 4) * s * 0.006
			var pts := []
			for j in 6:
				pts.append(tip + Vector2(ox + sin(t * 0.5 + i + j * 0.6) * s * 0.008 * j, j * s * 0.07))
			_taper(pts, s * 0.006, s * 0.002, sil)
		for hx in [0.655, 0.69, 0.81, 0.85]:
			var hip := Vector2(hx * w, 0.41 * h)
			var sgn := -1.0 if hx < 0.75 else 1.0
			var knee := hip + Vector2(sgn * s * 0.035, h * 0.2)
			var foot := knee + Vector2(-sgn * s * 0.02, h * 0.23)
			_taper([hip, knee, foot], s * 0.032, s * 0.01, sil)
			draw_circle(hip, s * 0.03, sil)
		# туман слоями
		for i in 9:
			var r := s * (0.5 + 0.12 * (i % 3))
			var px := fmod(i * w * 0.21 + t * (6.0 + i * 2.5), w * 1.5) - w * 0.25
			var py := h * (0.28 + 0.07 * i)
			draw_texture_rect(blob, Rect2(px - r, py - r * 0.35, r * 2.0, r * 0.7), false, Color(0.55, 0.6, 0.62, 0.17))
		# лес
		for tr in trees:
			var x: float = tr[0] * w
			var hh: float = tr[1] * h * 0.55
			if tr[2] == 0:
				_pine(x, h * 0.86, hh * 0.8, Color(0.07, 0.085, 0.09))
		for i in 7:
			var r2 := s * 0.55
			var px2 := fmod(i * w * 0.27 + t * (9.0 + i * 3.0), w * 1.5) - w * 0.25
			draw_texture_rect(blob, Rect2(px2 - r2, h * 0.7 - r2 * 0.25, r2 * 2.0, r2 * 0.5), false, Color(0.55, 0.6, 0.62, 0.2))
		for tr in trees:
			if tr[2] == 1:
				_pine(tr[0] * w, h * 1.02, tr[1] * h * 0.7, Color(0.015, 0.02, 0.022))
		# дождь
		for i in 90:
			var rx := fmod(i * 97.13 + t * 90.0 * 0.15 + i * 3.1, w + 200.0)
			var ry := fmod(i * 53.7 + t * (700.0 + (i % 5) * 80.0), h + 80.0) - 40.0
			draw_line(Vector2(rx, ry), Vector2(rx - 7.0, ry + 28.0), Color(0.75, 0.8, 0.85, 0.12), 1.2)
		draw_texture_rect(vig, Rect2(0, 0, w, h), false)

func _ready() -> void:
	layer = 50
	process_mode = Node.PROCESS_MODE_ALWAYS
	var sf := SystemFont.new()
	sf.font_names = PackedStringArray(["Noto Serif", "Georgia", "serif"])
	fv = FontVariation.new()
	fv.base_font = sf
	fv.spacing_glyph = 3
	root = Control.new()
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)
	bg = Bg.new()
	bg.pause = (mode == "pause")
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(bg)
	box = VBoxContainer.new()
	box.add_theme_constant_override("separation", 6)
	root.add_child(box)
	if mode == "main":
		menu_rain = AudioStreamPlayer.new()
		menu_rain.stream = Synth.noise(3.0, 0.5, 0.4, 0.0, true)
		menu_rain.volume_db = -24.0
		add_child(menu_rain)
		menu_rain.play()
	_build()

func _process(delta: float) -> void:
	t += delta
	var vs := get_viewport().get_visible_rect().size
	root.position = Vector2.ZERO
	root.size = vs
	bg.position = Vector2.ZERO
	bg.size = vs
	if in_settings:
		box.position = Vector2(vs.x * 0.07, vs.y * 0.06)
	elif mode == "main":
		box.position = Vector2(vs.x * 0.07, vs.y * 0.14)
	else:
		box.position = Vector2(vs.x * 0.07, vs.y * 0.3)
	if title_l and is_instance_valid(title_l):
		title_l.modulate.a = 0.85 + 0.15 * sin(t * 1.3) - (0.35 if fmod(t, 7.3) < 0.12 else 0.0)

func show_loading() -> void:
	loading = true
	_clear()
	var l := Label.new()
	l.text = "ЗАГРУЗКА..."
	l.add_theme_font_override("font", fv)
	l.add_theme_font_size_override("font_size", 34)
	l.add_theme_color_override("font_color", Color(0.7, 0.75, 0.73))
	box.add_child(l)

func _clear() -> void:
	for c in box.get_children():
		c.queue_free()
	title_l = null

func _btn(text: String, cb: Callable, size_px: int = 34, minw: float = 460.0) -> Button:
	var b := Button.new()
	b.text = text
	b.flat = true
	b.alignment = HORIZONTAL_ALIGNMENT_LEFT
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_font_override("font", fv)
	b.add_theme_font_size_override("font_size", size_px)
	b.add_theme_color_override("font_color", Color(0.62, 0.68, 0.66))
	b.add_theme_color_override("font_hover_color", Color(0.95, 0.97, 0.95))
	b.add_theme_color_override("font_pressed_color", Color(1, 1, 1))
	b.add_theme_color_override("font_disabled_color", Color(0.28, 0.3, 0.3))
	for st in ["normal", "hover", "pressed", "focus", "disabled"]:
		b.add_theme_stylebox_override(st, StyleBoxEmpty.new())
	b.custom_minimum_size = Vector2(minw, 56)
	b.pressed.connect(cb)
	return b

func _label(text: String, size_px: int, col: Color) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_override("font", fv)
	l.add_theme_font_size_override("font_size", size_px)
	l.add_theme_color_override("font_color", col)
	return l

func _build() -> void:
	in_settings = false
	_clear()
	if mode == "main":
		title_l = _label("DAY17", 100, Color(0.78, 0.84, 0.82))
		box.add_child(title_l)
		box.add_child(_label("Ты не помнишь, как попал сюда.   сборка %d" % int(_version().get("build", 0)), 20, Color(0.5, 0.55, 0.54)))
		var sp := Control.new()
		sp.custom_minimum_size = Vector2(0, 12)
		box.add_child(sp)
		box.add_child(_btn("НОВАЯ ИГРА", _build_slots.bind("new")))
		var cont := _btn("ПРОДОЛЖИТЬ", _continue_last)
		cont.disabled = not Saves.any_exists()
		box.add_child(cont)
		var load_b := _btn("ЗАГРУЗИТЬ", _build_slots.bind("load"))
		load_b.disabled = not Saves.any_exists()
		box.add_child(load_b)
		box.add_child(_btn("НАСТРОЙКИ", _build_settings))
		upd_btn = _btn("ПРОВЕРИТЬ ОБНОВЛЕНИЕ", _check_update, 26)
		box.add_child(upd_btn)
		upd_label = _label("", 18, Color(0.55, 0.6, 0.58))
		box.add_child(upd_label)
		box.add_child(_btn("ВЫХОД", _quit))
	else:
		title_l = _label("ПАУЗА", 80, Color(0.78, 0.84, 0.82))
		box.add_child(title_l)
		box.add_child(_btn("ПРОДОЛЖИТЬ", _resume))
		box.add_child(_btn("СОХРАНИТЬ", _build_slots.bind("save")))
		box.add_child(_btn("НАСТРОЙКИ", _build_settings))
		box.add_child(_btn("В ГЛАВНОЕ МЕНЮ", _to_main))

func _continue_last() -> void:
	continue_game.emit(Saves.latest())

func _quit() -> void:
	quit_game.emit()

func _resume() -> void:
	resume.emit()

func _to_main() -> void:
	to_main.emit()

func _build_slots(kind: String) -> void:
	in_settings = true
	_clear()
	var head := "НОВАЯ ИГРА — выбери слот"
	if kind == "load":
		head = "ЗАГРУЗИТЬ — выбери слот"
	elif kind == "save":
		head = "СОХРАНИТЬ — выбери слот"
	box.add_child(_label(head, 34, Color(0.78, 0.84, 0.82)))
	for i in range(1, Saves.SLOTS + 1):
		var b := _btn(Saves.label(i), _pick_slot.bind(kind, i), 28, 640.0)
		if kind == "load" and not Saves.exists(i):
			b.disabled = true
		box.add_child(b)
	if kind == "new":
		box.add_child(_label("Занятый слот будет перезаписан при первом сохранении.", 18, Color(0.5, 0.55, 0.52)))
	box.add_child(_btn("НАЗАД", _build))

func _pick_slot(kind: String, i: int) -> void:
	if kind == "new":
		new_game.emit(i)
	elif kind == "load":
		continue_game.emit(i)
	else:
		save_to.emit(i)
		_build()

func _build_settings() -> void:
	in_settings = true
	_clear()
	var tabs := HBoxContainer.new()
	for i in PAGES.size():
		var idx := i
		var b := _btn(PAGES[i][0], _set_page.bind(idx), 24, 200.0)
		if i == page:
			b.add_theme_color_override("font_color", Color(1, 1, 1))
		tabs.add_child(b)
	box.add_child(tabs)
	for r in PAGES[page][1]:
		box.add_child(_row(r[0], r[1], r[2]))
	box.add_child(_label("* применяется при новом запуске игры", 18, Color(0.45, 0.5, 0.5)))
	box.add_child(_btn("НАЗАД", _back))

func _set_page(i: int) -> void:
	page = i
	_build_settings()

func _back() -> void:
	Settings.save_settings()
	_build()

func _row(key: String, label: String, opts: Array) -> Control:
	var h := HBoxContainer.new()
	var l := _label(label, 26, Color(0.7, 0.75, 0.73))
	l.custom_minimum_size = Vector2(560, 0)
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	h.add_child(l)
	var bl := _btn("<", _change.bind(key, -1, opts.size()), 30, 70.0)
	h.add_child(bl)
	var v := _label(opts[Settings.s[key]], 26, Color(0.92, 0.95, 0.93))
	v.custom_minimum_size = Vector2(220, 0)
	v.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	h.add_child(v)
	var br := _btn(">", _change.bind(key, 1, opts.size()), 30, 70.0)
	h.add_child(br)
	return h

func _change(key: String, d: int, n: int) -> void:
	Settings.set_value(key, (Settings.s[key] + d + n) % n)
	Settings.apply(get_viewport())
	Settings.save_settings()
	settings_changed.emit()
	_build_settings()

# ---------- обновление: проверка последнего релиза в GitHub ----------
func _version() -> Dictionary:
	var d := {"build": 0, "repo": ""}
	if FileAccess.file_exists("res://version.json"):
		var f := FileAccess.open("res://version.json", FileAccess.READ)
		var p = JSON.parse_string(f.get_as_text())
		if p is Dictionary:
			d = p
	return d

func _status(t: String) -> void:
	if upd_label and is_instance_valid(upd_label):
		upd_label.text = t

func _check_update() -> void:
	if upd_url != "":
		OS.shell_open(upd_url)
		return
	var v := _version()
	if str(v.get("repo", "")) == "":
		_status("Репозиторий не задан (сборка не из GitHub Actions)")
		return
	_status("Проверяю...")
	if http == null:
		http = HTTPRequest.new()
		add_child(http)
		http.request_completed.connect(_on_update)
	http.request("https://api.github.com/repos/%s/releases/latest" % str(v["repo"]), ["User-Agent: day17"])

func _on_update(_result: int, code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
	if code != 200:
		_status("Не удалось проверить (код %d)" % code)
		return
	var d = JSON.parse_string(body.get_string_from_utf8())
	if not (d is Dictionary):
		_status("Ошибка ответа")
		return
	var n := int(str(d.get("tag_name", "build-0")).replace("build-", ""))
	var cur := int(_version().get("build", 0))
	if n > cur:
		upd_url = str(d.get("html_url", ""))
		for a in d.get("assets", []):
			if str(a.get("name", "")).ends_with(".apk"):
				upd_url = str(a.get("browser_download_url", upd_url))
		upd_btn.text = "СКАЧАТЬ СБОРКУ %d" % n
		_status("Установите поверх — прогресс сохранится")
	else:
		_status("У вас последняя версия")

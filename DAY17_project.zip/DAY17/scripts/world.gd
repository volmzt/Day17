extends Node3D
const Synth = preload("res://scripts/synth.gd")
const PlayerS = preload("res://scripts/player.gd")
const CreatureS = preload("res://scripts/creature.gd")
const InteractS = preload("res://scripts/interactable.gd")
const TouchUI = preload("res://scripts/touch_ui.gd")
const CHUNK := 64.0
const GRID := 16
const SAVE_PATH := "user://day17_save.json"
const NOTES := [
	"Лагерь №3. Дождь шестой день. Вчера ночью мы слышали шаги. Слишком медленные для человека. Слишком тяжёлые для зверя. Мы выключили свет.",
	"Если земля дрожит — не бегите. Стойте тихо. Оно слушает.",
	"Рация ловит только шум. Иногда в шуме что-то дышит.",
	"Я перестал считать дни. На картах этого леса нет. Дорога ведёт сюда, но обратно не ведёт.",
	"Дверь скрипела. Мы смазали петли жиром, и она замолчала. Это спасло нас дважды.",
	"Туман не рассеивается даже днём. Деревья на краю видимости иногда оказываются не деревьями.",
]

var quality := 1
var view_r := 1
var height_noise := FastNoiseLite.new()
var biome_noise := FastNoiseLite.new()
var fog_noise := FastNoiseLite.new()
var chunks := {}
var obstacles := {}
var cabins := {}
var player
var creature
var ui
var env: Environment
var tree_mat: ShaderMaterial
var ground_mat: StandardMaterial3D
var road_mat: StandardMaterial3D
var water_mat: StandardMaterial3D
var rock_mat: StandardMaterial3D
var log_mat: StandardMaterial3D
var wood_mat: StandardMaterial3D
var floor_mat: StandardMaterial3D
var rust_mat: StandardMaterial3D
var glass_mat: StandardMaterial3D
var dark_mat: StandardMaterial3D
var rain_mat: StandardMaterial3D
var meshes := {}
var t := 0.0
var wind := 0.4
var wind_boost := 0.0
var rain := 0.5
var rain_target := 0.5
var fog_base := 0.06
var silence_t := 0.0
var sil_s := 0.0
var rain_player: AudioStreamPlayer
var wind_player: AudioStreamPlayer
var thunder_stream: AudioStreamWAV
var creak_stream: AudioStreamWAV
var rain_p: CPUParticles3D
var flash_e := 0.0
var autosave_t := 45.0
var next_event := 70.0
var next_thunder := 50.0
var next_weather := 90.0
var chunk_t := 0.0
var caught_busy := false
var silhouette: Node3D = null
var silhouette_t := 0.0
var ambient_idx := -1
var ambient_lp: AudioEffectLowPassFilter

# ---------- терраин ----------
func road_z(x: float) -> float:
	return 18.0 * sin(x * 0.012) + 9.0 * sin(x * 0.031 + 1.7)

func road_dz(x: float) -> float:
	return 18.0 * 0.012 * cos(x * 0.012) + 9.0 * 0.031 * cos(x * 0.031 + 1.7)

func biome(x: float, z: float) -> float:
	return biome_noise.get_noise_2d(x, z) * 1.6

func cabin_site(c: Vector2i) -> Variant:
	if c == Vector2i(0, 0) or c == Vector2i(0, -1):
		return null
	var h := absi(hash(Vector3i(c.x, c.y, 77)))
	var forced := (c == Vector2i(1, -1))
	if not forced and h % 5 != 0:
		return null
	var ox := float((h / 7) % 25) - 12.0
	var oz := float((h / 131) % 25) - 12.0
	var p := Vector2((c.x + 0.5) * CHUNK + ox, (c.y + 0.5) * CHUNK + oz)
	if not forced and absf(p.y - road_z(p.x)) < 24.0:
		return null
	return p

func ground_h(x: float, z: float) -> float:
	var b := biome(x, z)
	var h := height_noise.get_noise_2d(x, z) * 4.5
	var sw := clampf((-0.35 - b) * 4.0, 0.0, 1.0)
	h = lerpf(h, -1.0 + h * 0.15, sw)
	var d := absf(z - road_z(x))
	h = lerpf(h, 0.0, 1.0 - smoothstep(3.5, 11.0, d))
	var c := Vector2i(floori(x / CHUNK), floori(z / CHUNK))
	var s = cabin_site(c)
	if s != null:
		var dd := Vector2(x, z).distance_to(s)
		h = lerpf(h, 0.0, 1.0 - smoothstep(11.0, 19.0, dd))
	return h

func ground_color(x: float, z: float) -> Color:
	var b := biome(x, z)
	var n := height_noise.get_noise_2d(x * 3.0, z * 3.0) * 0.5 + 0.5
	var col := Color(0.075, 0.085, 0.055)
	if b < -0.35:
		col = col.lerp(Color(0.045, 0.06, 0.05), clampf((-0.35 - b) * 4.0, 0.0, 1.0))
	elif b > 0.55:
		col = col.lerp(Color(0.16, 0.14, 0.11), clampf((b - 0.55) * 4.0, 0.0, 1.0))
	elif b > 0.2:
		col = col.lerp(Color(0.1, 0.12, 0.06), clampf((b - 0.2) * 4.0, 0.0, 1.0))
	var k := 0.75 + n * 0.5
	return Color(col.r * k, col.g * k, col.b * k)

func surface_at(p: Vector3) -> String:
	if biome(p.x, p.z) < -0.35:
		return "swamp"
	if absf(p.z - road_z(p.x)) < 4.0:
		return "road"
	return "mud"

# ---------- старт ----------
func start(load_game: bool, q: int) -> void:
	quality = q
	view_r = 2 if q >= 2 else 1
	height_noise.seed = 1717
	height_noise.frequency = 0.012
	height_noise.fractal_octaves = 3
	biome_noise.seed = 4242
	biome_noise.frequency = 0.0035
	fog_noise.seed = 9
	fog_noise.frequency = 0.05
	_setup_buses()
	_setup_env()
	_setup_materials()
	_setup_meshes()
	_setup_audio()
	var spawn := Vector3(0, 0, road_z(0.0))
	var yaw := -PI / 2.0
	var data := {}
	if load_game and FileAccess.file_exists(SAVE_PATH):
		var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
		var parsed = JSON.parse_string(f.get_as_text())
		if parsed is Dictionary:
			data = parsed
			spawn = Vector3(data.get("x", 0.0), 0, data.get("z", road_z(0.0)))
			yaw = data.get("yaw", yaw)
	_update_chunks(spawn, true)
	_build_car()
	_setup_rain()
	ui = TouchUI.new()
	var layer := CanvasLayer.new()
	layer.add_child(ui)
	add_child(layer)
	player = PlayerS.new()
	player.world = self
	player.ui = ui
	player.yaw = yaw
	add_child(player)
	player.global_position = Vector3(spawn.x, ground_h(spawn.x, spawn.z), spawn.z)
	ui.player = player
	ui.flash_pressed.connect(player.toggle_flash)
	ui.battery_pressed.connect(player.use_battery)
	ui.menu_pressed.connect(_to_menu)
	creature = CreatureS.new()
	creature.world = self
	creature.player = player
	add_child(creature)
	var a := randf() * TAU
	creature.global_position = spawn + Vector3(cos(a), 0, sin(a)) * 380.0
	if data.size() > 0:
		player.battery = data.get("battery", 1.0)
		player.spare_batteries = int(data.get("spare", 1))
		player.stamina = data.get("stamina", 1.0)
		player.intro_t = 8.0
		ui.fade = 1.0
		create_tween().tween_property(ui, "fade", 0.0, 2.5)
	else:
		ui.fade = 1.0
		create_tween().tween_property(ui, "fade", 0.0, 6.0).set_delay(1.0)

func _to_menu() -> void:
	save_game()
	get_tree().reload_current_scene()

func save_game() -> void:
	if player == null or caught_busy:
		return
	var d := {"x": player.global_position.x, "z": player.global_position.z, "yaw": player.yaw,
		"battery": player.battery, "spare": player.spare_batteries, "stamina": player.stamina}
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	f.store_string(JSON.stringify(d))

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST:
		save_game()

# ---------- окружение ----------
func _setup_buses() -> void:
	for n in ["Ambient", "Creature", "SFX"]:
		if AudioServer.get_bus_index(n) != -1:
			continue
		AudioServer.add_bus()
		var i := AudioServer.bus_count - 1
		AudioServer.set_bus_name(i, n)
		AudioServer.set_bus_send(i, "Master")
		AudioServer.add_bus_effect(i, AudioEffectLowPassFilter.new())
		if n != "SFX":
			var rv := AudioEffectReverb.new()
			rv.room_size = 0.8
			rv.wet = 0.18
			AudioServer.add_bus_effect(i, rv)
	ambient_idx = AudioServer.get_bus_index("Ambient")
	ambient_lp = AudioServer.get_bus_effect(ambient_idx, 0)
	ambient_lp.cutoff_hz = 20000.0
	var ci := AudioServer.get_bus_index("Creature")
	(AudioServer.get_bus_effect(ci, 0) as AudioEffectLowPassFilter).cutoff_hz = 16000.0

func _setup_env() -> void:
	env = Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.06, 0.075, 0.08)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.12, 0.14, 0.18)
	env.ambient_light_energy = 0.55
	env.fog_enabled = true
	env.fog_light_color = Color(0.07, 0.085, 0.09)
	env.fog_density = fog_base
	env.fog_sky_affect = 1.0
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	var moon := DirectionalLight3D.new()
	moon.light_color = Color(0.4, 0.5, 0.7)
	moon.light_energy = 0.12
	moon.rotation_degrees = Vector3(-50, 30, 0)
	add_child(moon)

func _noise_tex(freq: float, normal: bool, lo: float) -> NoiseTexture2D:
	var n := FastNoiseLite.new()
	n.frequency = freq
	n.fractal_octaves = 4
	var tx := NoiseTexture2D.new()
	tx.noise = n
	tx.width = 256
	tx.height = 256
	tx.seamless = true
	if normal:
		tx.as_normal_map = true
		tx.bump_strength = 6.0
	else:
		var g := Gradient.new()
		g.colors = PackedColorArray([Color(lo, lo, lo), Color(1, 1, 1)])
		tx.color_ramp = g
	return tx

func _std(col: Color, rough: float) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = col
	m.roughness = rough
	return m

func _setup_materials() -> void:
	ground_mat = _std(Color(1, 1, 1), 0.85)
	ground_mat.vertex_color_use_as_albedo = true
	ground_mat.albedo_texture = _noise_tex(0.02, false, 0.5)
	ground_mat.normal_enabled = true
	ground_mat.normal_texture = _noise_tex(0.03, true, 0.0)
	ground_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	road_mat = _std(Color(0.08, 0.08, 0.085), 0.28)
	road_mat.albedo_texture = _noise_tex(0.05, false, 0.6)
	road_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	water_mat = _std(Color(0.04, 0.06, 0.06, 0.8), 0.05)
	water_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	rock_mat = _std(Color(0.16, 0.16, 0.16), 0.9)
	log_mat = _std(Color(0.12, 0.09, 0.06), 0.95)
	wood_mat = _std(Color(0.17, 0.12, 0.08), 0.9)
	wood_mat.albedo_texture = _noise_tex(0.06, false, 0.55)
	wood_mat.uv1_triplanar = true
	wood_mat.uv1_scale = Vector3(0.5, 0.5, 0.5)
	floor_mat = _std(Color(0.1, 0.075, 0.05), 0.9)
	rust_mat = _std(Color(0.22, 0.11, 0.07), 0.6)
	rust_mat.metallic = 0.4
	glass_mat = _std(Color(0.1, 0.12, 0.12, 0.35), 0.1)
	glass_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	dark_mat = _std(Color(0.05, 0.045, 0.045), 0.9)
	var sh := Shader.new()
	sh.code = """shader_type spatial;
render_mode cull_disabled;
uniform float wind = 0.3;
void vertex() {
	float h = max(VERTEX.y, 0.0);
	float s = sin(TIME * 1.2 + MODEL_MATRIX[3].x * 0.2 + MODEL_MATRIX[3].z * 0.17);
	VERTEX.x += s * wind * h * h * 0.004;
	VERTEX.z += cos(TIME * 0.9 + MODEL_MATRIX[3].z * 0.2) * wind * h * h * 0.003;
}
void fragment() {
	ALBEDO = COLOR.rgb;
	ROUGHNESS = 0.95;
}
"""
	tree_mat = ShaderMaterial.new()
	tree_mat.shader = sh

# ---------- процедурные меши ----------
func _tube(st: SurfaceTool, a: Vector3, b: Vector3, r0: float, r1: float, col: Color, sides: int = 6) -> void:
	var up := (b - a).normalized()
	var ref := Vector3.RIGHT if absf(up.dot(Vector3.RIGHT)) < 0.9 else Vector3.FORWARD
	var x := up.cross(ref).normalized()
	var z := x.cross(up).normalized()
	for i in sides:
		var a0 := TAU * i / sides
		var a1 := TAU * (i + 1) / sides
		var d0 := x * cos(a0) + z * sin(a0)
		var d1 := x * cos(a1) + z * sin(a1)
		var p00 := a + d0 * r0
		var p01 := a + d1 * r0
		var p10 := b + d0 * r1
		var p11 := b + d1 * r1
		for v in [p00, p10, p01, p01, p10, p11]:
			st.set_color(col)
			st.add_vertex(v)

func _commit(st: SurfaceTool) -> ArrayMesh:
	st.generate_normals()
	return st.commit()

func _setup_meshes() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 12
	for v in 3:
		var st := SurfaceTool.new()
		st.begin(Mesh.PRIMITIVE_TRIANGLES)
		var H := 9.0 + v * 3.5
		_tube(st, Vector3.ZERO, Vector3(0, H, 0), 0.4, 0.15, Color(0.1, 0.07, 0.05), 5)
		var layers := 5 + v
		for i in layers:
			var y0 := H * 0.2 + i * (H * 0.75 / layers)
			var r := (1.0 - float(i) / layers) * (2.6 + v * 0.4) + 0.5
			var g := rng.randf_range(0.8, 1.2)
			_tube(st, Vector3(0, y0, 0), Vector3(0, y0 + 3.2, 0), r, 0.0, Color(0.03 * g, 0.075 * g, 0.045 * g), 7)
		meshes["pine%d" % v] = _commit(st)
	for v in 2:
		var st := SurfaceTool.new()
		st.begin(Mesh.PRIMITIVE_TRIANGLES)
		var H := 8.0 + v * 4.0
		_tube(st, Vector3.ZERO, Vector3(0, H, 0), 0.35, 0.1, Color(0.2, 0.17, 0.14), 5)
		for i in 6:
			var y := H * rng.randf_range(0.35, 0.95)
			var a := rng.randf() * TAU
			var l := rng.randf_range(1.5, 3.2)
			_tube(st, Vector3(0, y, 0), Vector3(cos(a) * l, y + rng.randf_range(-0.5, 1.5), sin(a) * l), 0.12, 0.03, Color(0.18, 0.15, 0.12), 4)
		meshes["dead%d" % v] = _commit(st)
	var st2 := SurfaceTool.new()
	st2.begin(Mesh.PRIMITIVE_TRIANGLES)
	for i in 5:
		var a := TAU * i / 5.0
		_tube(st2, Vector3.ZERO, Vector3(cos(a) * 0.35, 0.9, sin(a) * 0.35), 0.06, 0.0, Color(0.05, 0.09, 0.04), 3)
	meshes["tuft"] = _commit(st2)
	var sm := SphereMesh.new()
	sm.radial_segments = 6
	sm.rings = 3
	sm.radius = 1.0
	sm.height = 1.4
	meshes["rock"] = sm
	var cm := CylinderMesh.new()
	cm.top_radius = 0.35
	cm.bottom_radius = 0.4
	cm.height = 5.0
	cm.radial_segments = 6
	meshes["log"] = cm

func _add_mm(parent: Node3D, mesh: Mesh, xforms: Array, mat: Material) -> void:
	if xforms.is_empty():
		return
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.mesh = mesh
	mm.instance_count = xforms.size()
	for i in xforms.size():
		mm.set_instance_transform(i, xforms[i])
	var inst := MultiMeshInstance3D.new()
	inst.multimesh = mm
	inst.material_override = mat
	parent.add_child(inst)

# ---------- чанки ----------
func _update_chunks(pos: Vector3, immediate: bool) -> void:
	var c := Vector2i(floori(pos.x / CHUNK), floori(pos.z / CHUNK))
	var built := 0
	for dz in range(-view_r, view_r + 1):
		for dx in range(-view_r, view_r + 1):
			var cc := Vector2i(c.x + dx, c.y + dz)
			if not chunks.has(cc):
				if immediate or built < 1:
					build_chunk(cc)
					built += 1
	for k in chunks.keys():
		if absi(k.x - c.x) > view_r + 1 or absi(k.y - c.y) > view_r + 1:
			chunks[k].queue_free()
			chunks.erase(k)
			obstacles.erase(k)
			cabins.erase(k)

func build_chunk(c: Vector2i) -> void:
	var root := Node3D.new()
	add_child(root)
	chunks[c] = root
	var x0 := c.x * CHUNK
	var z0 := c.y * CHUNK
	var cell := CHUNK / GRID
	var verts := PackedVector3Array()
	var norms := PackedVector3Array()
	var cols := PackedColorArray()
	var uvs := PackedVector2Array()
	var idx := PackedInt32Array()
	for j in GRID + 1:
		for i in GRID + 1:
			var x := x0 + i * cell
			var z := z0 + j * cell
			verts.append(Vector3(x, ground_h(x, z), z))
			norms.append(Vector3(ground_h(x - 1.0, z) - ground_h(x + 1.0, z), 2.0, ground_h(x, z - 1.0) - ground_h(x, z + 1.0)).normalized())
			cols.append(ground_color(x, z))
			uvs.append(Vector2(x, z) * 0.15)
	for j in GRID:
		for i in GRID:
			var a := j * (GRID + 1) + i
			idx.append_array(PackedInt32Array([a, a + 1, a + GRID + 1, a + 1, a + GRID + 2, a + GRID + 1]))
	var arr := []
	arr.resize(Mesh.ARRAY_MAX)
	arr[Mesh.ARRAY_VERTEX] = verts
	arr[Mesh.ARRAY_NORMAL] = norms
	arr[Mesh.ARRAY_COLOR] = cols
	arr[Mesh.ARRAY_TEX_UV] = uvs
	arr[Mesh.ARRAY_INDEX] = idx
	var gm := ArrayMesh.new()
	gm.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)
	var mi := MeshInstance3D.new()
	mi.mesh = gm
	mi.material_override = ground_mat
	root.add_child(mi)
	# вода/лужи
	var pm := PlaneMesh.new()
	pm.size = Vector2(CHUNK, CHUNK)
	var wi := MeshInstance3D.new()
	wi.mesh = pm
	wi.material_override = water_mat
	wi.position = Vector3(x0 + CHUNK / 2.0, -0.7, z0 + CHUNK / 2.0)
	root.add_child(wi)
	_build_road(root, x0, z0)
	# растительность
	var rng := RandomNumberGenerator.new()
	rng.seed = absi(hash(c))
	var pines := [[], [], []]
	var deads := [[], []]
	var tufts := []
	var rocks := []
	var logs := []
	var obs := []
	var cs = cabin_site(c)
	var car_p := Vector2(6.0, road_z(6.0))
	for k in 150:
		var x := x0 + rng.randf() * CHUNK
		var z := z0 + rng.randf() * CHUNK
		var b := biome(x, z)
		if absf(z - road_z(x)) < 7.0:
			continue
		if cs != null and Vector2(x, z).distance_to(cs) < 15.0:
			continue
		if Vector2(x, z).distance_to(car_p) < 8.0:
			continue
		var p := 0.85
		var dead := false
		if b < -0.35:
			p = 0.08
			dead = true
		elif b > 0.55:
			p = 0.5
			dead = true
		elif b > 0.2:
			p = 0.09
		var y := ground_h(x, z)
		var r := rng.randf()
		if r < p:
			var s := rng.randf_range(0.8, 1.5)
			var bs := Basis(Vector3.UP, rng.randf() * TAU).scaled(Vector3(s, s * rng.randf_range(0.9, 1.25), s))
			var xf := Transform3D(bs, Vector3(x, y - 0.1, z))
			if dead:
				deads[rng.randi() % 2].append(xf)
			else:
				pines[rng.randi() % 3].append(xf)
			obs.append(Vector3(x, z, 0.5 * s))
		elif rng.randf() < 0.14:
			var rs := rng.randf_range(0.5, 1.6)
			rocks.append(Transform3D(Basis(Vector3.UP, rng.randf() * TAU).scaled(Vector3(rs * 1.2, rs * 0.7, rs)), Vector3(x, y, z)))
			obs.append(Vector3(x, z, rs))
		elif rng.randf() < 0.06:
			var lb := Basis(Vector3.UP, rng.randf() * TAU) * Basis(Vector3.RIGHT, PI / 2.0)
			logs.append(Transform3D(lb, Vector3(x, y + 0.3, z)))
	for k in 90:
		var x := x0 + rng.randf() * CHUNK
		var z := z0 + rng.randf() * CHUNK
		var b := biome(x, z)
		if b > 0.55 or absf(z - road_z(x)) < 5.0:
			continue
		var sc := rng.randf_range(0.6, 1.6)
		tufts.append(Transform3D(Basis(Vector3.UP, rng.randf() * TAU).scaled(Vector3(sc, sc, sc)), Vector3(x, ground_h(x, z), z)))
	for v in 3:
		_add_mm(root, meshes["pine%d" % v], pines[v], tree_mat)
	for v in 2:
		_add_mm(root, meshes["dead%d" % v], deads[v], tree_mat)
	_add_mm(root, meshes["tuft"], tufts, tree_mat)
	_add_mm(root, meshes["rock"], rocks, rock_mat)
	_add_mm(root, meshes["log"], logs, log_mat)
	obstacles[c] = obs
	if cs != null:
		_build_cabin(root, c, cs)
	elif absi(hash(Vector3i(c.x, c.y, 5))) % 6 == 0 and c != Vector2i(0, 0):
		_build_camp(root, x0 + 32.0 + rng.randf_range(-12, 12), z0 + 32.0 + rng.randf_range(-12, 12), rng)

func _build_road(root: Node3D, x0: float, z0: float) -> void:
	var pts := []
	for i in 17:
		var x := x0 + i * 4.0
		var rz := road_z(x)
		pts.append([x, rz])
	var any := false
	for p in pts:
		if p[1] > z0 - 6.0 and p[1] < z0 + CHUNK + 6.0:
			any = true
	if not any:
		return
	var verts := PackedVector3Array()
	var idx := PackedInt32Array()
	for p in pts:
		verts.append(Vector3(p[0], 0.04, p[1] - 3.2))
		verts.append(Vector3(p[0], 0.04, p[1] + 3.2))
	for i in 16:
		var a := i * 2
		idx.append_array(PackedInt32Array([a, a + 2, a + 1, a + 1, a + 2, a + 3]))
	var uvs := PackedVector2Array()
	for p in pts:
		uvs.append(Vector2(p[0] * 0.2, 0))
		uvs.append(Vector2(p[0] * 0.2, 1))
	var arr := []
	arr.resize(Mesh.ARRAY_MAX)
	arr[Mesh.ARRAY_VERTEX] = verts
	arr[Mesh.ARRAY_TEX_UV] = uvs
	arr[Mesh.ARRAY_INDEX] = idx
	var normals := PackedVector3Array()
	for v in verts:
		normals.append(Vector3.UP)
	arr[Mesh.ARRAY_NORMAL] = normals
	var m := ArrayMesh.new()
	m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)
	var mi := MeshInstance3D.new()
	mi.mesh = m
	mi.material_override = road_mat
	root.add_child(mi)

# ---------- постройки ----------
func _box(parent: Node3D, pos: Vector3, size: Vector3, mat: Material, collide: bool = true, rot: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = mat
	mi.position = pos
	mi.rotation = rot
	parent.add_child(mi)
	if collide:
		var sb := StaticBody3D.new()
		var cs := CollisionShape3D.new()
		var bs := BoxShape3D.new()
		bs.size = size
		cs.shape = bs
		sb.add_child(cs)
		mi.add_child(sb)
	return mi

func _make_interact(parent: Node3D, pos: Vector3, kind: String, prompt: String, text: String = ""):
	var it = InteractS.new()
	it.kind = kind
	it.prompt = prompt
	it.text = text
	it.world = self
	parent.add_child(it)
	it.position = pos
	return it

func _build_cabin(parent: Node3D, c: Vector2i, site: Vector2) -> void:
	var h := absi(hash(Vector3i(c.x, c.y, 3)))
	var cab := Node3D.new()
	cab.position = Vector3(site.x, 0, site.y)
	parent.add_child(cab)
	var H := 2.8
	_box(cab, Vector3(0, 0.01, 0), Vector3(8, 0.04, 6), floor_mat, false)
	_box(cab, Vector3(-1.5, H / 2, -3), Vector3(5, H, 0.2), wood_mat)
	_box(cab, Vector3(3.3, H / 2, -3), Vector3(1.4, H, 0.2), wood_mat)
	_box(cab, Vector3(1.8, 0.45, -3), Vector3(1.6, 0.9, 0.2), wood_mat)
	_box(cab, Vector3(1.8, 2.4, -3), Vector3(1.6, 0.8, 0.2), wood_mat)
	_box(cab, Vector3(1.8, 1.45, -3), Vector3(1.6, 1.1, 0.04), glass_mat)
	_box(cab, Vector3(-4, H / 2, 0), Vector3(0.2, H, 6.2), wood_mat)
	_box(cab, Vector3(4, H / 2, 0), Vector3(0.2, H, 6.2), wood_mat)
	_box(cab, Vector3(-2.3, H / 2, 3), Vector3(3.4, H, 0.2), wood_mat)
	_box(cab, Vector3(2.3, H / 2, 3), Vector3(3.4, H, 0.2), wood_mat)
	_box(cab, Vector3(0, 2.55, 3), Vector3(1.2, 0.5, 0.2), wood_mat)
	_box(cab, Vector3(0, 3.5, -1.75), Vector3(9, 0.15, 3.9), rust_mat, false, Vector3(-0.4, 0, 0))
	_box(cab, Vector3(0, 3.5, 1.75), Vector3(9, 0.15, 3.9), rust_mat, false, Vector3(0.4, 0, 0))
	var pivot := Node3D.new()
	pivot.position = Vector3(-0.6, 0, 3.0)
	cab.add_child(pivot)
	_box(pivot, Vector3(0.6, 1.15, 0), Vector3(1.2, 2.3, 0.1), wood_mat)
	var door = _make_interact(cab, Vector3(0, 1.2, 3.0), "door", "Дверь")
	door.pivot = pivot
	var sg := 1.0 if h % 2 == 0 else -1.0
	_box(cab, Vector3(-2.9 * sg, 0.3, -1.8), Vector3(2.0, 0.4, 1.0), floor_mat)
	_box(cab, Vector3(2.6 * sg, 0.4, 1.7), Vector3(1.2, 0.8, 0.7), wood_mat)
	_make_interact(cab, Vector3(-2.9 * sg, 0.8, -1.8), "bed", "Отдохнуть")
	var nt = _make_interact(cab, Vector3(2.6 * sg, 0.95, 1.7), "note", "Прочитать", NOTES[h % NOTES.size()])
	_box(nt, Vector3.ZERO, Vector3(0.22, 0.01, 0.3), _std(Color(0.5, 0.47, 0.38), 0.9), false)
	if h % 3 != 0:
		var bt = _make_interact(cab, Vector3(2.2 * sg, 0.9, 1.5), "battery", "Взять батарею")
		_box(bt, Vector3.ZERO, Vector3(0.07, 0.07, 0.15), dark_mat, false)
	cabins[c] = {"pos": Vector3(site.x, 0, site.y), "door": door, "win": Vector3(site.x + 1.8, 1.45, site.y - 3.0)}

func _build_camp(parent: Node3D, x: float, z: float, rng: RandomNumberGenerator) -> void:
	var y := ground_h(x, z)
	var camp := Node3D.new()
	camp.position = Vector3(x, y, z)
	parent.add_child(camp)
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	_tube(st, Vector3.ZERO, Vector3(0, 1.6, 0), 1.9, 0.0, Color(0.1, 0.12, 0.08), 4)
	var mi := MeshInstance3D.new()
	mi.mesh = _commit(st)
	mi.material_override = tree_mat
	camp.add_child(mi)
	for i in 6:
		var a := TAU * i / 6.0
		var rk := MeshInstance3D.new()
		rk.mesh = meshes["rock"]
		rk.material_override = rock_mat
		rk.scale = Vector3(0.25, 0.18, 0.25)
		rk.position = Vector3(5.0 + cos(a) * 0.6, 0.1, sin(a) * 0.6)
		camp.add_child(rk)
	var nt = _make_interact(camp, Vector3(2.2, 0.4, 0.5), "note", "Прочитать", NOTES[rng.randi() % NOTES.size()])
	_box(nt, Vector3.ZERO, Vector3(0.22, 0.02, 0.3), _std(Color(0.5, 0.47, 0.38), 0.9), false)
	if rng.randf() < 0.5:
		var bt = _make_interact(camp, Vector3(2.6, 0.3, -0.4), "battery", "Взять батарею")
		_box(bt, Vector3.ZERO, Vector3(0.07, 0.07, 0.15), dark_mat, false)

func _build_car() -> void:
	var car := Node3D.new()
	var rz := road_z(6.0)
	car.position = Vector3(6.0, 0, rz + 3.8)
	car.rotation.y = -atan2(road_dz(6.0), 1.0)
	add_child(car)
	var cm := _std(Color(0.1, 0.12, 0.1), 0.6)
	cm.metallic = 0.4
	_box(car, Vector3(0, 0.75, 0), Vector3(4.2, 0.9, 1.8), cm, false)
	_box(car, Vector3(-0.2, 1.5, 0), Vector3(2.2, 0.7, 1.6), cm, false)
	for sx in [-1.4, 1.4]:
		for sz in [-0.95, 0.95]:
			var w := MeshInstance3D.new()
			var wm := CylinderMesh.new()
			wm.top_radius = 0.38
			wm.bottom_radius = 0.38
			wm.height = 0.25
			w.mesh = wm
			w.material_override = dark_mat
			w.rotation.x = PI / 2.0
			w.position = Vector3(sx, 0.38, sz)
			car.add_child(w)
	_box(car, Vector3(0.6, 1.0, -1.6), Vector3(1.2, 0.9, 0.06), cm, false, Vector3(0, -1.2, 0))
	var sb := StaticBody3D.new()
	var cs := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = Vector3(4.2, 1.8, 1.8)
	cs.shape = bs
	sb.add_child(cs)
	sb.position.y = 0.9
	car.add_child(sb)
	_make_interact(car, Vector3(0.6, 1.2, -1.3), "note", "Осмотреть бардачок", "Ключей нет. На пассажирском сиденье мокрая карта: названия размыты. На приборной панели засохшая грязь и отпечаток ладони. Не твоей.")
	var bt = _make_interact(car, Vector3(0.8, 1.2, 0.9), "battery", "Взять батарею")
	_box(bt, Vector3.ZERO, Vector3(0.07, 0.07, 0.15), dark_mat, false)

# ---------- коллизии с деревьями, укрытия ----------
func push_out(p: Node3D) -> void:
	var pos := p.global_position
	var c := Vector2i(floori(pos.x / CHUNK), floori(pos.z / CHUNK))
	for dz in range(-1, 2):
		for dx in range(-1, 2):
			var arr = obstacles.get(Vector2i(c.x + dx, c.y + dz))
			if arr == null:
				continue
			for o in arr:
				var d := Vector2(pos.x - o.x, pos.z - o.y).length()
				var minr: float = o.z + 0.45
				if d < minr and d > 0.001:
					var n := Vector2(pos.x - o.x, pos.z - o.y) / d
					pos.x += n.x * (minr - d)
					pos.z += n.y * (minr - d)
	p.global_position = pos

func is_inside(p: Vector3) -> bool:
	for k in cabins:
		var cp: Vector3 = cabins[k]["pos"]
		if absf(p.x - cp.x) < 3.8 and absf(p.z - cp.z) < 2.8:
			return true
	return false

func player_sheltered() -> bool:
	if player == null:
		return false
	for k in cabins:
		var cp: Vector3 = cabins[k]["pos"]
		var pp: Vector3 = player.global_position
		if absf(pp.x - cp.x) < 3.8 and absf(pp.z - cp.z) < 2.8:
			var d = cabins[k]["door"]
			return is_instance_valid(d) and not d.open
	return false

func nearest_cabin_pos(p: Vector3) -> Vector3:
	var best := p
	var bd := 1e9
	for k in cabins:
		var cp: Vector3 = cabins[k]["pos"]
		var d := cp.distance_to(p)
		if d < bd:
			bd = d
			best = cp
	return best

func make_noise(pos: Vector3, loud: float) -> void:
	if creature:
		creature.hear(pos, loud)

func tentacle_window(pp: Vector3) -> void:
	var cp := nearest_cabin_pos(pp)
	for k in cabins:
		if cabins[k]["pos"] == cp:
			var wpos: Vector3 = cabins[k]["win"]
			var root := Node3D.new()
			add_child(root)
			root.global_position = wpos
			var mi := MeshInstance3D.new()
			var cm := CylinderMesh.new()
			cm.height = 9.0
			cm.top_radius = 0.1
			cm.bottom_radius = 0.35
			mi.mesh = cm
			mi.material_override = dark_mat
			mi.rotation = Vector3(PI / 2.0, 0, 0)
			mi.position = Vector3(0, 0, -9.0)
			root.add_child(mi)
			play3d(Synth.noise(3.0, 0.2, 0.5, 0.8), wpos + Vector3(0, 0, -2), -4.0, 80.0, 6.0, "SFX", 0.7)
			var tw := create_tween()
			tw.tween_property(mi, "position:z", -5.2, 8.0)
			tw.tween_interval(3.0)
			tw.tween_property(mi, "position:z", -9.0, 6.0)
			tw.tween_callback(root.queue_free)
			return

func play3d(s: AudioStream, pos: Vector3, db: float, maxd: float, unit: float, bus: String, pitch: float = 1.0) -> void:
	var p := AudioStreamPlayer3D.new()
	p.stream = s
	p.bus = bus
	p.volume_db = db
	p.max_distance = maxd
	p.unit_size = unit
	p.pitch_scale = pitch
	add_child(p)
	p.global_position = pos
	p.finished.connect(p.queue_free)
	p.play()

# ---------- звук, дождь ----------
func _setup_audio() -> void:
	rain_player = AudioStreamPlayer.new()
	rain_player.stream = Synth.noise(3.0, 0.55, 0.5, 0.0, true)
	rain_player.bus = "Ambient"
	rain_player.volume_db = -20.0
	add_child(rain_player)
	rain_player.play()
	wind_player = AudioStreamPlayer.new()
	wind_player.stream = Synth.noise(5.0, 0.012, 0.8, 0.0, true)
	wind_player.bus = "Ambient"
	wind_player.volume_db = -20.0
	add_child(wind_player)
	wind_player.play()
	thunder_stream = Synth.noise(5.0, 0.015, 1.0, 0.55)
	creak_stream = Synth.creak(1.4)

func _setup_rain() -> void:
	rain_p = CPUParticles3D.new()
	rain_p.amount = 450 if quality == 0 else 800
	rain_p.lifetime = 1.0
	rain_p.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	rain_p.emission_box_extents = Vector3(14, 0.5, 14)
	rain_p.direction = Vector3(0.15, -1, 0.05)
	rain_p.spread = 3.0
	rain_p.gravity = Vector3(0, -20, 0)
	rain_p.initial_velocity_min = 16.0
	rain_p.initial_velocity_max = 20.0
	rain_p.local_coords = false
	var bm := BoxMesh.new()
	bm.size = Vector3(0.01, 0.5, 0.01)
	rain_p.mesh = bm
	rain_mat = StandardMaterial3D.new()
	rain_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	rain_mat.albedo_color = Color(0.6, 0.65, 0.7, 0.25)
	rain_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	rain_p.material_override = rain_mat
	add_child(rain_p)

func rest_event() -> void:
	if creature:
		play3d(creature.step_s, player.global_position + Vector3(randf_range(-80, 80), 0, randf_range(-80, 80)), 4.0, 400.0, 30.0, "Creature", 0.5)

func on_caught() -> void:
	caught_busy = true
	player.control = false
	if creature.far_s.size() > 0:
		play3d(creature.near_s[0] if creature.near_s.size() > 0 else creature.far_s[0], player.global_position + Vector3(0, 6, -4), 6.0, 200.0, 20.0, "SFX")
	var tw := create_tween()
	tw.tween_property(ui, "fade", 1.0, 3.0)
	await get_tree().create_timer(4.0).timeout
	ui.msg = "Ты потерял сознание..."
	await get_tree().create_timer(4.0).timeout
	var spawn := Vector3(0, 0, road_z(0.0))
	if FileAccess.file_exists(SAVE_PATH):
		var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
		var parsed = JSON.parse_string(f.get_as_text())
		if parsed is Dictionary:
			spawn = Vector3(parsed.get("x", 0.0), 0, parsed.get("z", spawn.z))
	player.global_position = Vector3(spawn.x, ground_h(spawn.x, spawn.z), spawn.z)
	creature.retreat()
	player.tension = 0.3
	ui.msg = ""
	caught_busy = false
	create_tween().tween_property(ui, "fade", 0.0, 3.0)

# ---------- цикл ----------
func _process(delta: float) -> void:
	if player == null:
		return
	t += delta
	# туман: плотный, плавно меняется
	env.fog_density = fog_base * (0.75 + 0.7 * (fog_noise.get_noise_1d(t * 3.0) * 0.5 + 0.5))
	wind = clampf(0.3 + 0.25 * fog_noise.get_noise_1d(t * 1.7 + 100.0) + wind_boost, 0.0, 1.0)
	tree_mat.set_shader_parameter("wind", wind * 2.0)
	# погода
	next_weather -= delta
	if next_weather <= 0.0:
		next_weather = randf_range(60.0, 180.0)
		rain_target = [0.15, 0.5, 0.85][randi() % 3]
	rain = move_toward(rain, rain_target, delta * 0.03)
	rain_mat.albedo_color.a = lerpf(0.06, 0.3, rain)
	rain_p.global_position = player.global_position + Vector3(0, 12, 0)
	# тишина
	silence_t = maxf(0.0, silence_t - delta)
	sil_s = move_toward(sil_s, 1.0 if silence_t > 0.0 else 0.0, delta * 0.4)
	var inside_k := -10.0 if player.inside else 0.0
	rain_player.volume_db = lerpf(-34.0, -8.0, rain) - 40.0 * sil_s + inside_k
	wind_player.volume_db = lerpf(-32.0, -10.0, wind) - 40.0 * sil_s + inside_k
	var want_cut := 1800.0 if player.inside else 20000.0
	ambient_lp.cutoff_hz = move_toward(ambient_lp.cutoff_hz, want_cut, delta * 12000.0)
	# гроза
	if rain > 0.6:
		next_thunder -= delta
		if next_thunder <= 0.0:
			next_thunder = randf_range(40.0, 120.0)
			flash_e = 1.0
			_thunder_sound()
	flash_e = maxf(0.0, flash_e - delta * 3.0)
	env.ambient_light_energy = 0.55 + flash_e * flash_e * 2.5
	# чанки
	chunk_t -= delta
	if chunk_t <= 0.0:
		chunk_t = 0.25
		_update_chunks(player.global_position, false)
	# случайные события
	next_event -= delta
	if next_event <= 0.0:
		next_event = randf_range(70.0, 200.0)
		_random_event()
	if silhouette:
		silhouette_t -= delta
		if silhouette_t <= 0.0 or silhouette.global_position.distance_to(player.global_position) < 14.0:
			silhouette.queue_free()
			silhouette = null
	autosave_t -= delta
	if autosave_t <= 0.0:
		autosave_t = 45.0
		if creature.dist > 120.0:
			save_game()

func _thunder_sound() -> void:
	await get_tree().create_timer(randf_range(1.0, 5.0)).timeout
	var p := AudioStreamPlayer.new()
	p.stream = thunder_stream
	p.bus = "Ambient"
	p.volume_db = -4.0
	p.pitch_scale = randf_range(0.8, 1.1)
	add_child(p)
	p.finished.connect(p.queue_free)
	p.play()

func _random_event() -> void:
	var pp: Vector3 = player.global_position
	var a := randf() * TAU
	match randi() % 6:
		0:
			var pos := pp + Vector3(cos(a), 0, sin(a)) * randf_range(80.0, 160.0)
			play3d(Synth.thump(1.8, 38.0, 2.2, 0.6), pos, 6.0, 400.0, 25.0, "SFX")
			play3d(Synth.creak(2.5), pos, -2.0, 300.0, 15.0, "SFX", 0.6)
		1:
			var pos2 := pp + Vector3(cos(a), 0, sin(a)) * randf_range(12.0, 25.0)
			play3d(Synth.noise(0.12, 0.7, 0.9, 40.0), pos2, 0.0, 80.0, 6.0, "SFX")
		2:
			silence_t = randf_range(10.0, 25.0)
		3:
			if quality >= 0 and not player.inside:
				_spawn_silhouette()
		4:
			var pos3 := pp + Vector3(cos(a), 0, sin(a)) * randf_range(100.0, 220.0)
			play3d(Synth.thump(1.2, 30.0, 3.0, 0.2), pos3, 8.0, 500.0, 30.0, "SFX")
		_:
			pass

func _spawn_silhouette() -> void:
	if silhouette:
		return
	var yaw: float = player.yaw + randf_range(-0.7, 0.7)
	var dir := Vector3(-sin(yaw), 0, -cos(yaw))
	var pos: Vector3 = player.global_position + dir * randf_range(26.0, 38.0)
	var s := MeshInstance3D.new()
	var cm := CapsuleMesh.new()
	cm.radius = 0.28
	cm.height = 2.1
	s.mesh = cm
	s.material_override = dark_mat
	add_child(s)
	s.global_position = Vector3(pos.x, ground_h(pos.x, pos.z) + 1.05, pos.z)
	silhouette = s
	silhouette_t = randf_range(8.0, 20.0)

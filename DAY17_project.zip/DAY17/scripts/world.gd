extends Node3D
const Synth = preload("res://scripts/synth.gd")
const B = preload("res://scripts/builder.gd")
const Settings = preload("res://scripts/settings.gd")
const PlayerS = preload("res://scripts/player.gd")
const CreatureS = preload("res://scripts/creature.gd")
const InteractS = preload("res://scripts/interactable.gd")
const TouchUI = preload("res://scripts/touch_ui.gd")
const CHUNK := 64.0
var GRID := 28
const Saves = preload("res://scripts/saves.gd")
const Items = preload("res://scripts/items.gd")
const InvUI = preload("res://scripts/inv_ui.gd")
const PIXEL_SHADER := """shader_type canvas_item;
uniform sampler2D screen_tex : hint_screen_texture, filter_nearest;
uniform float lines = 360.0;
uniform float levels = 24.0;
uniform float dither = 0.6;
float bayer(vec2 p) {
	int x = int(mod(p.x, 4.0));
	int y = int(mod(p.y, 4.0));
	int idx = x + y * 4;
	float m[16] = float[16](0.0, 8.0, 2.0, 10.0, 12.0, 4.0, 14.0, 6.0, 3.0, 11.0, 1.0, 9.0, 15.0, 7.0, 13.0, 5.0);
	return m[idx] / 16.0 - 0.5;
}
void fragment() {
	vec2 res = vec2(textureSize(screen_tex, 0));
	float pix = max(res.y / lines, 1.0);
	vec2 cell = floor(SCREEN_UV * res / pix);
	vec2 uv = (cell + 0.5) * pix / res;
	vec3 c = texture(screen_tex, uv).rgb;
	float b = bayer(cell) * dither / levels;
	c = floor((c + b) * levels + 0.5) / levels;
	vec2 q = SCREEN_UV - 0.5;
	c *= 1.0 - dot(q, q) * 0.9;
	COLOR = vec4(c, 1.0);
}
"""
const STORY := {
	"car": "Путевой лист: инспекция бригады №3, участок «Дорога 17».\nВыезд — день 1. Возврат — не позднее дня 17.\nТы помнишь только, как заглушил мотор. Двигатель мёртв: с него кто-то снял детали.",
	"c0": "ЖУРНАЛ БРИГАДЫ №3. День 9.\nТуман не уходит. Рация ловит только шум.\nЕсли читаешь — машину не бросай. Дорога выведет, но нужны детали: канистра на складе, предохранитель у лесника, аккумулятор в радиорубке. Все дома — дальше по дороге на восток.\nНе шуми. Оно ходит по дороге.",
	"c1": "День 12. Мы сняли детали с грузовика, чтобы он не завёлся: боялись, что шум приведёт Его.\nКанистра — здесь, на верстаке. Предохранитель я отнёс леснику, это следующий дом. Ключ от его двери лежит в шкафу.",
	"c2": "День 14. Лесник ушёл на вышку и не вернулся. В его дневнике: «Оно не злое. Оно просто идёт. Мы стоим у него на пути».\nПредохранитель на столе. Аккумулятор — в радиорубке, дальше по дороге. Ключ от рубки — в шкафу.",
	"c3": "День 16. Радио поймало голос. Он считает дни. Он сказал: «День семнадцатый».\nПотом всё стихло, и туман стал плотнее. Забери аккумулятор. Возвращайся к машине. Уезжай. Не оглядывайся.",
}
const NOTES := [
	"Дождь шестой день. Вчера ночью слышали шаги. Слишком медленные для человека, слишком тяжёлые для зверя. Мы выключили свет.",
	"Если земля дрожит — не бегите. Стойте тихо. Оно слушает.",
	"Рация ловит только шум. Иногда в шуме что-то дышит.",
	"Я перестал считать дни. На картах этого леса нет.",
	"Дверь скрипела. Мы смазали петли жиром, и она замолчала. Это спасло нас дважды.",
	"Туман не рассеивается даже днём. Деревья на краю видимости иногда оказываются не деревьями.",
	"Следы у реки — каждый размером с избу. Шагов мы не слышали. Только как лес замолкает.",
	"Говорят, оно ищет не нас. Оно ищет то, что мы отсюда унесли.",
	"Не свети на него. Свет оно видит. Иногда останавливается и смотрит. Иногда идёт на свет.",
	"Маша сказала, что видела людей между деревьями. Они стояли и смотрели. Следов я не нашёл.",
	"Консервы кончились на 11-й день. Воду берём из бочки. Ночью бочка гудит.",
	"Если найдёшь это — иди по дороге. Лес сам не выпустит.",
]

var view_r := 1
var height_noise := FastNoiseLite.new()
var biome_noise := FastNoiseLite.new()
var fog_noise := FastNoiseLite.new()
var shape_noise := FastNoiseLite.new()
var chunks := {}
var obstacles := {}
var cabins := {}
var player
var creature
var ui
var env: Environment
var moon: DirectionalLight3D
var tree_mat: ShaderMaterial
var ground_mat: StandardMaterial3D
var road_mat: StandardMaterial3D
var water_mat: StandardMaterial3D
var rock_mat: StandardMaterial3D
var wood_mat: StandardMaterial3D
var floor_mat: StandardMaterial3D
var rust_mat: StandardMaterial3D
var glass_mat: StandardMaterial3D
var dark_mat: StandardMaterial3D
var cloth_mat: StandardMaterial3D
var paper_mat: StandardMaterial3D
var creature_mat: StandardMaterial3D
var car_mat: StandardMaterial3D
var rain_mat: StandardMaterial3D
var fog_mat: StandardMaterial3D
var meshes := {}
var t := 0.0
var wind := 0.4
var wind_boost := 0.0
var rain := 0.5
var rain_target := 0.5
var fog_base := 0.095
var fog_mul := 1.0
var silence_t := 0.0
var sil_s := 0.0
var rain_player: AudioStreamPlayer
var wind_player: AudioStreamPlayer
var thunder_stream: AudioStreamWAV
var creak_stream: AudioStreamWAV
var rain_p: GPUParticles3D
var fog_p: GPUParticles3D
var fog_pm: ParticleProcessMaterial
var flash_e := 0.0
var autosave_t := 45.0
var next_event := 70.0
var next_thunder := 50.0
var next_weather := 90.0
var chunk_t := 0.0
var caught_busy := false
var silhouette: Node3D = null
var silhouette_t := 0.0
var ambient_lp: AudioEffectLowPassFilter
var slot := 1
var explored := {}
var markers: Array = []
var marker_keys := {}
var taken := {}
var camps := {}
var site_cache := {}
var site_road := {}
var tracks: Array = []
var track_mat: StandardMaterial3D
var path_mat: StandardMaterial3D
var radio_stream: AudioStreamWAV
var inv_ui
var pix_rect: ColorRect
var pix_mat: ShaderMaterial
var explore_t := 0.0
var notes_read := 0
var play_time := 0.0
var site_idx := {}
var dir_t := 100.0
var repairing := false
var car_pos := Vector3.ZERO
var last_obj := ""
var obj_t := 0.0

# ---------- терраин ----------
func road_z(x: float) -> float:
	return 18.0 * sin(x * 0.012) + 9.0 * sin(x * 0.031 + 1.7)

func road_dz(x: float) -> float:
	return 18.0 * 0.012 * cos(x * 0.012) + 9.0 * 0.031 * cos(x * 0.031 + 1.7)

func biome(x: float, z: float) -> float:
	return biome_noise.get_noise_2d(x, z) * 1.6

func _road_site(i: int, c: Vector2i) -> Variant:
	var h := absi(hash(Vector2i(i, 31)))
	var x := 84.0 + i * 170.0
	var side := 1.0 if (h % 2 == 0) else -1.0
	if i == 0:
		side = 1.0
	else:
		x += float(h % 41) - 20.0
	var x0 := c.x * CHUNK
	var z0 := c.y * CHUNK
	for cand in [[side, 22.0], [-side, 22.0], [side, 27.0], [-side, 27.0], [side, 18.0], [-side, 18.0]]:
		var z := road_z(x) + float(cand[0]) * float(cand[1])
		if x >= x0 + 16.0 and x <= x0 + CHUNK - 16.0 and z >= z0 + 16.0 and z <= z0 + CHUNK - 16.0:
			return Vector2(x, z)
	return null

func cabin_site(c: Vector2i) -> Variant:
	if site_cache.has(c):
		return site_cache[c]
	var res: Variant = null
	var i0 := floori((c.x * CHUNK - 84.0) / 170.0) - 1
	for i in range(i0, i0 + 3):
		var p = _road_site(i, c)
		if p != null:
			res = p
			site_road[c] = true
			site_idx[c] = i
			break
	if res == null and c != Vector2i(0, 0) and c != Vector2i(0, -1):
		var h := absi(hash(Vector3i(c.x, c.y, 77)))
		if h % 7 == 0:
			var ox := float((h / 7) % 25) - 12.0
			var oz := float((h / 131) % 25) - 12.0
			var p2 := Vector2((c.x + 0.5) * CHUNK + ox, (c.y + 0.5) * CHUNK + oz)
			if absf(p2.y - road_z(p2.x)) > 34.0:
				res = p2
	site_cache[c] = res
	return res

func ground_h(x: float, z: float) -> float:
	var b := biome(x, z)
	var h := height_noise.get_noise_2d(x, z) * 4.5
	var sw := clampf((-0.35 - b) * 4.0, 0.0, 1.0)
	h = lerpf(h, -1.0 + h * 0.15, sw)
	var d := absf(z - road_z(x))
	h = lerpf(h, 0.0, 1.0 - smoothstep(3.5, 11.0, d))
	var c := Vector2i(floori(x / CHUNK), floori(z / CHUNK))
	var s = cabin_site(c)
	if s != null:
		var dd := Vector2(x, z).distance_to(s)
		h = lerpf(h, 0.0, 1.0 - smoothstep(9.0, 15.0, dd))
	return h

func ground_color(x: float, z: float) -> Color:
	var b := biome(x, z)
	var n := height_noise.get_noise_2d(x * 3.0, z * 3.0) * 0.5 + 0.5
	var col := Color(0.085, 0.09, 0.06)
	if b < -0.35:
		col = col.lerp(Color(0.05, 0.065, 0.055), clampf((-0.35 - b) * 4.0, 0.0, 1.0))
	elif b > 0.55:
		col = col.lerp(Color(0.18, 0.16, 0.125), clampf((b - 0.55) * 4.0, 0.0, 1.0))
	elif b > 0.2:
		col = col.lerp(Color(0.11, 0.13, 0.07), clampf((b - 0.2) * 4.0, 0.0, 1.0))
	var k := 0.7 + n * 0.6
	return Color(col.r * k, col.g * k, col.b * k)

func surface_at(p: Vector3) -> String:
	if is_inside(p):
		return "wood"
	var b := biome(p.x, p.z)
	if b < -0.35:
		return "swamp"
	if absf(p.z - road_z(p.x)) < 4.0:
		return "road"
	if b > 0.55:
		return "dry"
	if b > 0.2:
		return "grass"
	if ground_h(p.x, p.z) < -0.3:
		return "mud"
	return "needles"

# ---------- старт ----------
func start(load_game: bool, slot_i: int = 1) -> void:
	slot = slot_i
	view_r = [1, 1, 2][Settings.s["view"]]
	GRID = [16, 24, 32][Settings.s["poly"]]
	height_noise.seed = 1717
	height_noise.frequency = 0.012
	height_noise.fractal_octaves = 3
	biome_noise.seed = 4242
	biome_noise.frequency = 0.0035
	fog_noise.seed = 9
	fog_noise.frequency = 0.05
	shape_noise.seed = 5
	shape_noise.frequency = 0.6
	shape_noise.fractal_octaves = 3
	_setup_buses()
	Settings.apply(get_viewport())
	_setup_env()
	_setup_materials()
	_setup_track_mat()
	_setup_meshes()
	_setup_audio()
	var spawn := Vector3(0, 0, road_z(0.0))
	var yaw := -PI / 2.0
	var data := {}
	if load_game:
		data = Saves.read(slot)
		if data.size() > 0:
			spawn = Vector3(float(data.get("x", 0.0)), 0, float(data.get("z", road_z(0.0))))
			yaw = float(data.get("yaw", yaw))
			notes_read = int(data.get("notes", 0))
			for k in data.get("taken", []):
				taken[String(k)] = true
			for k in data.get("explored", []):
				var parts := String(k).split("_")
				if parts.size() == 2:
					explored[Vector2i(int(parts[0]), int(parts[1]))] = true
			for m in data.get("markers", []):
				_add_marker(Vector3(float(m["x"]), 0, float(m["z"])), String(m["k"]))
	_update_chunks(spawn, true)
	_build_car()
	_setup_rain()
	_setup_fog_sprites()
	_setup_pixel()
	ui = TouchUI.new()
	var layer := CanvasLayer.new()
	layer.layer = 2
	layer.add_child(ui)
	add_child(layer)
	player = PlayerS.new()
	player.world = self
	player.ui = ui
	player.yaw = yaw
	add_child(player)
	player.global_position = Vector3(spawn.x, ground_h(spawn.x, spawn.z), spawn.z)
	inv_ui = InvUI.new()
	inv_ui.player = player
	var il := CanvasLayer.new()
	il.layer = 3
	il.add_child(inv_ui)
	add_child(il)
	player.inv_ui = inv_ui
	ui.player = player
	ui.flash_pressed.connect(player.toggle_flash)
	ui.battery_pressed.connect(player.use_battery)
	ui.crouch_pressed.connect(player.toggle_crouch)
	ui.bag_pressed.connect(player.toggle_bag)
	ui.map_pressed.connect(player.toggle_map)
	ui.menu_pressed.connect(_pause)
	creature = CreatureS.new()
	creature.world = self
	creature.player = player
	add_child(creature)
	var a := randf() * TAU
	creature.global_position = spawn + Vector3(cos(a), 0, sin(a)) * 280.0
	if data.size() > 0:
		player.load_state(data)
		if data.has("cx") and data.has("cz"):
			creature.global_position = Vector3(float(data["cx"]), 0, float(data["cz"]))
		player.intro_t = 8.0
		ui.fade = 1.0
		create_tween().tween_property(ui, "fade", 0.0, 2.5)
	else:
		ui.fade = 1.0
		create_tween().tween_property(ui, "fade", 0.0, 6.0).set_delay(1.0)

signal pause_requested
func _pause() -> void:
	save_game()
	pause_requested.emit()

func apply_live() -> void:
	Settings.apply(get_viewport())
	_apply_pixel()
	if player:
		player.flash.shadow_enabled = Settings.s["shadows"] > 0
		player.sens = 0.001 + Settings.s["sens"] * 0.0006
		player.cam_intensity = [0.0, 0.5, 1.0, 1.5][Settings.s["camfx"]]
	if moon:
		moon.shadow_enabled = Settings.s["shadows"] >= 2
		moon.directional_shadow_max_distance = [50.0, 80.0, 140.0][Settings.s["shadow_dist"]]

func collect_state() -> Dictionary:
	var d := {"x": player.global_position.x, "z": player.global_position.z, "yaw": player.yaw,
		"cx": creature.global_position.x, "cz": creature.global_position.z, "notes": notes_read}
	var ps: Dictionary = player.save_state()
	for k in ps:
		d[k] = ps[k]
	d["taken"] = taken.keys()
	var ex: Array = []
	for k in explored.keys():
		var kk: Vector2i = k
		ex.append("%d_%d" % [kk.x, kk.y])
	d["explored"] = ex
	var mk: Array = []
	for m in markers:
		var mp: Vector3 = m["p"]
		mk.append({"x": mp.x, "z": mp.z, "k": m["k"]})
	d["markers"] = mk
	return d

func save_game() -> void:
	if player == null or caught_busy or creature == null:
		return
	Saves.write(slot, collect_state())

func save_to_slot(i: int) -> void:
	slot = i
	save_game()
	if ui != null:
		ui.toast("Сохранено: слот %d" % i)

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST:
		save_game()

# ---------- окружение ----------
func _setup_buses() -> void:
	for n in ["Ambient", "Creature", "SFX"]:
		if AudioServer.get_bus_index(n) != -1:
			continue
		AudioServer.add_bus()
		var i := AudioServer.bus_count - 1
		AudioServer.set_bus_name(i, n)
		AudioServer.set_bus_send(i, "Master")
		AudioServer.add_bus_effect(i, AudioEffectLowPassFilter.new())
		if n == "Creature":
			var rv := AudioEffectReverb.new()
			rv.room_size = 0.85
			rv.wet = 0.2
			AudioServer.add_bus_effect(i, rv)
	var ai := AudioServer.get_bus_index("Ambient")
	ambient_lp = AudioServer.get_bus_effect(ai, 0)
	ambient_lp.cutoff_hz = 20000.0
	var ci := AudioServer.get_bus_index("Creature")
	var clp := AudioServer.get_bus_effect(ci, 0) as AudioEffectLowPassFilter
	clp.cutoff_hz = 16000.0

func _setup_env() -> void:
	env = Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.15, 0.175, 0.19)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.2, 0.23, 0.28)
	env.ambient_light_energy = 0.5
	env.fog_enabled = true
	env.fog_light_color = Color(0.15, 0.175, 0.19)
	env.fog_density = fog_base
	env.fog_sky_affect = 1.0
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	moon = DirectionalLight3D.new()
	moon.light_color = Color(0.45, 0.55, 0.75)
	moon.light_energy = 0.15
	moon.rotation_degrees = Vector3(-50, 30, 0)
	add_child(moon)

func _ntex(freq: float, octaves: int, cols: Array, offs: Array, normal: bool = false, bump: float = 6.0, sd: int = 1, ntype: int = FastNoiseLite.TYPE_SIMPLEX_SMOOTH) -> NoiseTexture2D:
	var n := FastNoiseLite.new()
	n.noise_type = ntype
	n.seed = sd
	n.frequency = freq
	n.fractal_octaves = octaves
	var tx := NoiseTexture2D.new()
	tx.noise = n
	tx.width = 256
	tx.height = 256
	tx.seamless = true
	if normal:
		tx.as_normal_map = true
		tx.bump_strength = bump
	else:
		var g := Gradient.new()
		g.offsets = PackedFloat32Array(offs)
		g.colors = PackedColorArray(cols)
		tx.color_ramp = g
	return tx

func _std(col: Color, rough: float) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = col
	m.roughness = rough
	return m

func _setup_materials() -> void:
	var g1 := [Color(0.42, 0.4, 0.36), Color(0.78, 0.72, 0.62), Color(0.55, 0.65, 0.48), Color(1.0, 0.95, 0.9)]
	var o1 := [0.0, 0.35, 0.65, 1.0]
	ground_mat = _std(Color(1, 1, 1), 0.8)
	ground_mat.vertex_color_use_as_albedo = true
	ground_mat.albedo_texture = _ntex(0.035, 5, g1, o1, false, 6.0, 3)
	ground_mat.normal_enabled = true
	ground_mat.normal_texture = _ntex(0.05, 5, [], [], true, 7.0, 3)
	ground_mat.normal_scale = 1.3
	ground_mat.detail_enabled = true
	ground_mat.detail_uv_layer = BaseMaterial3D.DETAIL_UV_2
	ground_mat.detail_blend_mode = BaseMaterial3D.BLEND_MODE_MUL
	ground_mat.detail_albedo = _ntex(0.15, 3, [Color(0.55, 0.55, 0.55), Color(1.0, 1.0, 1.0)], [0.0, 1.0], false, 1.0, 8)
	ground_mat.detail_normal = _ntex(0.2, 3, [], [], true, 6.0, 8)
	ground_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	road_mat = _std(Color(0.11, 0.11, 0.115), 0.3)
	road_mat.albedo_texture = _ntex(0.09, 5, [Color(0.4, 0.4, 0.4), Color(0.7, 0.7, 0.72), Color(1, 1, 1)], [0.0, 0.5, 1.0], false, 1.0, 12)
	road_mat.normal_enabled = true
	road_mat.normal_texture = _ntex(0.12, 4, [], [], true, 9.0, 12)
	road_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	water_mat = _std(Color(0.04, 0.06, 0.06, 0.82), 0.04)
	water_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	water_mat.metallic = 0.2
	rock_mat = _std(Color(0.7, 0.7, 0.72), 0.85)
	rock_mat.vertex_color_use_as_albedo = true
	rock_mat.albedo_texture = _ntex(0.05, 4, [Color(0.5, 0.5, 0.5), Color(1, 1, 1)], [0.0, 1.0], false, 1.0, 21, FastNoiseLite.TYPE_CELLULAR)
	rock_mat.normal_enabled = true
	rock_mat.normal_texture = _ntex(0.06, 4, [], [], true, 8.0, 21, FastNoiseLite.TYPE_CELLULAR)
	rock_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	wood_mat = _std(Color(0.3, 0.22, 0.15), 0.85)
	wood_mat.albedo_texture = _ntex(0.05, 5, [Color(0.35, 0.28, 0.22), Color(0.8, 0.68, 0.55), Color(1, 0.9, 0.8)], [0.0, 0.5, 1.0], false, 1.0, 30)
	wood_mat.normal_enabled = true
	wood_mat.normal_texture = _ntex(0.06, 5, [], [], true, 9.0, 30)
	wood_mat.uv1_scale = Vector3(4.0, 3.0, 1.0)
	floor_mat = _std(Color(0.2, 0.15, 0.1), 0.85)
	floor_mat.albedo_texture = wood_mat.albedo_texture
	floor_mat.uv1_triplanar = true
	floor_mat.uv1_scale = Vector3(0.4, 0.4, 0.4)
	rust_mat = _std(Color(0.6, 0.45, 0.4), 0.6)
	rust_mat.albedo_texture = _ntex(0.04, 5, [Color(0.3, 0.17, 0.1), Color(0.7, 0.38, 0.2), Color(0.45, 0.42, 0.4)], [0.0, 0.55, 1.0], false, 1.0, 40)
	rust_mat.metallic = 0.35
	rust_mat.uv1_triplanar = true
	rust_mat.uv1_scale = Vector3(0.3, 0.3, 0.3)
	car_mat = _std(Color(1, 1, 1), 0.5)
	car_mat.vertex_color_use_as_albedo = true
	car_mat.metallic = 0.3
	car_mat.albedo_texture = rust_mat.albedo_texture
	car_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	glass_mat = _std(Color(0.1, 0.12, 0.12, 0.35), 0.05)
	glass_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	dark_mat = _std(Color(0.05, 0.045, 0.045), 0.9)
	cloth_mat = _std(Color(0.16, 0.13, 0.1), 1.0)
	cloth_mat.albedo_texture = _ntex(0.2, 3, [Color(0.5, 0.5, 0.5), Color(1, 1, 1)], [0.0, 1.0], false, 1.0, 50)
	paper_mat = _std(Color(0.55, 0.5, 0.4), 0.95)
	creature_mat = _std(Color(1, 1, 1), 0.42)
	creature_mat.vertex_color_use_as_albedo = true
	creature_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	creature_mat.albedo_texture = _ntex(0.07, 4, [Color(0.45, 0.45, 0.45), Color(1, 1, 1)], [0.0, 1.0], false, 1.0, 60)
	creature_mat.normal_enabled = true
	creature_mat.normal_texture = _ntex(0.09, 4, [], [], true, 12.0, 60)
	creature_mat.clearcoat_enabled = true
	creature_mat.clearcoat = 0.35
	creature_mat.clearcoat_roughness = 0.35
	var sh := Shader.new()
	sh.code = """shader_type spatial;
render_mode cull_disabled;
uniform sampler2D tex : source_color, repeat_enable, filter_linear_mipmap;
uniform sampler2D nrm : hint_normal, repeat_enable, filter_linear_mipmap;
uniform float wind = 0.3;
void vertex() {
	float h = max(VERTEX.y, 0.0);
	float s = sin(TIME * 1.2 + MODEL_MATRIX[3].x * 0.2 + MODEL_MATRIX[3].z * 0.17);
	VERTEX.x += s * wind * h * h * 0.004;
	VERTEX.z += cos(TIME * 0.9 + MODEL_MATRIX[3].z * 0.2) * wind * h * h * 0.003;
}
void fragment() {
	vec3 tx = texture(tex, UV).rgb;
	ALBEDO = COLOR.rgb * (0.4 + tx * 1.4);
	NORMAL_MAP = texture(nrm, UV).rgb;
	ROUGHNESS = 0.85;
}
"""
	tree_mat = ShaderMaterial.new()
	tree_mat.shader = sh
	tree_mat.set_shader_parameter("tex", _ntex(0.06, 5, [Color(0.45, 0.42, 0.4), Color(0.8, 0.78, 0.74), Color(1, 1, 1)], [0.0, 0.5, 1.0], false, 1.0, 70))
	tree_mat.set_shader_parameter("nrm", _ntex(0.07, 5, [], [], true, 10.0, 70))

func _setup_meshes() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 12
	var d: int = Settings.s["poly"]
	var nz := FastNoiseLite.new()
	nz.frequency = 0.8
	nz.fractal_octaves = 2
	for v in 4:
		meshes["pine%d" % v] = B.pine(rng, 10.0 + v * 3.0, d, nz)
	for v in 2:
		meshes["dead%d" % v] = B.dead_tree(rng, 8.0 + v * 4.0, d, nz)
	for v in 3:
		meshes["rock%d" % v] = B.rock(rng, nz, d)
	for v in 2:
		meshes["log%d" % v] = B.fallen_log(rng, nz, d)
	meshes["grass"] = B.grass(rng, 9 + d * 4, 0.9, 0.5, Color(0.04, 0.07, 0.03), Color(0.1, 0.15, 0.06), 0.03)
	meshes["fern"] = B.grass(rng, 6 + d * 2, 0.7, 1.0, Color(0.03, 0.08, 0.04), Color(0.08, 0.16, 0.07), 0.07)

# ---------- чанки ----------
func _update_chunks(pos: Vector3, immediate: bool) -> void:
	var c := Vector2i(floori(pos.x / CHUNK), floori(pos.z / CHUNK))
	var built := 0
	for dz in range(-view_r, view_r + 1):
		for dx in range(-view_r, view_r + 1):
			var cc := Vector2i(c.x + dx, c.y + dz)
			if not chunks.has(cc):
				if immediate or built < 1:
					build_chunk(cc)
					built += 1
	for k in chunks.keys():
		if absi(k.x - c.x) > view_r + 1 or absi(k.y - c.y) > view_r + 1:
			chunks[k].queue_free()
			chunks.erase(k)
			obstacles.erase(k)
			cabins.erase(k)
			camps.erase(k)

func build_chunk(c: Vector2i) -> void:
	var root := Node3D.new()
	add_child(root)
	chunks[c] = root
	_terrain(root, c)
	await get_tree().process_frame
	if not is_instance_valid(root):
		return
	_vegetation(root, c)
	await get_tree().process_frame
	if not is_instance_valid(root):
		return
	var cs = cabin_site(c)
	if cs != null:
		_build_cabin(root, c, cs)
	elif absi(hash(Vector3i(c.x, c.y, 5))) % 4 == 0 and c != Vector2i(0, 0):
		var rng := RandomNumberGenerator.new()
		rng.seed = absi(hash(c)) + 9
		var cx := c.x * CHUNK + 32.0 + rng.randf_range(-12, 12)
		var cz := c.y * CHUNK + 32.0 + rng.randf_range(-12, 12)
		if absf(cz - road_z(cx)) > 12.0:
			_build_camp(root, c, cx, cz, rng)

func _terrain(root: Node3D, c: Vector2i) -> void:
	var x0 := c.x * CHUNK
	var z0 := c.y * CHUNK
	var cell := CHUNK / GRID
	var N := GRID + 3
	var hs := PackedFloat32Array()
	hs.resize(N * N)
	for j in N:
		for i in N:
			hs[j * N + i] = ground_h(x0 + (i - 1) * cell, z0 + (j - 1) * cell)
	var verts := PackedVector3Array()
	var norms := PackedVector3Array()
	var cols := PackedColorArray()
	var uvs := PackedVector2Array()
	var uv2 := PackedVector2Array()
	var tans := PackedFloat32Array()
	var idx := PackedInt32Array()
	for j in GRID + 1:
		for i in GRID + 1:
			var x := x0 + i * cell
			var z := z0 + j * cell
			var hl := hs[(j + 1) * N + i]
			var hr := hs[(j + 1) * N + i + 2]
			var hd := hs[j * N + i + 1]
			var hu := hs[(j + 2) * N + i + 1]
			verts.append(Vector3(x, hs[(j + 1) * N + i + 1], z))
			norms.append(Vector3(hl - hr, 2.0 * cell, hd - hu).normalized())
			cols.append(ground_color(x, z))
			uvs.append(Vector2(x, z) * 0.12)
			uv2.append(Vector2(x, z) * 0.8)
			tans.append(1.0)
			tans.append(0.0)
			tans.append(0.0)
			tans.append(1.0)
	for j in GRID:
		for i in GRID:
			var a := j * (GRID + 1) + i
			idx.append_array(PackedInt32Array([a, a + 1, a + GRID + 1, a + 1, a + GRID + 2, a + GRID + 1]))
	var arr := []
	arr.resize(Mesh.ARRAY_MAX)
	arr[Mesh.ARRAY_VERTEX] = verts
	arr[Mesh.ARRAY_NORMAL] = norms
	arr[Mesh.ARRAY_TANGENT] = tans
	arr[Mesh.ARRAY_COLOR] = cols
	arr[Mesh.ARRAY_TEX_UV] = uvs
	arr[Mesh.ARRAY_TEX_UV2] = uv2
	arr[Mesh.ARRAY_INDEX] = idx
	var gm := ArrayMesh.new()
	gm.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)
	var mi := MeshInstance3D.new()
	mi.mesh = gm
	mi.material_override = ground_mat
	root.add_child(mi)
	var pm := PlaneMesh.new()
	pm.size = Vector2(CHUNK, CHUNK)
	var wi := MeshInstance3D.new()
	wi.mesh = pm
	wi.material_override = water_mat
	wi.position = Vector3(x0 + CHUNK / 2.0, -0.7, z0 + CHUNK / 2.0)
	root.add_child(wi)
	_build_road(root, x0, z0)

func _mm_at(parent: Node3D, mesh: Mesh, xforms: Array, mat: Material) -> void:
	if xforms.is_empty():
		return
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.mesh = mesh
	mm.instance_count = xforms.size()
	for i in xforms.size():
		mm.set_instance_transform(i, xforms[i])
	var inst := MultiMeshInstance3D.new()
	inst.multimesh = mm
	inst.material_override = mat
	parent.add_child(inst)

func _vegetation(root: Node3D, c: Vector2i) -> void:
	var rng := RandomNumberGenerator.new()
	var pines := [[], [], [], []]
	var deads := [[], []]
	var rocks := [[], [], []]
	var logs := [[], []]
	var grass := []
	var ferns := []
	var obs := []
	var cs = cabin_site(c)
	var car_p := Vector2(6.0, road_z(6.0))
	var paths: Array = []
	for dz in range(-1, 2):
		for dx in range(-1, 2):
			var nc := Vector2i(c.x + dx, c.y + dz)
			var ns = cabin_site(nc)
			if ns != null and site_road.has(nc):
				paths.append(ns)
	var cell := 6.4
	var per := 10
	var dens: float = [0.75, 1.0, 1.2][Settings.s["veg"]]
	for gz in per:
		for gx in per:
			var gi := c.x * per + gx
			var gj := c.y * per + gz
			rng.seed = absi(hash(Vector2i(gi, gj)))
			var x := (gi + 0.15 + rng.randf() * 0.7) * cell
			var z := (gj + 0.15 + rng.randf() * 0.7) * cell
			if absf(z - road_z(x)) < 7.0:
				continue
			if cs != null and Vector2(x, z).distance_to(cs) < 15.0:
				continue
			if Vector2(x, z).distance_to(car_p) < 8.0:
				continue
			var on_path := false
			for ps in paths:
				var pv: Vector2 = ps
				if absf(x - pv.x) < 2.6 and (z - road_z(pv.x)) * (z - pv.y) <= 0.0:
					on_path = true
			if on_path:
				continue
			var b := biome(x, z)
			var p := 0.8
			var dead := false
			if b < -0.35:
				p = 0.08
				dead = true
			elif b > 0.55:
				p = 0.5
				dead = true
			elif b > 0.2:
				p = 0.09
			p = minf(0.95, p * dens)
			var y := ground_h(x, z)
			var r := rng.randf()
			if r < p:
				var s := rng.randf_range(0.8, 1.5)
				var bs := Basis(Vector3.UP, rng.randf() * TAU).scaled(Vector3(s, s * rng.randf_range(0.9, 1.25), s))
				var xf := Transform3D(bs, Vector3(x, y - 0.1, z))
				if dead:
					deads[rng.randi() % 2].append(xf)
				else:
					pines[rng.randi() % 4].append(xf)
				obs.append(Vector3(x, z, 0.5 * s))
			elif r < p + 0.05:
				var rs := rng.randf_range(0.5, 1.6)
				rocks[rng.randi() % 3].append(Transform3D(Basis(Vector3.UP, rng.randf() * TAU).scaled(Vector3(rs, rs, rs)), Vector3(x, y + 0.1, z)))
				obs.append(Vector3(x, z, rs))
			elif r < p + 0.07:
				logs[rng.randi() % 2].append(Transform3D(Basis(Vector3.UP, rng.randf() * TAU), Vector3(x, y + 0.35, z)))
	var gcell := 3.2
	var gper := 20
	for gz in gper:
		for gx in gper:
			var gi := c.x * gper + gx
			var gj := c.y * gper + gz
			rng.seed = absi(hash(Vector3i(gi, gj, 5)))
			if rng.randf() > 0.3 * dens:
				continue
			var x := (gi + rng.randf()) * gcell
			var z := (gj + rng.randf()) * gcell
			var b := biome(x, z)
			if b > 0.55 or absf(z - road_z(x)) < 5.0:
				continue
			var sc := rng.randf_range(0.7, 1.7)
			var xf2 := Transform3D(Basis(Vector3.UP, rng.randf() * TAU).scaled(Vector3(sc, sc, sc)), Vector3(x, ground_h(x, z), z))
			if rng.randf() < 0.65:
				grass.append(xf2)
			else:
				ferns.append(xf2)
	for v in 4:
		_mm_at(root, meshes["pine%d" % v], pines[v], tree_mat)
	for v in 2:
		_mm_at(root, meshes["dead%d" % v], deads[v], tree_mat)
		_mm_at(root, meshes["log%d" % v], logs[v], tree_mat)
	for v in 3:
		_mm_at(root, meshes["rock%d" % v], rocks[v], rock_mat)
	_mm_at(root, meshes["grass"], grass, tree_mat)
	_mm_at(root, meshes["fern"], ferns, tree_mat)
	obstacles[c] = obs

func _build_road(root: Node3D, x0: float, z0: float) -> void:
	var pts := []
	for i in 17:
		var x := x0 + i * 4.0
		pts.append([x, road_z(x)])
	var any := false
	for p in pts:
		if p[1] > z0 - 6.0 and p[1] < z0 + CHUNK + 6.0:
			any = true
	if not any:
		return
	var verts := PackedVector3Array()
	var normals := PackedVector3Array()
	var uvs := PackedVector2Array()
	var tans := PackedFloat32Array()
	var idx := PackedInt32Array()
	for p in pts:
		for s in [-3.2, 3.2]:
			verts.append(Vector3(p[0], 0.04, p[1] + s))
			normals.append(Vector3.UP)
			uvs.append(Vector2(p[0] * 0.25, (p[1] + s) * 0.25))
			tans.append_array(PackedFloat32Array([1.0, 0.0, 0.0, 1.0]))
	for i in 16:
		var a := i * 2
		idx.append_array(PackedInt32Array([a, a + 2, a + 1, a + 1, a + 2, a + 3]))
	var arr := []
	arr.resize(Mesh.ARRAY_MAX)
	arr[Mesh.ARRAY_VERTEX] = verts
	arr[Mesh.ARRAY_NORMAL] = normals
	arr[Mesh.ARRAY_TANGENT] = tans
	arr[Mesh.ARRAY_TEX_UV] = uvs
	arr[Mesh.ARRAY_INDEX] = idx
	var m := ArrayMesh.new()
	m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)
	var mi := MeshInstance3D.new()
	mi.mesh = m
	mi.material_override = road_mat
	root.add_child(mi)

# ---------- постройки ----------
func _box(parent: Node3D, pos: Vector3, size: Vector3, mat: Material, collide: bool = false, rot: Vector3 = Vector3.ZERO, vis: bool = true) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = mat
	mi.position = pos
	mi.rotation = rot
	mi.visible = vis
	parent.add_child(mi)
	if collide:
		var sb := StaticBody3D.new()
		var cs := CollisionShape3D.new()
		var bs := BoxShape3D.new()
		bs.size = size
		cs.shape = bs
		sb.add_child(cs)
		mi.add_child(sb)
	return mi

func _cyl(parent: Node3D, pos: Vector3, r: float, h: float, mat: Material, rot: Vector3 = Vector3.ZERO, seg: int = 8) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = r
	cm.bottom_radius = r * 1.03
	cm.height = h
	cm.radial_segments = seg
	cm.rings = 1
	mi.mesh = cm
	mi.material_override = mat
	mi.position = pos
	mi.rotation = rot
	parent.add_child(mi)
	return mi

func _make_interact(parent: Node3D, pos: Vector3, kind: String, prompt: String, text: String = ""):
	var it = InteractS.new()
	it.kind = kind
	it.prompt = prompt
	it.text = text
	it.world = self
	parent.add_child(it)
	it.position = pos
	return it

# стена из брёвен; gaps: [t0, t1, y0, y1] вдоль стены
func _log_wall(parent: Node3D, a: Vector3, b: Vector3, gaps: Array, rng: RandomNumberGenerator) -> void:
	var L := a.distance_to(b)
	var dir := (b - a).normalized()
	var along_x := absf(dir.x) > 0.5
	for r in 9:
		var y := 0.16 + r * 0.31
		var segs := [[0.0, L]]
		for g in gaps:
			if y + 0.16 > g[2] and y - 0.16 < g[3]:
				var ns := []
				for sg in segs:
					if g[1] <= sg[0] or g[0] >= sg[1]:
						ns.append(sg)
					else:
						if g[0] > sg[0]:
							ns.append([sg[0], g[0]])
						if g[1] < sg[1]:
							ns.append([g[1], sg[1]])
				segs = ns
		for sg in segs:
			var s0: float = sg[0]
			var s1: float = sg[1]
			if s1 - s0 < 0.1:
				continue
			if s0 <= 0.001:
				s0 -= 0.2
			if s1 >= L - 0.001:
				s1 += 0.2
			var mid := a + dir * ((s0 + s1) * 0.5)
			var rot := Vector3(0, 0, PI / 2.0) if along_x else Vector3(PI / 2.0, 0, 0)
			var lg := _cyl(parent, Vector3(mid.x + rng.randf_range(-0.02, 0.02), y, mid.z + rng.randf_range(-0.02, 0.02)), 0.16 + rng.randf_range(-0.015, 0.02), s1 - s0, wood_mat, rot, 8)
			lg.name = "log"

func _col_box(parent: Node3D, pos: Vector3, size: Vector3) -> void:
	_box(parent, pos, size, dark_mat, true, Vector3.ZERO, false)

func _build_cabin(parent: Node3D, c: Vector2i, site: Vector2) -> void:
	var h := absi(hash(Vector3i(c.x, c.y, 3)))
	var rng := RandomNumberGenerator.new()
	rng.seed = h
	var idx: int = int(site_idx.get(c, 99))
	var cab := Node3D.new()
	cab.position = Vector3(site.x, 0, site.y)
	parent.add_child(cab)
	var H := 2.8
	_box(cab, Vector3(0, 0.01, 0), Vector3(8, 0.04, 6), floor_mat)
	_log_wall(cab, Vector3(-4, 0, -3), Vector3(4, 0, -3), [[1.0, 2.6, 0.9, 2.0]], rng)
	_log_wall(cab, Vector3(-4, 0, 3), Vector3(4, 0, 3), [[3.4, 4.6, 0.0, 2.3]], rng)
	_log_wall(cab, Vector3(-4, 0, -3), Vector3(-4, 0, 3), [], rng)
	_log_wall(cab, Vector3(4, 0, -3), Vector3(4, 0, 3), [], rng)
	_box(cab, Vector3(1.8, 1.45, -3), Vector3(1.6, 1.1, 0.04), glass_mat, true)
	_box(cab, Vector3(1.8, 0.92, -3.05), Vector3(1.7, 0.06, 0.12), wood_mat)
	_box(cab, Vector3(1.8, 2.0, -3.05), Vector3(1.7, 0.06, 0.12), wood_mat)
	_box(cab, Vector3(1.8, 1.45, -3.05), Vector3(0.05, 1.1, 0.1), wood_mat)
	_col_box(cab, Vector3(-1.5, H / 2, -3), Vector3(5, H, 0.3))
	_col_box(cab, Vector3(3.3, H / 2, -3), Vector3(1.4, H, 0.3))
	_col_box(cab, Vector3(1.8, 0.45, -3), Vector3(1.6, 0.9, 0.3))
	_col_box(cab, Vector3(1.8, 2.4, -3), Vector3(1.6, 0.8, 0.3))
	_col_box(cab, Vector3(-4, H / 2, 0), Vector3(0.3, H, 6.4))
	_col_box(cab, Vector3(4, H / 2, 0), Vector3(0.3, H, 6.4))
	_col_box(cab, Vector3(-2.3, H / 2, 3), Vector3(3.4, H, 0.3))
	_col_box(cab, Vector3(2.3, H / 2, 3), Vector3(3.4, H, 0.3))
	for sx in [-4.0, 4.0]:
		var zz := -2.8
		while zz <= 2.8:
			var top := 4.2 - 0.42 * absf(zz) - 0.1
			var bh := top - 2.8
			if bh > 0.05:
				_box(cab, Vector3(sx, 2.8 + bh / 2.0, zz), Vector3(0.1, bh, 0.38), wood_mat)
			zz += 0.4
	for side in [-1.0, 1.0]:
		var rp := Node3D.new()
		rp.position = Vector3(0, 3.5, side * 1.75)
		rp.rotation.x = 0.4 * side
		cab.add_child(rp)
		for i in 14:
			var pl := _box(rp, Vector3(rng.randf_range(-0.05, 0.05), rng.randf_range(0.0, 0.03), -1.95 + i * 0.3), Vector3(9.4, 0.07, 0.32), rust_mat if h % 2 == 0 else wood_mat)
			pl.rotation.x = rng.randf_range(-0.03, 0.03)
	_box(cab, Vector3(0, 4.22, 0), Vector3(9.4, 0.1, 0.3), wood_mat)
	# дверь
	var pivot := Node3D.new()
	pivot.position = Vector3(-0.6, 0, 3.0)
	cab.add_child(pivot)
	_box(pivot, Vector3(0.6, 1.15, 0), Vector3(1.2, 2.3, 0.1), wood_mat, true)
	for i in 3:
		_box(pivot, Vector3(0.6, 0.5 + i * 0.7, 0.07), Vector3(1.2, 0.1, 0.03), dark_mat)
	var uid_door := "%d_%d_door" % [c.x, c.y]
	var door = _make_interact(cab, Vector3(0, 1.2, 3.0), "door", "Открыть")
	door.pivot = pivot
	door.uid = uid_door
	door.locked = (idx == 2 or idx == 3) and not taken.has("unlock_" + uid_door)
	if door.locked:
		_box(pivot, Vector3(1.0, 1.1, 0.09), Vector3(0.12, 0.16, 0.05), rust_mat)
	# планировка (3 варианта)
	var v := h % 3
	if idx >= 0 and idx <= 3:
		v = 0
	var bed_p := Vector3(-2.9, 0, -1.8)
	var table_p := Vector3(2.6, 0, 1.7)
	var ward_p := Vector3(3.5, 0, -0.6)
	var crate_p := Vector3(-3.2, 0, 2.2)
	if v == 1:
		bed_p = Vector3(2.9, 0, -1.8)
		table_p = Vector3(-2.6, 0, -1.8)
		ward_p = Vector3(-3.5, 0, 0.9)
		crate_p = Vector3(3.2, 0, 2.2)
	elif v == 2:
		bed_p = Vector3(-2.9, 0, 0.3)
		table_p = Vector3(0.4, 0, -1.9)
		ward_p = Vector3(3.5, 0, 1.2)
		crate_p = Vector3(-3.1, 0, -2.2)
	# кровать
	_box(cab, bed_p + Vector3(0, 0.3, 0), Vector3(2.0, 0.12, 1.0), wood_mat, true)
	_box(cab, bed_p + Vector3(0, 0.42, 0), Vector3(1.9, 0.14, 0.9), cloth_mat)
	_box(cab, bed_p + Vector3(-0.75, 0.55, 0), Vector3(0.4, 0.12, 0.6), paper_mat)
	for px in [-1.0, 1.0]:
		for pz in [-0.45, 0.45]:
			_cyl(cab, bed_p + Vector3(px * 0.95, 0.15, pz), 0.05, 0.3, wood_mat, Vector3.ZERO, 6)
	_make_interact(cab, bed_p + Vector3(0, 0.8, 0), "bed", "Лечь")
	# стол, стул, записка, батарея, радио
	_box(cab, table_p + Vector3(0, 0.78, 0), Vector3(1.3, 0.07, 0.75), wood_mat, true)
	for px in [-0.55, 0.55]:
		for pz in [-0.3, 0.3]:
			_cyl(cab, table_p + Vector3(px, 0.38, pz), 0.04, 0.78, wood_mat, Vector3.ZERO, 6)
	var chair_p := table_p + Vector3(-1.2, 0, 0.0)
	_box(cab, chair_p + Vector3(0, 0.45, 0), Vector3(0.45, 0.06, 0.45), wood_mat)
	for px in [-0.18, 0.18]:
		for pz in [-0.18, 0.18]:
			_cyl(cab, chair_p + Vector3(px, 0.21, pz), 0.025, 0.42, wood_mat, Vector3.ZERO, 5)
	_box(cab, chair_p + Vector3(-0.2, 0.75, 0), Vector3(0.05, 0.5, 0.45), wood_mat)
	var ntext: String = NOTES[(h / 3) % NOTES.size()]
	var nflag := ""
	if idx >= 0 and idx <= 3:
		ntext = String(STORY["c%d" % idx])
		nflag = "seen_c%d" % idx
	var nt = _make_interact(cab, table_p + Vector3(0, 0.9, 0), "note", "Читать", ntext)
	nt.flag = nflag
	_box(nt, Vector3.ZERO, Vector3(0.22, 0.01, 0.3), paper_mat)
	if idx == 2:
		_make_item(cab, table_p + Vector3(-0.4, 0.88, -0.2), "fuse", "q_fuse")
	elif h % 3 != 0:
		_make_item(cab, table_p + Vector3(-0.4, 0.88, -0.2), "battery", "%d_%d_bat" % [c.x, c.y])
	if h % 5 < 2 or idx == 0 or idx == 3:
		var rd = _make_interact(cab, table_p + Vector3(0.4, 0.95, 0.1), "radio", "Радио")
		_box(rd, Vector3.ZERO, Vector3(0.34, 0.2, 0.12), dark_mat)
		_cyl(rd, Vector3(0.12, 0.2, 0), 0.01, 0.35, rust_mat, Vector3(0, 0, 0.3), 4)
	# шкаф-контейнер
	var sgx := 1.0 if ward_p.x > 0.0 else -1.0
	_box(cab, ward_p + Vector3(0, 0.95, 0), Vector3(0.55, 1.9, 1.1), wood_mat, true)
	_box(cab, ward_p + Vector3(-0.28 * sgx, 1.0, 0), Vector3(0.02, 1.7, 0.04), dark_mat)
	var wc = _make_interact(cab, ward_p + Vector3(-0.5 * sgx, 1.0, 0), "container", "Обыскать")
	wc.uid = "%d_%d_ward" % [c.x, c.y]
	wc.loot = Items.roll_loot(rng, 2)
	if idx == 1 or idx == 2:
		wc.loot = [["key", 1]] + Items.roll_loot(rng, 1)
	# ящик-контейнер
	_box(cab, crate_p + Vector3(0, 0.3, 0), Vector3(0.8, 0.6, 0.8), wood_mat, true)
	_box(cab, crate_p + Vector3(0, 0.62, 0), Vector3(0.84, 0.05, 0.84), dark_mat)
	var cc = _make_interact(cab, crate_p + Vector3(0, 0.8, 0), "container", "Обыскать")
	cc.uid = "%d_%d_crate" % [c.x, c.y]
	cc.loot = Items.roll_loot(rng, 1)
	_cyl(cab, Vector3(-3.5 * sgx, 0.25, 2.5), 0.22, 0.5, rust_mat, Vector3.ZERO, 10)
	_box(cab, Vector3(-3.0, 1.6, -2.85), Vector3(1.4, 0.05, 0.3), wood_mat)
	for i in 3:
		_cyl(cab, Vector3(-3.4 + i * 0.4, 1.7, -2.85), 0.05, 0.14, glass_mat, Vector3.ZERO, 6)
	_theme_props(cab, idx)
	cabins[c] = {"pos": Vector3(site.x, 0, site.y), "door": door, "win": Vector3(site.x + 1.8, 1.45, site.y - 3.0), "idx": idx}
	if site_road.has(c):
		_build_path(parent, site)
		var label := "ДОМ"
		if idx == 0:
			label = "УКРЫТИЕ"
		elif idx == 1:
			label = "СКЛАД"
		elif idx == 2:
			label = "ДОМ ЛЕСНИКА"
		elif idx == 3:
			label = "РАДИОРУБКА"
		_build_sign(parent, site, label)

func _build_camp(parent: Node3D, c: Vector2i, x: float, z: float, rng: RandomNumberGenerator) -> void:
	var y := ground_h(x, z)
	var camp := Node3D.new()
	camp.position = Vector3(x, y, z)
	parent.add_child(camp)
	camps[c] = Vector3(x, y, z)
	var mb := B.MB.new()
	var peak := Vector3(0, 1.7, 0)
	for k in 4:
		var a0 := TAU * k / 4.0 + 0.4
		var a1 := TAU * (k + 1) / 4.0 + 0.4
		var p0 := Vector3(cos(a0) * 1.9, 0, sin(a0) * 1.9)
		var p1 := Vector3(cos(a1) * 1.9, 0, sin(a1) * 1.9)
		var nn := ((p0 + p1) * 0.5 + Vector3(0, 1.2, 0)).normalized()
		var col := Color(0.12, 0.14, 0.09)
		var i0 := mb.vert(peak, nn, col, Vector2(0.5, 0))
		var i1 := mb.vert(p0 + Vector3(0, 0.3 if k % 2 == 0 else 0.0, 0), nn, col, Vector2(0, 1))
		var i2 := mb.vert(p1, nn, col, Vector2(1, 1))
		mb.tri(i0, i1, i2)
	var tent := MeshInstance3D.new()
	tent.mesh = mb.to_mesh()
	tent.material_override = tree_mat
	camp.add_child(tent)
	for i in 8:
		var a := TAU * i / 8.0
		var rk := MeshInstance3D.new()
		rk.mesh = meshes["rock%d" % (i % 3)]
		rk.material_override = rock_mat
		rk.scale = Vector3(0.22, 0.18, 0.22)
		rk.position = Vector3(5.0 + cos(a) * 0.65, 0.05, sin(a) * 0.65)
		camp.add_child(rk)
	for i in 4:
		_cyl(camp, Vector3(5.0 + rng.randf_range(-0.3, 0.3), 0.08, rng.randf_range(-0.3, 0.3)), 0.05, 0.7, dark_mat, Vector3(PI / 2.0, rng.randf() * TAU, 0), 6)
	var nt = _make_interact(camp, Vector3(2.2, 0.4, 0.5), "note", "Читать", NOTES[rng.randi() % NOTES.size()])
	_box(nt, Vector3.ZERO, Vector3(0.22, 0.02, 0.3), paper_mat)
	_box(camp, Vector3(3.0, 0.25, -1.6), Vector3(0.8, 0.5, 0.6), wood_mat, true)
	var cc = _make_interact(camp, Vector3(3.0, 0.6, -1.6), "container", "Обыскать")
	cc.uid = "%d_%d_campbox" % [c.x, c.y]
	cc.loot = Items.roll_loot(rng, 2)

func _car_mesh() -> ArrayMesh:
	var mb := B.MB.new()
	var prof := PackedVector2Array([Vector2(-2.15, 0.35), Vector2(-2.15, 0.9), Vector2(-1.95, 1.05), Vector2(-1.2, 1.1), Vector2(-0.75, 1.62),
		Vector2(0.55, 1.62), Vector2(1.05, 1.15), Vector2(1.95, 1.0), Vector2(2.15, 0.8), Vector2(2.15, 0.35)])
	var hw := 0.9
	var tri_idx := Geometry2D.triangulate_polygon(prof)
	var cen := Vector2.ZERO
	for p in prof:
		cen += p
	cen /= prof.size()
	var col := Color(0.16, 0.18, 0.14)
	for side in [1.0, -1.0]:
		var base := mb.v.size()
		for p in prof:
			mb.vert(Vector3(p.x, p.y, side * hw), Vector3(0, 0, side), col, Vector2(p.x * 0.3, p.y * 0.3))
		for i in range(0, tri_idx.size(), 3):
			mb.tri(base + tri_idx[i], base + tri_idx[i + 1], base + tri_idx[i + 2])
		var wp := PackedVector2Array([Vector2(-0.65, 1.15), Vector2(-0.4, 1.56), Vector2(0.5, 1.56), Vector2(0.9, 1.15)])
		var wb := mb.v.size()
		for p in wp:
			mb.vert(Vector3(p.x, p.y, side * (hw + 0.01)), Vector3(0, 0, side), Color(0.02, 0.03, 0.035), Vector2(0, 0))
		mb.tri(wb, wb + 1, wb + 2)
		mb.tri(wb, wb + 2, wb + 3)
	for i in prof.size():
		var a := prof[i]
		var b := prof[(i + 1) % prof.size()]
		var e := (b - a).normalized()
		var n2 := Vector2(e.y, -e.x)
		if n2.dot((a + b) * 0.5 - cen) < 0.0:
			n2 = -n2
		var nn := Vector3(n2.x, n2.y, 0)
		var q0 := mb.vert(Vector3(a.x, a.y, hw), nn, col, Vector2(0, 0))
		var q1 := mb.vert(Vector3(b.x, b.y, hw), nn, col, Vector2(1, 0))
		var q2 := mb.vert(Vector3(a.x, a.y, -hw), nn, col, Vector2(0, 1))
		var q3 := mb.vert(Vector3(b.x, b.y, -hw), nn, col, Vector2(1, 1))
		mb.tri(q0, q1, q2)
		mb.tri(q1, q3, q2)
	return mb.to_mesh()

func _build_car() -> void:
	var car := Node3D.new()
	car.position = Vector3(6.0, 0, road_z(6.0) + 3.8)
	car.rotation.y = -atan2(road_dz(6.0), 1.0)
	add_child(car)
	var cm := MeshInstance3D.new()
	cm.mesh = _car_mesh()
	cm.material_override = car_mat
	car.add_child(cm)
	for sx in [-1.35, 1.35]:
		for sz in [-0.9, 0.9]:
			_cyl(car, Vector3(sx, 0.4, sz), 0.4, 0.28, dark_mat, Vector3(PI / 2.0, 0, 0), 16)
			_cyl(car, Vector3(sx, 0.4, sz * 1.08), 0.2, 0.05, rust_mat, Vector3(PI / 2.0, 0, 0), 10)
	_box(car, Vector3(0.7, 1.0, -1.55), Vector3(1.1, 0.7, 0.05), car_mat, false, Vector3(0, -1.2, 0))
	_box(car, Vector3(2.18, 0.55, 0.6), Vector3(0.05, 0.12, 0.3), paper_mat)
	var sb := StaticBody3D.new()
	var cs := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = Vector3(4.3, 1.8, 1.8)
	cs.shape = bs
	sb.add_child(cs)
	sb.position.y = 0.9
	car.add_child(sb)
	var cn = _make_interact(car, Vector3(0.6, 1.2, -1.3), "note", "Осмотреть", String(STORY["car"]))
	_make_item(car, Vector3(0.9, 1.25, -0.5), "map", "car_map")
	_make_item(car, Vector3(0.9, 1.25, 0.5), "battery", "car_bat")
	car_pos = Vector3(6.0, 0, road_z(6.0) + 3.8)
	var rp = _make_interact(car, Vector3(-1.6, 1.0, -0.3), "repair", "Починить")
	_box(rp, Vector3.ZERO, Vector3(0.1, 0.1, 0.1), dark_mat)
	_add_marker(car_pos, "car")

# ---------- коллизии с деревьями, укрытия ----------
func push_out(p: Node3D) -> void:
	var pos := p.global_position
	var c := Vector2i(floori(pos.x / CHUNK), floori(pos.z / CHUNK))
	for dz in range(-1, 2):
		for dx in range(-1, 2):
			var arr = obstacles.get(Vector2i(c.x + dx, c.y + dz))
			if arr == null:
				continue
			for o in arr:
				var d := Vector2(pos.x - o.x, pos.z - o.y).length()
				var minr: float = o.z + 0.45
				if d < minr and d > 0.001:
					var n := Vector2(pos.x - o.x, pos.z - o.y) / d
					pos.x += n.x * (minr - d)
					pos.z += n.y * (minr - d)
	p.global_position = pos

func is_inside(p: Vector3) -> bool:
	for k in cabins:
		var cp: Vector3 = cabins[k]["pos"]
		if absf(p.x - cp.x) < 3.8 and absf(p.z - cp.z) < 2.8:
			return true
	return false

func player_sheltered() -> bool:
	if player == null:
		return false
	for k in cabins:
		var cp: Vector3 = cabins[k]["pos"]
		var pp: Vector3 = player.global_position
		if absf(pp.x - cp.x) < 3.8 and absf(pp.z - cp.z) < 2.8:
			var d = cabins[k]["door"]
			return is_instance_valid(d) and not d.open
	return false

func nearest_cabin_pos(p: Vector3) -> Vector3:
	var best := p
	var bd := 1e9
	for k in cabins:
		var cp: Vector3 = cabins[k]["pos"]
		var d := cp.distance_to(p)
		if d < bd:
			bd = d
			best = cp
	return best

func make_noise(pos: Vector3, loud: float) -> void:
	if creature:
		creature.hear(pos, loud)

func tentacle_window(pp: Vector3) -> void:
	var cp := nearest_cabin_pos(pp)
	for k in cabins:
		if cabins[k]["pos"] == cp:
			var wpos: Vector3 = cabins[k]["win"]
			var root := Node3D.new()
			add_child(root)
			root.global_position = wpos
			var mb := B.MB.new()
			mb.loft([Vector3(0, 0, 0), Vector3(0.4, 0.2, 3.0), Vector3(-0.2, -0.1, 6.0), Vector3(0.1, 0.1, 9.0)], [0.4, 0.3, 0.18, 0.03], 8, Color(0.05, 0.045, 0.045), Color(0.04, 0.04, 0.04), shape_noise, 0.1, Vector2(2, 0.3))
			var mi := MeshInstance3D.new()
			mi.mesh = mb.to_mesh()
			mi.material_override = creature_mat
			mi.position = Vector3(0, 0, -10.0)
			root.add_child(mi)
			play3d(Synth.noise(3.0, 0.2, 0.5, 0.8), wpos + Vector3(0, 0, -2), -4.0, 80.0, 6.0, "SFX", 0.7)
			var tw := create_tween()
			tw.tween_property(mi, "position:z", -6.4, 8.0)
			tw.tween_interval(3.0)
			tw.tween_property(mi, "position:z", -10.0, 6.0)
			tw.tween_callback(root.queue_free)
			return

func get_radio_stream() -> AudioStreamWAV:
	if radio_stream == null:
		radio_stream = Synth.radio_loop()
	return radio_stream

func play3d(s: AudioStream, pos: Vector3, db: float, maxd: float, unit: float, bus: String, pitch: float = 1.0) -> void:
	var p := AudioStreamPlayer3D.new()
	p.stream = s
	p.bus = bus
	p.volume_db = db
	p.max_distance = maxd
	p.unit_size = unit
	p.pitch_scale = pitch
	add_child(p)
	p.global_position = pos
	p.finished.connect(p.queue_free)
	p.play()

# звук существа: громкость считается вручную, затухает плавно, без обрыва
func play_creature(s: AudioStream, pos: Vector3, db: float, pitch: float = 1.0) -> void:
	var p := AudioStreamPlayer3D.new()
	p.stream = s
	p.bus = "Creature"
	p.attenuation_model = AudioStreamPlayer3D.ATTENUATION_DISABLED
	p.attenuation_filter_cutoff_hz = 20500.0
	p.max_distance = 0.0
	p.volume_db = minf(db, 20.0)
	p.pitch_scale = pitch
	add_child(p)
	p.global_position = pos
	p.finished.connect(p.queue_free)
	p.play()

# ---------- звук, дождь, туман ----------
func _setup_audio() -> void:
	rain_player = AudioStreamPlayer.new()
	rain_player.stream = Synth.noise(3.0, 0.55, 0.5, 0.0, true)
	rain_player.bus = "Ambient"
	rain_player.volume_db = -20.0
	add_child(rain_player)
	rain_player.play()
	wind_player = AudioStreamPlayer.new()
	wind_player.stream = Synth.noise(5.0, 0.012, 0.8, 0.0, true)
	wind_player.bus = "Ambient"
	wind_player.volume_db = -20.0
	add_child(wind_player)
	wind_player.play()
	thunder_stream = Synth.noise(5.0, 0.015, 1.0, 0.55)
	creak_stream = Synth.creak(1.4)

func _setup_rain() -> void:
	var pm := ParticleProcessMaterial.new()
	pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
	pm.emission_box_extents = Vector3(14, 0.5, 14)
	pm.direction = Vector3(0.15, -1, 0.05)
	pm.spread = 3.0
	pm.initial_velocity_min = 16.0
	pm.initial_velocity_max = 20.0
	pm.gravity = Vector3(0, -20, 0)
	rain_p = GPUParticles3D.new()
	rain_p.amount = [350, 650, 1000][Settings.s["rain"]]
	rain_p.lifetime = 1.0
	rain_p.process_material = pm
	rain_p.local_coords = false
	rain_p.visibility_aabb = AABB(Vector3(-40, -40, -40), Vector3(80, 80, 80))
	var bm := BoxMesh.new()
	bm.size = Vector3(0.012, 0.55, 0.012)
	rain_p.draw_pass_1 = bm
	rain_mat = StandardMaterial3D.new()
	rain_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	rain_mat.albedo_color = Color(0.7, 0.75, 0.8, 0.25)
	rain_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	rain_mat.disable_fog = true
	bm.material = rain_mat
	rain_p.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(rain_p)

# Слои плывущего тумана: мягкие большие спрайты вокруг игрока (объём, клубы)
func _setup_fog_sprites() -> void:
	var gr := Gradient.new()
	gr.offsets = PackedFloat32Array([0.0, 0.5, 1.0])
	gr.colors = PackedColorArray([Color(1, 1, 1, 0.55), Color(1, 1, 1, 0.2), Color(1, 1, 1, 0.0)])
	var gt := GradientTexture2D.new()
	gt.gradient = gr
	gt.fill = GradientTexture2D.FILL_RADIAL
	gt.fill_from = Vector2(0.5, 0.5)
	gt.fill_to = Vector2(1.0, 0.5)
	gt.width = 128
	gt.height = 128
	fog_mat = StandardMaterial3D.new()
	fog_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	fog_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	fog_mat.albedo_texture = gt
	fog_mat.vertex_color_use_as_albedo = true
	fog_mat.albedo_color = Color(0.34, 0.38, 0.4, 1.0)
	fog_mat.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	fog_mat.billboard_keep_scale = true
	fog_mat.disable_fog = true
	fog_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	fog_mat.distance_fade_mode = BaseMaterial3D.DISTANCE_FADE_PIXEL_ALPHA
	fog_mat.distance_fade_min_distance = 3.0
	fog_mat.distance_fade_max_distance = 11.0
	var cg := Gradient.new()
	cg.offsets = PackedFloat32Array([0.0, 0.25, 0.75, 1.0])
	cg.colors = PackedColorArray([Color(1, 1, 1, 0.0), Color(1, 1, 1, 0.1), Color(1, 1, 1, 0.1), Color(1, 1, 1, 0.0)])
	var ramp := GradientTexture1D.new()
	ramp.gradient = cg
	var pm := ParticleProcessMaterial.new()
	pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
	pm.emission_box_extents = Vector3(40, 2.0, 40)
	pm.direction = Vector3(1, 0, 0.3)
	pm.spread = 180.0
	pm.gravity = Vector3.ZERO
	pm.initial_velocity_min = 0.3
	pm.initial_velocity_max = 1.0
	pm.scale_min = 9.0
	pm.scale_max = 22.0
	pm.color_ramp = ramp
	fog_pm = pm
	fog_p = GPUParticles3D.new()
	fog_p.amount = [30, 70, 120][Settings.s["fog"]]
	fog_p.lifetime = 16.0
	fog_p.preprocess = 16.0
	fog_p.process_material = pm
	fog_p.local_coords = false
	fog_p.visibility_aabb = AABB(Vector3(-60, -20, -60), Vector3(120, 40, 120))
	var qm := QuadMesh.new()
	qm.size = Vector2(1, 1)
	qm.material = fog_mat
	fog_p.draw_pass_1 = qm
	fog_p.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(fog_p)

func rest_event() -> void:
	if creature and creature.step_s:
		var pos: Vector3 = player.global_position + Vector3(randf_range(-80, 80), 0, randf_range(-80, 80))
		play_creature(creature.step_s, pos, 14.0 + creature._vdb(80.0), 0.5)

func on_caught() -> void:
	caught_busy = true
	repairing = false
	player.control = false
	player.crouched = false
	if inv_ui != null and inv_ui.open:
		inv_ui.toggle()
	if creature.near_s.size() > 0:
		play_creature(creature.near_s[0], player.global_position + Vector3(0, 8, -6), 10.0, 0.7)
	if creature.step_s:
		play_creature(creature.step_s, player.global_position + Vector3(0, 0, -8), 14.0, 0.5)
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(player, "lift", 9.0, 3.0)
	tw.tween_property(player, "pitch", 1.0, 3.0)
	tw.tween_property(ui, "fade", 1.0, 3.2)
	await get_tree().create_timer(3.4).timeout
	ui.msg = "Что-то огромное подняло тебя над лесом."
	await get_tree().create_timer(3.5).timeout
	ui.msg = "Потом — темнота."
	await get_tree().create_timer(3.0).timeout
	player.lift = 0.0
	player.pitch = 0.0
	var lost: String = player.penalize()
	var spawn := Vector3(0, 0, road_z(0.0))
	var d := Saves.read(slot)
	if d.size() > 0:
		spawn = Vector3(float(d.get("x", 0.0)), 0, float(d.get("z", spawn.z)))
	player.global_position = Vector3(spawn.x, ground_h(spawn.x, spawn.z), spawn.z)
	creature.retreat()
	player.tension = 0.3
	ui.msg = "Ты очнулся. Тело болит. " + lost
	await get_tree().create_timer(3.5).timeout
	ui.msg = ""
	caught_busy = false
	create_tween().tween_property(ui, "fade", 0.0, 3.0)

# ---------- цикл ----------
func _process(delta: float) -> void:
	if player == null:
		return
	t += delta
	play_time += delta
	explore_t -= delta
	if explore_t <= 0.0:
		explore_t = 0.5
		_update_discovery()
	dir_t -= delta
	if dir_t <= 0.0:
		director_pass()
	obj_t -= delta
	if obj_t <= 0.0:
		obj_t = 1.0
		var ob := objective()
		if ob != last_obj:
			if last_obj != "":
				ui.toast("Новая цель")
			last_obj = ob
		ui.objective = ob
	if pix_rect != null:
		pix_rect.position = Vector2.ZERO
		pix_rect.size = get_viewport().get_visible_rect().size
	# туман: плотный; рядом с существом чуть редеет (проблески силуэтов)
	var near := clampf(1.0 - creature.dist / 140.0, 0.0, 1.0)
	fog_mul = lerpf(fog_mul, 1.0 - 0.45 * near, delta * 0.4)
	env.fog_density = fog_base * fog_mul * (0.8 + 0.6 * (fog_noise.get_noise_1d(t * 3.0) * 0.5 + 0.5))
	wind = clampf(0.3 + 0.25 * fog_noise.get_noise_1d(t * 1.7 + 100.0) + wind_boost, 0.0, 1.0)
	tree_mat.set_shader_parameter("wind", wind * 2.0)
	# погода
	next_weather -= delta
	if next_weather <= 0.0:
		next_weather = randf_range(60.0, 180.0)
		rain_target = [0.15, 0.5, 0.85][randi() % 3]
	rain = move_toward(rain, rain_target, delta * 0.03)
	rain_mat.albedo_color.a = lerpf(0.06, 0.3, rain)
	rain_p.global_position = player.global_position + Vector3(0, 12, 0)
	fog_p.global_position = player.global_position + Vector3(0, 1.8, 0)
	fog_pm.initial_velocity_max = 0.6 + wind * 2.5
	# тишина
	silence_t = maxf(0.0, silence_t - delta)
	sil_s = move_toward(sil_s, 1.0 if silence_t > 0.0 else 0.0, delta * 0.4)
	var inside_k := -10.0 if player.inside else 0.0
	rain_player.volume_db = lerpf(-34.0, -8.0, rain) - 40.0 * sil_s + inside_k
	wind_player.volume_db = lerpf(-32.0, -10.0, wind) - 40.0 * sil_s + inside_k
	var want_cut := 1800.0 if player.inside else 20000.0
	ambient_lp.cutoff_hz = move_toward(ambient_lp.cutoff_hz, want_cut, delta * 12000.0)
	# гроза
	if rain > 0.6:
		next_thunder -= delta
		if next_thunder <= 0.0:
			next_thunder = randf_range(40.0, 120.0)
			flash_e = 1.0
			_thunder_sound()
	flash_e = maxf(0.0, flash_e - delta * 3.0)
	env.ambient_light_energy = 0.5 + flash_e * flash_e * 2.5
	chunk_t -= delta
	if chunk_t <= 0.0:
		chunk_t = 0.25
		_update_chunks(player.global_position, false)
	next_event -= delta
	if next_event <= 0.0:
		next_event = randf_range(70.0, 200.0)
		_random_event()
	if silhouette:
		silhouette_t -= delta
		if silhouette_t <= 0.0 or silhouette.global_position.distance_to(player.global_position) < 8.0:
			silhouette.queue_free()
			silhouette = null
	autosave_t -= delta
	if autosave_t <= 0.0:
		autosave_t = 45.0
		if creature.dist > 120.0:
			save_game()

func _thunder_sound() -> void:
	await get_tree().create_timer(randf_range(1.0, 5.0)).timeout
	var p := AudioStreamPlayer.new()
	p.stream = thunder_stream
	p.bus = "Ambient"
	p.volume_db = -4.0
	p.pitch_scale = randf_range(0.8, 1.1)
	add_child(p)
	p.finished.connect(p.queue_free)
	p.play()

func _random_event() -> void:
	var pp: Vector3 = player.global_position
	var a := randf() * TAU
	match randi() % 6:
		0:
			var pos := pp + Vector3(cos(a), 0, sin(a)) * randf_range(80.0, 160.0)
			play3d(Synth.thump(1.8, 38.0, 2.2, 0.6), pos, 6.0, 400.0, 25.0, "SFX")
			play3d(Synth.creak(2.5), pos, -2.0, 300.0, 15.0, "SFX", 0.6)
		1:
			var pos2 := pp + Vector3(cos(a), 0, sin(a)) * randf_range(12.0, 25.0)
			play3d(Synth.noise(0.12, 0.7, 0.9, 40.0), pos2, 0.0, 80.0, 6.0, "SFX")
		2:
			silence_t = randf_range(10.0, 25.0)
		3:
			if not player.inside:
				_spawn_silhouette()
		4:
			var pos3 := pp + Vector3(cos(a), 0, sin(a)) * randf_range(100.0, 220.0)
			play3d(Synth.thump(1.2, 30.0, 3.0, 0.2), pos3, 8.0, 500.0, 30.0, "SFX")
		_:
			pass

func _spawn_silhouette() -> void:
	if silhouette:
		return
	var yaw: float = player.yaw + randf_range(-0.7, 0.7)
	var dir := Vector3(-sin(yaw), 0, -cos(yaw))
	var pos: Vector3 = player.global_position + dir * randf_range(16.0, 24.0)
	var s := MeshInstance3D.new()
	var cm := CapsuleMesh.new()
	cm.radius = 0.28
	cm.height = 2.1
	s.mesh = cm
	s.material_override = dark_mat
	add_child(s)
	s.global_position = Vector3(pos.x, ground_h(pos.x, pos.z) + 1.05, pos.z)
	silhouette = s
	silhouette_t = randf_range(8.0, 20.0)

# ---------- предметы, следы, карта, пиксель-режим ----------
func _item_visual(parent: Node3D, id: String) -> void:
	if id == "battery":
		_box(parent, Vector3.ZERO, Vector3(0.05, 0.12, 0.05), dark_mat)
	elif id == "food":
		_cyl(parent, Vector3.ZERO, 0.045, 0.1, rust_mat, Vector3.ZERO, 10)
	elif id == "water":
		_cyl(parent, Vector3.ZERO, 0.04, 0.22, glass_mat, Vector3.ZERO, 8)
	elif id == "bandage":
		_box(parent, Vector3.ZERO, Vector3(0.12, 0.05, 0.08), _std(Color(0.8, 0.8, 0.75), 0.9))
	elif id == "key":
		_box(parent, Vector3.ZERO, Vector3(0.12, 0.02, 0.03), _std(Color(0.6, 0.5, 0.2), 0.5))
	elif id == "map":
		_box(parent, Vector3.ZERO, Vector3(0.2, 0.012, 0.28), paper_mat)
	else:
		_cyl(parent, Vector3.ZERO, 0.05, 0.03, rust_mat, Vector3.ZERO, 10)

func _make_item(parent: Node3D, pos: Vector3, id: String, uid: String):
	if taken.has(uid):
		return null
	var it = _make_interact(parent, pos, "item", "Взять")
	it.item_id = id
	it.uid = uid
	_item_visual(it, id)
	return it

func spawn_drop(id: String, pos: Vector3) -> void:
	var it = _make_interact(self, pos, "item", "Взять")
	it.item_id = id
	it.uid = "drop_%d" % randi()
	it.global_position = Vector3(pos.x, ground_h(pos.x, pos.z) + 0.15, pos.z)
	_item_visual(it, id)

func _setup_track_mat() -> void:
	var gr := Gradient.new()
	gr.offsets = PackedFloat32Array([0.0, 0.6, 1.0])
	gr.colors = PackedColorArray([Color(0.02, 0.015, 0.01, 0.9), Color(0.03, 0.025, 0.02, 0.7), Color(0.03, 0.025, 0.02, 0.0)])
	var gt := GradientTexture2D.new()
	gt.gradient = gr
	gt.fill = GradientTexture2D.FILL_RADIAL
	gt.fill_from = Vector2(0.5, 0.5)
	gt.fill_to = Vector2(1.0, 0.5)
	gt.width = 128
	gt.height = 128
	track_mat = StandardMaterial3D.new()
	track_mat.albedo_texture = gt
	track_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	track_mat.roughness = 1.0
	track_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	path_mat = StandardMaterial3D.new()
	path_mat.albedo_color = Color(0.09, 0.07, 0.05)
	path_mat.roughness = 0.95
	path_mat.cull_mode = BaseMaterial3D.CULL_DISABLED

# Следы существа: огромные вмятины, остаются на земле
func add_track(pos: Vector3, yaw_a: float) -> void:
	if player == null or track_mat == null:
		return
	if Vector2(pos.x - player.global_position.x, pos.z - player.global_position.z).length() > 400.0:
		return
	var mi := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(7.0, 11.0)
	mi.mesh = pm
	mi.material_override = track_mat
	add_child(mi)
	mi.global_position = Vector3(pos.x, ground_h(pos.x, pos.z) + 0.06, pos.z)
	mi.rotation.y = yaw_a
	tracks.append(mi)
	if tracks.size() > 40:
		var old = tracks.pop_front()
		if is_instance_valid(old):
			old.queue_free()

func _add_marker(p: Vector3, k: String) -> void:
	var key := "%d_%d" % [roundi(p.x / 10.0), roundi(p.z / 10.0)]
	if marker_keys.has(key):
		return
	marker_keys[key] = true
	markers.append({"p": p, "k": k})

func _update_discovery() -> void:
	if player == null:
		return
	var pp: Vector3 = player.global_position
	var cx := floori(pp.x / 40.0)
	var cz := floori(pp.z / 40.0)
	for dz in range(-1, 2):
		for dx in range(-1, 2):
			explored[Vector2i(cx + dx, cz + dz)] = true
	for k in cabins:
		var cp: Vector3 = cabins[k]["pos"]
		if Vector2(cp.x - pp.x, cp.z - pp.z).length() < 45.0:
			_add_marker(cp, "cabin")
	for k in camps:
		var cp2: Vector3 = camps[k]
		if Vector2(cp2.x - pp.x, cp2.z - pp.z).length() < 45.0:
			_add_marker(cp2, "camp")

func _setup_pixel() -> void:
	var pl := CanvasLayer.new()
	pl.layer = 1
	add_child(pl)
	pix_rect = ColorRect.new()
	pix_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sh := Shader.new()
	sh.code = PIXEL_SHADER
	pix_mat = ShaderMaterial.new()
	pix_mat.shader = sh
	pix_rect.material = pix_mat
	pl.add_child(pix_rect)
	_apply_pixel()

func _apply_pixel() -> void:
	if pix_rect == null:
		return
	var m: int = Settings.s["pixel"]
	pix_rect.visible = m > 0
	pix_mat.set_shader_parameter("lines", 300.0 if m == 2 else 480.0)
	pix_mat.set_shader_parameter("levels", 14.0 if m == 2 else 40.0)
	pix_mat.set_shader_parameter("dither", 0.9 if m == 2 else 0.4)

# Тропа и указатель от дороги к дому
func _build_path(parent: Node3D, site: Vector2) -> void:
	var rz := road_z(site.x)
	var side := 1.0 if site.y > rz else -1.0
	var z_start := site.y - side * 4.5
	var z_end := rz + side * 3.2
	var verts := PackedVector3Array()
	var normals := PackedVector3Array()
	var idx := PackedInt32Array()
	var n := 8
	for i in n + 1:
		var z := lerpf(z_start, z_end, float(i) / n)
		for dx in [-0.8, 0.8]:
			var x: float = site.x + dx
			verts.append(Vector3(x, ground_h(x, z) + 0.05, z))
			normals.append(Vector3.UP)
	for i in n:
		var a := i * 2
		idx.append_array(PackedInt32Array([a, a + 2, a + 1, a + 1, a + 2, a + 3]))
	var arr := []
	arr.resize(Mesh.ARRAY_MAX)
	arr[Mesh.ARRAY_VERTEX] = verts
	arr[Mesh.ARRAY_NORMAL] = normals
	arr[Mesh.ARRAY_INDEX] = idx
	var m := ArrayMesh.new()
	m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)
	var mi := MeshInstance3D.new()
	mi.mesh = m
	mi.material_override = path_mat
	parent.add_child(mi)

func _build_sign(parent: Node3D, site: Vector2, label: String) -> void:
	var sx := site.x - 3.0
	var rz := road_z(sx)
	var side := 1.0 if site.y > road_z(site.x) else -1.0
	var sign_root := Node3D.new()
	sign_root.position = Vector3(sx, ground_h(sx, rz + side * 4.4), rz + side * 4.4)
	sign_root.rotation.y = -atan2(road_dz(sx), 1.0) + PI / 2.0
	parent.add_child(sign_root)
	_cyl(sign_root, Vector3(0, 0.8, 0), 0.06, 1.6, wood_mat, Vector3.ZERO, 6)
	_box(sign_root, Vector3(0, 1.5, 0), Vector3(1.3, 0.45, 0.05), wood_mat)
	var lb := Label3D.new()
	lb.text = label + "\n%d м" % int(Vector2(site.x - sx, site.y - rz).length())
	lb.font_size = 40
	lb.pixel_size = 0.0045
	lb.modulate = Color(0.85, 0.8, 0.65)
	lb.position = Vector3(0, 1.5, 0.04)
	sign_root.add_child(lb)


# ---------- цель, ремонт, финал, режиссёр встреч ----------
func objective() -> String:
	if player == null:
		return ""
	if taken.has("ended"):
		return "Лес не отпустил тебя. Исследуй дальше."
	if not (player.inv_count("map") > 0 or taken.has("car_map")):
		return "Осмотри машину. Найди карту."
	if not taken.has("seen_c0"):
		return "Иди по дороге на восток. Найди укрытие (знак «УКРЫТИЕ»)."
	var f: bool = player.inv_count("fuel") > 0
	var u: bool = player.inv_count("fuse") > 0
	var a: bool = player.inv_count("accu") > 0
	if f and u and a:
		return "Вернись к машине (на запад) и почини её. Это будет шумно."
	var ys := "есть"
	var no := "нет"
	return "Найди детали для машины. Канистра: %s. Предохранитель: %s. Аккумулятор: %s. Дома — на восток по дороге." % [ys if f else no, ys if u else no, ys if a else no]

func try_repair() -> void:
	if repairing or taken.has("ended") or caught_busy:
		return
	var f: bool = player.inv_count("fuel") > 0
	var u: bool = player.inv_count("fuse") > 0
	var a: bool = player.inv_count("accu") > 0
	if not (f and u and a):
		var miss: Array = []
		if not f:
			miss.append("канистра")
		if not u:
			miss.append("предохранитель")
		if not a:
			miss.append("аккумулятор")
		ui.toast("Двигатель мёртв. Не хватает: " + ", ".join(miss))
		return
	repairing = true
	ui.toast("Ты чинишь машину. Не отходи. Это шумно...")
	for i in 7:
		await get_tree().create_timer(2.0).timeout
		if caught_busy:
			repairing = false
			return
		if player.global_position.distance_to(car_pos) > 9.0:
			repairing = false
			ui.toast("Ты отошёл от машины. Ремонт прерван")
			return
		make_noise(car_pos, 280.0)
		play3d(Synth.thump(0.25, 150.0, 40.0, 0.6), car_pos + Vector3(0, 1, 0), 2.0, 250.0, 12.0, "SFX", randf_range(0.8, 1.2))
		if i == 3:
			creature.hear(car_pos, 600.0)
	repairing = false
	_ending()

func _ending() -> void:
	caught_busy = true
	player.control = false
	var tw := create_tween()
	tw.tween_property(ui, "fade", 1.0, 3.0)
	play3d(Synth.thump(2.5, 48.0, 1.1, 0.9), car_pos + Vector3(0, 1, 0), 4.0, 200.0, 10.0, "SFX", 1.0)
	await get_tree().create_timer(3.5).timeout
	var lines := ["Мотор завёлся с третьей попытки.", "Дорога потянулась сквозь туман.", "Позади что-то огромное повернулось на звук.", "На обочине стоял знак: «ДЕНЬ 1»."]
	for l in lines:
		ui.msg = String(l)
		await get_tree().create_timer(4.5).timeout
	ui.msg = "КОНЕЦ?"
	await get_tree().create_timer(4.0).timeout
	ui.msg = ""
	taken["ended"] = true
	player.inv_remove("fuel", 1)
	player.inv_remove("fuse", 1)
	player.inv_remove("accu", 1)
	caught_busy = false
	save_game()
	create_tween().tween_property(ui, "fade", 0.0, 3.0)
	ui.toast("Лес не отпустил тебя. Он продолжается.")

# Режиссёр: время от времени существо проходит мимо игрока на расстоянии (видны ноги в тумане)
func director_pass() -> void:
	dir_t = randf_range(240.0, 420.0)
	if player.inside or caught_busy or creature == null:
		dir_t = 40.0
		return
	var a := randf() * TAU
	var pp: Vector3 = player.global_position
	var d := Vector3(cos(a), 0, sin(a))
	var lat := Vector3(-d.z, 0, d.x) * randf_range(45.0, 75.0) * (1.0 if randf() < 0.5 else -1.0)
	creature.flyby(pp + d * 300.0, lat)

# Особые детали у домов по дороге (у каждого свой характер)
func _theme_props(cab: Node3D, idx: int) -> void:
	if idx == 0:
		_box(cab, Vector3(2.5, 0.25, 4.3), Vector3(1.6, 0.08, 0.4), wood_mat)
		_box(cab, Vector3(1.8, 0.12, 4.3), Vector3(0.08, 0.24, 0.35), wood_mat)
		_box(cab, Vector3(3.2, 0.12, 4.3), Vector3(0.08, 0.24, 0.35), wood_mat)
	elif idx == 1:
		_box(cab, Vector3(0.0, 0.45, -2.3), Vector3(2.0, 0.9, 0.7), wood_mat, true)
		_box(cab, Vector3(0.0, 0.93, -2.3), Vector3(2.1, 0.06, 0.75), dark_mat)
		_make_item(cab, Vector3(-0.5, 1.08, -2.3), "fuel", "q_fuel")
		for i in 3:
			_box(cab, Vector3(-3.3, 0.3 + i * 0.6, 0.6), Vector3(0.8, 0.6, 0.8), wood_mat, i == 0)
		for i in 3:
			_cyl(cab, Vector3(2.4 + i * 0.7, 0.5, 4.7), 0.3, 1.0, rust_mat, Vector3.ZERO, 10)
	elif idx == 2:
		for i in 3:
			_box(cab, Vector3(-3.0 + i * 0.6, 1.7, -2.88), Vector3(0.35, 0.45, 0.03), paper_mat)
		_box(cab, Vector3(-3.3, 0.45, 0.6), Vector3(0.8, 0.9, 0.8), dark_mat, true)
		_cyl(cab, Vector3(-3.3, 2.0, 0.6), 0.1, 2.2, rust_mat, Vector3.ZERO, 8)
	elif idx == 3:
		_box(cab, Vector3(-0.6, 0.4, -2.3), Vector3(2.4, 0.8, 0.8), wood_mat, true)
		for i in 3:
			_box(cab, Vector3(-1.3 + i * 0.7, 0.93, -2.3), Vector3(0.5, 0.25, 0.3), dark_mat)
		_make_item(cab, Vector3(0.35, 0.95, -2.3), "accu", "q_accu")
		_cyl(cab, Vector3(3.0, 7.0, -4.5), 0.08, 14.0, rust_mat, Vector3.ZERO, 6)
		_box(cab, Vector3(3.0, 11.0, -4.5), Vector3(1.6, 0.05, 0.05), rust_mat)
		_box(cab, Vector3(3.0, 9.0, -4.5), Vector3(1.0, 0.05, 0.05), rust_mat)

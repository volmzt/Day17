extends Control
# Сенсорное управление + минимальный HUD, всё рисуется в одном месте.
signal flash_pressed
signal battery_pressed
signal menu_pressed
var player
var move := Vector2.ZERO
var look_acc := Vector2.ZERO
var interact_held := false
var prompt := ""
var note := ""
var toast_text := ""
var toast_t := 0.0
var fade := 1.0
var msg := ""
var hud_a := 0.0
var hud_t := 0.0
var roles := {}
var j_origin := Vector2.ZERO
var j_pos := Vector2.ZERO
var j_active := false
const JR := 110.0

func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func toast(t: String) -> void:
	toast_text = t
	toast_t = 3.0

func show_hud() -> void:
	hud_t = 3.0

func consume_look() -> Vector2:
	var v := look_acc
	look_acc = Vector2.ZERO
	return v

func _buttons() -> Dictionary:
	return {
		"interact": [Vector2(size.x - 140, size.y - 140), 70.0, "ДЕЙСТВИЕ"],
		"flash": [Vector2(size.x - 300, size.y - 90), 48.0, "СВЕТ"],
		"battery": [Vector2(size.x - 300, size.y - 205), 42.0, "БАТАРЕЯ"],
		"menu": [Vector2(size.x - 50, 50), 30.0, "II"],
	}

func _input(e: InputEvent) -> void:
	if e is InputEventScreenTouch:
		if e.pressed:
			_down(e.index, e.position)
		else:
			_up(e.index)
	elif e is InputEventScreenDrag:
		var r = roles.get(e.index, "")
		if r == "move":
			j_pos = e.position
			move = ((j_pos - j_origin) / JR).limit_length(1.0)
		elif r == "look":
			look_acc += e.relative

func _down(idx: int, p: Vector2) -> void:
	if note != "":
		note = ""
		roles[idx] = "none"
		return
	var b := _buttons()
	for k in b:
		if p.distance_to(b[k][0]) < b[k][1] + 12.0:
			roles[idx] = k
			match k:
				"interact":
					interact_held = true
				"flash":
					flash_pressed.emit()
				"battery":
					battery_pressed.emit()
				"menu":
					menu_pressed.emit()
			return
	if p.x < size.x * 0.45:
		roles[idx] = "move"
		j_origin = p
		j_pos = p
		j_active = true
		move = Vector2.ZERO
	else:
		roles[idx] = "look"

func _up(idx: int) -> void:
	var r = roles.get(idx, "")
	if r == "move":
		move = Vector2.ZERO
		j_active = false
	elif r == "interact":
		interact_held = false
	roles.erase(idx)

func _process(delta: float) -> void:
	toast_t = maxf(0.0, toast_t - delta)
	hud_t = maxf(0.0, hud_t - delta)
	var want := 0.0
	if player and (hud_t > 0.0 or player.stamina < 0.95 or player.battery < 0.25):
		want = 1.0
	hud_a = move_toward(hud_a, want, delta * 2.0)
	queue_redraw()

func _draw() -> void:
	var font := ThemeDB.fallback_font
	if j_active:
		draw_circle(j_origin, JR, Color(1, 1, 1, 0.05))
		draw_arc(j_origin, JR, 0, TAU, 32, Color(1, 1, 1, 0.18), 2.0)
		draw_circle(j_origin + (j_pos - j_origin).limit_length(JR), 38.0, Color(1, 1, 1, 0.16))
	var b := _buttons()
	for k in b:
		var c: Vector2 = b[k][0]
		var held: bool = (k == "interact" and interact_held)
		draw_circle(c, b[k][1], Color(0.75, 0.8, 0.78, 0.22 if held else 0.1))
		draw_arc(c, b[k][1], 0, TAU, 28, Color(0.8, 0.85, 0.82, 0.3), 2.0)
		draw_string(font, c + Vector2(-b[k][1], 6), b[k][2], HORIZONTAL_ALIGNMENT_CENTER, b[k][1] * 2.0, 15, Color(0.85, 0.9, 0.88, 0.6))
	if hud_a > 0.01 and player:
		draw_rect(Rect2(40, 40, 200, 5), Color(1, 1, 1, 0.1 * hud_a))
		draw_rect(Rect2(40, 40, 200 * player.stamina, 5), Color(0.7, 0.75, 0.6, 0.6 * hud_a))
		draw_rect(Rect2(40, 54, 200, 5), Color(1, 1, 1, 0.1 * hud_a))
		draw_rect(Rect2(40, 54, 200 * player.battery, 5), Color(0.85, 0.8, 0.5, 0.6 * hud_a))
		draw_string(font, Vector2(40, 82), "Батарей: %d" % player.spare_batteries, HORIZONTAL_ALIGNMENT_LEFT, -1, 16, Color(0.8, 0.8, 0.75, 0.6 * hud_a))
	if prompt != "":
		draw_string(font, Vector2(0, size.y - 60), prompt + "  (держите — тихо)", HORIZONTAL_ALIGNMENT_CENTER, size.x, 22, Color(0.85, 0.85, 0.8, 0.75))
	if toast_t > 0.0:
		draw_string(font, Vector2(0, size.y * 0.3), toast_text, HORIZONTAL_ALIGNMENT_CENTER, size.x, 22, Color(0.85, 0.85, 0.8, minf(1.0, toast_t)))
	if note != "":
		var r := Rect2(size.x * 0.15, size.y * 0.12, size.x * 0.7, size.y * 0.7)
		draw_rect(r, Color(0.72, 0.66, 0.52, 0.94))
		draw_multiline_string(font, r.position + Vector2(30, 50), note, HORIZONTAL_ALIGNMENT_LEFT, r.size.x - 60, 26, -1, Color(0.1, 0.08, 0.05))
		draw_string(font, Vector2(r.position.x, r.end.y - 14), "(коснитесь, чтобы закрыть)", HORIZONTAL_ALIGNMENT_CENTER, r.size.x, 16, Color(0.2, 0.15, 0.1, 0.8))
	if fade > 0.001:
		draw_rect(Rect2(Vector2.ZERO, size), Color(0, 0, 0, fade))
	if msg != "":
		draw_string(font, Vector2(0, size.y * 0.5), msg, HORIZONTAL_ALIGNMENT_CENTER, size.x, 30, Color(0.8, 0.8, 0.78, minf(1.0, fade * 2.0)))

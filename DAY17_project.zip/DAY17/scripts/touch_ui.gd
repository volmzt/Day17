extends Control
# Сенсорное управление + минимальный HUD. Кнопка «действие» появляется рядом с предметом.
signal flash_pressed
signal battery_pressed
signal menu_pressed
signal crouch_pressed
signal bag_pressed
signal map_pressed
var player
var move := Vector2.ZERO
var look_acc := Vector2.ZERO
var interact_held := false
var interact_vis := false
var interact_pos := Vector2.ZERO
var hold_ratio := 0.0
var prompt := ""
var note := ""
var toast_text := ""
var toast_t := 0.0
var fade := 1.0
var msg := ""
var hud_a := 0.0
var hud_t := 0.0
var blocked := false
var roles := {}
var j_origin := Vector2.ZERO
var j_pos := Vector2.ZERO
var j_active := false
var hint_t := 14.0
var objective := ""
const JR := 110.0

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_fit()

func _fit() -> void:
	position = Vector2.ZERO
	size = get_viewport().get_visible_rect().size

func toast(t: String) -> void:
	toast_text = t
	toast_t = 3.0

func show_hud() -> void:
	hud_t = 3.0

func consume_look() -> Vector2:
	var v := look_acc
	look_acc = Vector2.ZERO
	return v

func _buttons() -> Dictionary:
	var d := {
		"flash": [Vector2(size.x - 110, size.y - 95), 46.0, "СВЕТ"],
		"crouch": [Vector2(size.x - 235, size.y - 85), 42.0, "ПРИСЕСТЬ"],
		"bag": [Vector2(size.x - 110, size.y - 215), 42.0, "РЮКЗАК"],
		"map": [Vector2(size.x - 235, size.y - 200), 42.0, "КАРТА"],
		"menu": [Vector2(size.x - 50, 50), 30.0, "II"],
	}
	if player != null and player.battery < 0.25 and player.spare_batteries > 0:
		d["battery"] = [Vector2(size.x - 360, size.y - 90), 40.0, "БАТАРЕЯ"]
	return d

func _input(e: InputEvent) -> void:
	if blocked:
		return
	if e is InputEventScreenTouch:
		if e.pressed:
			_down(e.index, e.position)
		else:
			_up(e.index)
	elif e is InputEventScreenDrag:
		var r = roles.get(e.index, "")
		if r == "move":
			j_pos = e.position
			move = ((j_pos - j_origin) / JR).limit_length(1.0)
		elif r == "look":
			look_acc += e.relative

func _down(idx: int, p: Vector2) -> void:
	if note != "":
		note = ""
		roles[idx] = "none"
		return
	if interact_vis and p.distance_to(interact_pos) < 76.0:
		roles[idx] = "interact"
		interact_held = true
		return
	var b := _buttons()
	for k in b:
		if p.distance_to(b[k][0]) < b[k][1] + 12.0:
			roles[idx] = k
			if k == "flash":
				flash_pressed.emit()
			elif k == "battery":
				battery_pressed.emit()
			elif k == "menu":
				menu_pressed.emit()
			elif k == "crouch":
				crouch_pressed.emit()
			elif k == "bag":
				bag_pressed.emit()
			elif k == "map":
				map_pressed.emit()
			return
	if p.x < size.x * 0.45:
		roles[idx] = "move"
		j_origin = p
		j_pos = p
		j_active = true
		move = Vector2.ZERO
	else:
		roles[idx] = "look"

func _up(idx: int) -> void:
	var r = roles.get(idx, "")
	if r == "move":
		move = Vector2.ZERO
		j_active = false
	elif r == "interact":
		interact_held = false
	roles.erase(idx)

func _process(delta: float) -> void:
	_fit()
	if blocked:
		move = Vector2.ZERO
		j_active = false
		interact_held = false
	hint_t = maxf(0.0, hint_t - delta)
	toast_t = maxf(0.0, toast_t - delta)
	hud_t = maxf(0.0, hud_t - delta)
	var want := 0.0
	if player and (hud_t > 0.0 or player.stamina < 0.95 or player.battery < 0.25):
		want = 1.0
	hud_a = move_toward(hud_a, want, delta * 2.0)
	queue_redraw()

func _draw() -> void:
	var font := ThemeDB.fallback_font
	if not blocked:
		if j_active:
			draw_circle(j_origin, JR, Color(1, 1, 1, 0.05))
			draw_arc(j_origin, JR, 0, TAU, 32, Color(1, 1, 1, 0.18), 2.0)
			draw_circle(j_origin + (j_pos - j_origin).limit_length(JR), 38.0, Color(1, 1, 1, 0.16))
		else:
			var hc := Vector2(190, size.y - 170)
			draw_arc(hc, JR, 0, TAU, 40, Color(1, 1, 1, 0.14), 3.0)
			draw_circle(hc, 36.0, Color(1, 1, 1, 0.07))
			draw_string(font, hc + Vector2(-JR, JR + 28), "ДВИЖЕНИЕ (тяни влево)", HORIZONTAL_ALIGNMENT_CENTER, JR * 2.0, 15, Color(1, 1, 1, 0.35))
		if hint_t > 0.0:
			draw_string(font, Vector2(size.x * 0.25, size.y * 0.5), "ОБЗОР — вести пальцем по правой стороне", HORIZONTAL_ALIGNMENT_CENTER, size.x * 0.5, 18, Color(1, 1, 1, 0.3 * minf(1.0, hint_t)))
		var b := _buttons()
		for k in b:
			var c: Vector2 = b[k][0]
			draw_circle(c, b[k][1], Color(0.75, 0.8, 0.78, 0.1))
			draw_arc(c, b[k][1], 0, TAU, 28, Color(0.8, 0.85, 0.82, 0.3), 2.0)
			draw_string(font, c + Vector2(-b[k][1], 5), b[k][2], HORIZONTAL_ALIGNMENT_CENTER, b[k][1] * 2.0, 13, Color(0.85, 0.9, 0.88, 0.6))
		if interact_vis:
			var held := interact_held
			draw_circle(interact_pos, 62.0, Color(0.9, 0.92, 0.8, 0.22 if held else 0.12))
			draw_arc(interact_pos, 62.0, 0, TAU, 32, Color(0.95, 0.95, 0.85, 0.65), 3.0)
			if held and hold_ratio > 0.0:
				var col := Color(0.6, 0.9, 0.7, 0.9) if hold_ratio >= 1.0 else Color(1, 1, 1, 0.6)
				draw_arc(interact_pos, 70.0, -PI / 2.0, -PI / 2.0 + TAU * hold_ratio, 32, col, 4.0)
			draw_string(font, interact_pos + Vector2(-62, 7), prompt, HORIZONTAL_ALIGNMENT_CENTER, 124.0, 19, Color(0.95, 0.95, 0.9, 0.9))
			draw_string(font, interact_pos + Vector2(-90, 96), "тап — громко, держи — тихо", HORIZONTAL_ALIGNMENT_CENTER, 180.0, 13, Color(1, 1, 1, 0.4))
	if hud_a > 0.01 and player:
		draw_rect(Rect2(40, 40, 200, 5), Color(1, 1, 1, 0.1 * hud_a))
		draw_rect(Rect2(40, 40, 200 * player.stamina, 5), Color(0.7, 0.75, 0.6, 0.6 * hud_a))
		draw_rect(Rect2(40, 54, 200, 5), Color(1, 1, 1, 0.1 * hud_a))
		draw_rect(Rect2(40, 54, 200 * player.battery, 5), Color(0.85, 0.8, 0.5, 0.6 * hud_a))
		draw_string(font, Vector2(40, 82), "Батарей: %d" % player.spare_batteries, HORIZONTAL_ALIGNMENT_LEFT, -1, 16, Color(0.8, 0.8, 0.75, 0.6 * hud_a))
	if objective != "" and not blocked and note == "":
		draw_multiline_string(font, Vector2(40, 118), "▸ " + objective, HORIZONTAL_ALIGNMENT_LEFT, size.x * 0.4, 17, 3, Color(0.85, 0.85, 0.7, 0.55))
	if toast_t > 0.0:
		draw_string(font, Vector2(0, size.y * 0.3), toast_text, HORIZONTAL_ALIGNMENT_CENTER, size.x, 22, Color(0.85, 0.85, 0.8, minf(1.0, toast_t)))
	if note != "":
		var r := Rect2(size.x * 0.15, size.y * 0.12, size.x * 0.7, size.y * 0.7)
		draw_rect(r, Color(0.72, 0.66, 0.52, 0.94))
		draw_multiline_string(font, r.position + Vector2(30, 50), note, HORIZONTAL_ALIGNMENT_LEFT, r.size.x - 60, 26, -1, Color(0.1, 0.08, 0.05))
		draw_string(font, Vector2(r.position.x, r.end.y - 14), "(коснитесь, чтобы закрыть)", HORIZONTAL_ALIGNMENT_CENTER, r.size.x, 16, Color(0.2, 0.15, 0.1, 0.8))
	if fade > 0.001:
		draw_rect(Rect2(Vector2.ZERO, size), Color(0, 0, 0, fade))
	if msg != "":
		draw_string(font, Vector2(0, size.y * 0.5), msg, HORIZONTAL_ALIGNMENT_CENTER, size.x, 30, Color(0.8, 0.8, 0.78, minf(1.0, fade * 2.0)))

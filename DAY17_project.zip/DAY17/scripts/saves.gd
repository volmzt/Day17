extends RefCounted
# Слоты сохранения (3 слота)
const SLOTS := 3
static var last_slot := 1

static func path(i: int) -> String:
	return "user://day17_slot%d.json" % i

static func exists(i: int) -> bool:
	return FileAccess.file_exists(path(i))

static func read(i: int) -> Dictionary:
	if not exists(i):
		return {}
	var f := FileAccess.open(path(i), FileAccess.READ)
	if f == null:
		return {}
	var d = JSON.parse_string(f.get_as_text())
	if d is Dictionary:
		return d
	return {}

static func write(i: int, d: Dictionary) -> void:
	d["ts"] = Time.get_datetime_string_from_system(false, true)
	d["unix"] = Time.get_unix_time_from_system()
	var f := FileAccess.open(path(i), FileAccess.WRITE)
	if f != null:
		f.store_string(JSON.stringify(d))
	last_slot = i

static func label(i: int) -> String:
	if not exists(i):
		return "СЛОТ %d — пусто" % i
	var d := read(i)
	return "СЛОТ %d — %s" % [i, str(d.get("ts", "?"))]

static func any_exists() -> bool:
	for i in range(1, SLOTS + 1):
		if exists(i):
			return true
	return false

static func latest() -> int:
	var best := 0
	var bt := -1.0
	for i in range(1, SLOTS + 1):
		if exists(i):
			var u := float(read(i).get("unix", 0.0))
			if u >= bt:
				bt = u
				best = i
	return best

extends Node3D
var kind := "note"
var prompt := "Взять"
var text := ""
var world
var pivot: Node3D
var open := false
var busy := false
var snd: AudioStreamPlayer3D

func _ready() -> void:
	add_to_group("interact")
	if kind == "door":
		snd = AudioStreamPlayer3D.new()
		snd.bus = "SFX"
		snd.stream = world.creak_stream
		snd.max_distance = 60.0
		add_child(snd)

func interact(player, slow: bool) -> void:
	match kind:
		"door":
			_toggle(slow)
		"battery":
			player.add_battery()
			queue_free()
		"note":
			player.show_note(text)
		"bed":
			player.rest()

func _toggle(slow: bool) -> void:
	if busy:
		return
	busy = true
	open = not open
	var dur := 3.2 if slow else 0.9
	snd.pitch_scale = 0.6 if slow else randf_range(0.9, 1.1)
	snd.volume_db = -14.0 if slow else 0.0
	snd.play()
	world.make_noise(global_position, 28.0 if slow else 130.0)
	var tw := create_tween()
	tw.tween_property(pivot, "rotation:y", 1.75 if open else 0.0, dur)
	tw.finished.connect(func(): busy = false)

extends Node3D
# Универсальный объект взаимодействия: дверь, предмет, записка, кровать, контейнер, радио
const Synth = preload("res://scripts/synth.gd")
const Items = preload("res://scripts/items.gd")
var kind := "note"
var prompt := "Взять"
var text := ""
var world
var pivot: Node3D
var open := false
var busy := false
var snd: AudioStreamPlayer3D
var item_id := ""
var uid := ""
var locked := false
var loot: Array = []
var radio_on := false
var radio_p: AudioStreamPlayer3D
var radio_t := 0.0

func _ready() -> void:
	add_to_group("interact")
	if kind == "door" or kind == "container":
		snd = AudioStreamPlayer3D.new()
		snd.bus = "SFX"
		snd.stream = world.creak_stream
		snd.max_distance = 60.0
		add_child(snd)
	if kind == "radio":
		radio_p = AudioStreamPlayer3D.new()
		radio_p.bus = "SFX"
		radio_p.stream = world.get_radio_stream()
		radio_p.max_distance = 40.0
		radio_p.unit_size = 4.0
		radio_p.volume_db = -8.0
		add_child(radio_p)

func _process(delta: float) -> void:
	if kind == "radio" and radio_on:
		radio_t -= delta
		if radio_t <= 0.0:
			radio_t = 6.0
			world.make_noise(global_position, 70.0)
		if world.player != null:
			radio_p.volume_db = -8.0 + 10.0 * clampf(world.player.tension, 0.0, 1.0)

func interact(player, slow: bool) -> void:
	if kind == "door":
		_door(player, slow)
	elif kind == "item":
		_item(player)
	elif kind == "note":
		player.show_note(text)
	elif kind == "bed":
		player.rest()
	elif kind == "container":
		_container(player, slow)
	elif kind == "radio":
		radio_on = not radio_on
		if radio_on:
			radio_p.play()
			player.ui.toast("Радио шипит...")
		else:
			radio_p.stop()
		player.click.play()

func _item(player) -> void:
	if player.inv_add(item_id, 1):
		world.taken[uid] = true
		player.ui.toast("Взято: " + String(Items.ITEMS[item_id]["name"]))
		player.sfx_pick()
		queue_free()
	else:
		player.ui.toast("Рюкзак полон")

func _container(player, slow: bool) -> void:
	if world.taken.has(uid):
		player.ui.toast("Пусто")
		return
	snd.pitch_scale = 0.6 if slow else randf_range(0.9, 1.1)
	snd.volume_db = -14.0 if slow else -2.0
	snd.play()
	world.make_noise(global_position, 14.0 if slow else 55.0)
	var left: Array = []
	var got: Array = []
	for l in loot:
		if player.inv_add(String(l[0]), int(l[1])):
			got.append(String(Items.ITEMS[l[0]]["name"]))
		else:
			left.append(l)
	loot = left
	if left.size() == 0:
		world.taken[uid] = true
	if got.size() > 0:
		player.ui.toast("Найдено: " + ", ".join(got))
	elif left.size() > 0:
		player.ui.toast("Рюкзак полон")
	else:
		player.ui.toast("Пусто")

func _door(player, slow: bool) -> void:
	if locked:
		if player.inv_count("key") > 0:
			player.inv_remove("key", 1)
			locked = false
			world.taken["unlock_" + uid] = true
			player.ui.toast("Ты открыл замок")
			player.click.play()
		else:
			player.ui.toast("Заперто. Нужен ключ")
			world.make_noise(global_position, 20.0)
		return
	if busy:
		return
	busy = true
	open = not open
	var dur := 3.2 if slow else 0.9
	snd.pitch_scale = 0.6 if slow else randf_range(0.9, 1.1)
	snd.volume_db = -14.0 if slow else 0.0
	snd.play()
	world.make_noise(global_position, 28.0 if slow else 130.0)
	var tw := create_tween()
	tw.tween_property(pivot, "rotation:y", 1.75 if open else 0.0, dur)
	tw.finished.connect(func(): busy = false)

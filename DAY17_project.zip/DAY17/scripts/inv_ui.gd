extends Control
# Рюкзак: сетка слотов, описание, использовать/выбросить, состояние героя.
const Items = preload("res://scripts/items.gd")
var player
var open := false
var open_t := 0.0
var sel := -1
var slot_rects: Array = []
var use_rect := Rect2()
var drop_rect := Rect2()
var close_rect := Rect2()

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	visible = false

func toggle() -> void:
	open = not open
	if open:
		sel = -1
		if player != null:
			player.sfx_rustle()

func _process(delta: float) -> void:
	position = Vector2.ZERO
	size = get_viewport().get_visible_rect().size
	open_t = move_toward(open_t, 1.0 if open else 0.0, delta * 3.5)
	visible = open_t > 0.01
	if visible:
		queue_redraw()

func _layout() -> void:
	var w := size.x
	var h := size.y
	var oy := (1.0 - open_t) * h * 0.25
	var s := minf((w * 0.55 - 60.0) / 4.0 - 12.0, (h - 280.0) / 2.0 - 12.0)
	slot_rects.clear()
	for i in Items.SLOTS:
		var col := i % 4
		var row := i / 4
		slot_rects.append(Rect2(60.0 + col * (s + 12.0), 160.0 + oy + row * (s + 12.0), s, s))
	var rx := w * 0.6
	use_rect = Rect2(rx, h - 190.0 + oy, 220.0, 64.0)
	drop_rect = Rect2(rx + 240.0, h - 190.0 + oy, 220.0, 64.0)
	close_rect = Rect2(w - 190.0, 30.0 + oy, 150.0, 56.0)

func _input(e: InputEvent) -> void:
	if not open or player == null:
		return
	if e is InputEventScreenTouch and e.pressed:
		_layout()
		var p: Vector2 = e.position
		if close_rect.has_point(p):
			toggle()
			return
		for i in slot_rects.size():
			if slot_rects[i].has_point(p):
				sel = i
				return
		if sel >= 0 and sel < player.inv.size():
			var id := String(player.inv[sel]["id"])
			if use_rect.has_point(p):
				player.use_item(id)
				if sel >= player.inv.size():
					sel = -1
			elif drop_rect.has_point(p):
				player.drop_item(id)
				if sel >= player.inv.size():
					sel = -1

func _word(v: float, a: String, b: String, c: String) -> String:
	if v > 0.6:
		return a
	if v > 0.3:
		return b
	return c

func _draw() -> void:
	_layout()
	var font := ThemeDB.fallback_font
	var w := size.x
	var h := size.y
	var oy := (1.0 - open_t) * h * 0.25
	draw_rect(Rect2(0, 0, w, h), Color(0.02, 0.025, 0.03, 0.86 * open_t))
	var ink := Color(0.85, 0.87, 0.82, open_t)
	draw_string(font, Vector2(60, 70 + oy), "РЮКЗАК", HORIZONTAL_ALIGNMENT_LEFT, 400, 40, ink)
	draw_string(font, Vector2(60, 112 + oy), "Вес: %.1f / %.0f кг    Слоты: %d / %d" % [player.inv_weight(), Items.MAX_W, player.inv.size(), Items.SLOTS], HORIZONTAL_ALIGNMENT_LEFT, 700, 22, Color(0.65, 0.68, 0.64, open_t))
	if player.ui != null and player.ui.objective != "":
		draw_string(font, Vector2(60, 140 + oy), "Цель: " + player.ui.objective, HORIZONTAL_ALIGNMENT_LEFT, w * 0.55, 18, Color(0.85, 0.82, 0.6, open_t))
	for i in slot_rects.size():
		var r: Rect2 = slot_rects[i]
		var chosen := (i == sel)
		draw_rect(r, Color(0.12, 0.13, 0.13, 0.9 * open_t))
		draw_rect(r, Color(0.7, 0.72, 0.65, (0.9 if chosen else 0.25) * open_t), false, 3.0 if chosen else 1.5)
		if i < player.inv.size():
			var it: Dictionary = player.inv[i]
			_icon(String(it["id"]), r.get_center() + Vector2(0, -10), r.size.x * 0.28)
			var nm: String = Items.ITEMS[it["id"]]["name"]
			draw_string(font, Vector2(r.position.x, r.end.y - 12), nm, HORIZONTAL_ALIGNMENT_CENTER, r.size.x, 17, ink)
			if int(it["n"]) > 1:
				draw_string(font, Vector2(r.end.x - 40, r.position.y + 26), "x%d" % int(it["n"]), HORIZONTAL_ALIGNMENT_RIGHT, 32, 20, ink)
	# состояние
	var sy: float = float(slot_rects[4].end.y) + 44.0
	var lines := [
		"Здоровье: " + _word(player.health, "в порядке", "ранен", "плохо"),
		"Голод: " + _word(player.hunger, "сыт", "голоден", "очень голоден"),
		"Жажда: " + _word(player.thirst, "не хочется пить", "хочется пить", "мучает жажда"),
		"Усталость: " + _word(1.0 - player.fatigue, "бодр", "устал", "измотан"),
	]
	for i in lines.size():
		draw_string(font, Vector2(60, sy + i * 30.0), lines[i], HORIZONTAL_ALIGNMENT_LEFT, 600, 22, Color(0.7, 0.73, 0.68, open_t))
	# описание
	var rx := w * 0.6
	if sel >= 0 and sel < player.inv.size():
		var id := String(player.inv[sel]["id"])
		var d: Dictionary = Items.ITEMS[id]
		draw_string(font, Vector2(rx, 190 + oy), String(d["name"]), HORIZONTAL_ALIGNMENT_LEFT, 500, 32, ink)
		draw_string(font, Vector2(rx, 222 + oy), "%s · %.1f кг" % [String(d["cat"]), float(d["w"])], HORIZONTAL_ALIGNMENT_LEFT, 500, 18, Color(0.6, 0.63, 0.6, open_t))
		draw_multiline_string(font, Vector2(rx, 262 + oy), String(d["desc"]), HORIZONTAL_ALIGNMENT_LEFT, w * 0.36, 22, -1, Color(0.8, 0.82, 0.78, open_t))
		draw_rect(use_rect, Color(0.2, 0.24, 0.2, 0.9 * open_t))
		draw_string(font, use_rect.position + Vector2(0, 41), String(d["use"]).to_upper(), HORIZONTAL_ALIGNMENT_CENTER, use_rect.size.x, 22, ink)
		draw_rect(drop_rect, Color(0.24, 0.18, 0.16, 0.9 * open_t))
		draw_string(font, drop_rect.position + Vector2(0, 41), "ВЫБРОСИТЬ", HORIZONTAL_ALIGNMENT_CENTER, drop_rect.size.x, 22, ink)
	else:
		draw_string(font, Vector2(rx, 200 + oy), "Выбери предмет", HORIZONTAL_ALIGNMENT_LEFT, 500, 24, Color(0.55, 0.58, 0.55, open_t))
	draw_rect(close_rect, Color(0.15, 0.15, 0.16, 0.9 * open_t))
	draw_string(font, close_rect.position + Vector2(0, 37), "НАЗАД", HORIZONTAL_ALIGNMENT_CENTER, close_rect.size.x, 22, ink)

func _icon(id: String, c: Vector2, s: float) -> void:
	var a := open_t
	if id == "battery":
		draw_rect(Rect2(c.x - s * 0.5, c.y - s * 0.8, s, s * 1.6), Color(0.3, 0.32, 0.3, a))
		draw_rect(Rect2(c.x - s * 0.2, c.y - s * 1.0, s * 0.4, s * 0.2), Color(0.75, 0.75, 0.7, a))
	elif id == "food":
		draw_rect(Rect2(c.x - s * 0.6, c.y - s * 0.6, s * 1.2, s * 1.2), Color(0.55, 0.3, 0.18, a))
		draw_rect(Rect2(c.x - s * 0.6, c.y - s * 0.2, s * 1.2, s * 0.35), Color(0.8, 0.75, 0.55, a))
	elif id == "water":
		draw_rect(Rect2(c.x - s * 0.35, c.y - s * 0.4, s * 0.7, s * 1.2), Color(0.45, 0.55, 0.62, a * 0.9))
		draw_rect(Rect2(c.x - s * 0.15, c.y - s * 0.8, s * 0.3, s * 0.4), Color(0.45, 0.55, 0.62, a))
	elif id == "bandage":
		draw_rect(Rect2(c.x - s * 0.7, c.y - s * 0.4, s * 1.4, s * 0.8), Color(0.85, 0.85, 0.8, a))
		draw_rect(Rect2(c.x - s * 0.1, c.y - s * 0.4, s * 0.2, s * 0.8), Color(0.6, 0.15, 0.12, a))
	elif id == "key":
		draw_circle(c + Vector2(-s * 0.4, 0), s * 0.35, Color(0.7, 0.6, 0.3, a))
		draw_rect(Rect2(c.x - s * 0.1, c.y - s * 0.08, s * 0.9, s * 0.16), Color(0.7, 0.6, 0.3, a))
		draw_rect(Rect2(c.x + s * 0.55, c.y, s * 0.12, s * 0.3), Color(0.7, 0.6, 0.3, a))
	elif id == "map":
		draw_rect(Rect2(c.x - s * 0.8, c.y - s * 0.55, s * 1.6, s * 1.1), Color(0.7, 0.62, 0.45, a))
		draw_line(Vector2(c.x - s * 0.8, c.y), Vector2(c.x + s * 0.8, c.y), Color(0.3, 0.2, 0.15, a), 2.0)
		draw_line(Vector2(c.x, c.y - s * 0.55), Vector2(c.x, c.y + s * 0.55), Color(0.3, 0.2, 0.15, a), 2.0)
	elif id == "compass":
		draw_circle(c, s * 0.7, Color(0.25, 0.25, 0.22, a))
		draw_circle(c, s * 0.55, Color(0.75, 0.75, 0.7, a))
		draw_line(c + Vector2(0, s * 0.4), c + Vector2(0, -s * 0.4), Color(0.7, 0.1, 0.1, a), 3.0)
	else:
		draw_circle(c, s * 0.5, Color(0.5, 0.5, 0.5, a))

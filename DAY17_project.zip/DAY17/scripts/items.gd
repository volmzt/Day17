extends RefCounted
# Предметы рюкзака
const SLOTS := 8
const MAX_W := 10.0
const ITEMS := {
	"battery": {"name": "Батарея", "desc": "Запасная батарея для фонарика. Хватает примерно на 20 минут.", "w": 0.1, "stack": 4, "cat": "ресурс", "use": "Вставить"},
	"food": {"name": "Консервы", "desc": "Банка тушёнки. Утоляет голод. Открывать тихо нельзя.", "w": 0.5, "stack": 3, "cat": "еда", "use": "Съесть"},
	"water": {"name": "Бутылка воды", "desc": "Чистая вода. Утоляет жажду.", "w": 0.7, "stack": 3, "cat": "вода", "use": "Выпить"},
	"bandage": {"name": "Бинт", "desc": "Чистый бинт. Восстанавливает здоровье.", "w": 0.1, "stack": 3, "cat": "медицина", "use": "Применить"},
	"key": {"name": "Ключ", "desc": "Ржавый ключ. Подходит к одной из запертых дверей.", "w": 0.1, "stack": 3, "cat": "ключ", "use": "Осмотреть"},
	"map": {"name": "Карта", "desc": "Старая бумажная карта. Показывает только то, что ты уже видел. Кнопка КАРТА достаёт её в руку.", "w": 0.1, "stack": 1, "cat": "навигация", "use": "Достать"},
	"compass": {"name": "Компас", "desc": "Показывает север и направление взгляда на карте.", "w": 0.2, "stack": 1, "cat": "навигация", "use": "Осмотреть"},
}
const LOOT := [["battery", 3], ["food", 3], ["water", 3], ["bandage", 2], ["key", 1], ["compass", 1]]

static func roll_loot(rng: RandomNumberGenerator, count: int) -> Array:
	var out: Array = []
	var total := 0
	for l in LOOT:
		total += int(l[1])
	for k in count:
		var r := rng.randi() % total
		var acc := 0
		for l in LOOT:
			acc += int(l[1])
			if r < acc:
				out.append([String(l[0]), 1])
				break
	return out

extends RefCounted
# Процедурные звуки: дождь, ветер, шаги, скрип, сердцебиение и т.д.
const RATE := 16000

static func _make(data: PackedByteArray, loop: bool) -> AudioStreamWAV:
	var st := AudioStreamWAV.new()
	st.format = AudioStreamWAV.FORMAT_16_BITS
	st.mix_rate = RATE
	st.stereo = false
	st.data = data
	if loop:
		st.loop_mode = AudioStreamWAV.LOOP_FORWARD
		st.loop_begin = 0
		st.loop_end = data.size() / 2
	return st

static func noise(seconds: float, lp: float, gain: float = 0.5, decay: float = 0.0, loop: bool = false) -> AudioStreamWAV:
	var n := int(seconds * RATE)
	var data := PackedByteArray()
	data.resize(n * 2)
	var y := 0.0
	var norm := sqrt((2.0 - lp) / lp) * 0.55
	for i in n:
		y += ((randf() * 2.0 - 1.0) - y) * lp
		var env := 1.0
		if decay > 0.0:
			env = exp(-float(i) / RATE * decay)
		data.encode_s16(i * 2, int(clampf(y * norm * gain * env, -1.0, 1.0) * 32000.0))
	return _make(data, loop)

static func thump(seconds: float, freq: float, decay: float, noise_amt: float = 0.3) -> AudioStreamWAV:
	var n := int(seconds * RATE)
	var data := PackedByteArray()
	data.resize(n * 2)
	var ph := 0.0
	var y := 0.0
	for i in n:
		var t := float(i) / RATE
		ph += TAU * freq * (1.0 - 0.35 * t / seconds) / RATE
		y += ((randf() * 2.0 - 1.0) - y) * 0.05
		var s := sin(ph) * exp(-t * decay) + y * 4.0 * noise_amt * exp(-t * decay * 1.5)
		data.encode_s16(i * 2, int(clampf(s, -1.0, 1.0) * 30000.0))
	return _make(data, false)

static func heartbeat() -> AudioStreamWAV:
	var n := int(0.8 * RATE)
	var data := PackedByteArray()
	data.resize(n * 2)
	for i in n:
		var t := float(i) / RATE
		var s := sin(TAU * 52.0 * t) * exp(-t * 16.0)
		var t2 := t - 0.28
		if t2 > 0.0:
			s += 0.7 * sin(TAU * 46.0 * t2) * exp(-t2 * 18.0)
		data.encode_s16(i * 2, int(clampf(s, -1.0, 1.0) * 30000.0))
	return _make(data, false)

static func creak(seconds: float) -> AudioStreamWAV:
	var n := int(seconds * RATE)
	var data := PackedByteArray()
	data.resize(n * 2)
	var ph := 0.0
	var y := 0.0
	for i in n:
		var t := float(i) / RATE
		var f := 170.0 + 140.0 * (0.5 + 0.5 * sin(t * 4.0)) + 30.0 * sin(t * 23.0)
		ph += TAU * f / RATE
		y += ((randf() * 2.0 - 1.0) - y) * 0.3
		var saw := fposmod(ph, TAU) / PI - 1.0
		var env := sin(PI * t / seconds)
		var s := (saw * 0.35 + sin(ph * 2.0) * 0.15 + y * 0.12) * env
		data.encode_s16(i * 2, int(clampf(s, -1.0, 1.0) * 26000.0))
	return _make(data, false)

static func breath(seconds: float) -> AudioStreamWAV:
	var n := int(seconds * RATE)
	var data := PackedByteArray()
	data.resize(n * 2)
	var y := 0.0
	var cycle := seconds / 2.0
	for i in n:
		var t := float(i) / RATE
		y += ((randf() * 2.0 - 1.0) - y) * 0.12
		var e := maxf(0.0, sin(TAU * t / cycle))
		data.encode_s16(i * 2, int(clampf(y * 1.6 * e * e, -1.0, 1.0) * 28000.0))
	return _make(data, true)

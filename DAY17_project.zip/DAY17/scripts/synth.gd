extends RefCounted
# Процедурные звуки: дождь, ветер, шаги, скрип, сердцебиение и т.д.
const RATE := 16000

static func _make(data: PackedByteArray, loop: bool) -> AudioStreamWAV:
	var st := AudioStreamWAV.new()
	st.format = AudioStreamWAV.FORMAT_16_BITS
	st.mix_rate = RATE
	st.stereo = false
	st.data = data
	if loop:
		st.loop_mode = AudioStreamWAV.LOOP_FORWARD
		st.loop_begin = 0
		st.loop_end = data.size() / 2
	return st

static func noise(seconds: float, lp: float, gain: float = 0.5, decay: float = 0.0, loop: bool = false) -> AudioStreamWAV:
	var n := int(seconds * RATE)
	var data := PackedByteArray()
	data.resize(n * 2)
	var y := 0.0
	var norm := sqrt((2.0 - lp) / lp) * 0.55
	for i in n:
		y += ((randf() * 2.0 - 1.0) - y) * lp
		var env := 1.0
		if decay > 0.0:
			env = exp(-float(i) / RATE * decay)
		data.encode_s16(i * 2, int(clampf(y * norm * gain * env, -1.0, 1.0) * 32000.0))
	return _make(data, loop)

static func thump(seconds: float, freq: float, decay: float, noise_amt: float = 0.3) -> AudioStreamWAV:
	var n := int(seconds * RATE)
	var data := PackedByteArray()
	data.resize(n * 2)
	var ph := 0.0
	var y := 0.0
	for i in n:
		var t := float(i) / RATE
		ph += TAU * freq * (1.0 - 0.35 * t / seconds) / RATE
		y += ((randf() * 2.0 - 1.0) - y) * 0.05
		var s := sin(ph) * exp(-t * decay) + y * 4.0 * noise_amt * exp(-t * decay * 1.5)
		data.encode_s16(i * 2, int(clampf(s, -1.0, 1.0) * 30000.0))
	return _make(data, false)

static func heartbeat() -> AudioStreamWAV:
	var n := int(0.8 * RATE)
	var data := PackedByteArray()
	data.resize(n * 2)
	for i in n:
		var t := float(i) / RATE
		var s := sin(TAU * 52.0 * t) * exp(-t * 16.0)
		var t2 := t - 0.28
		if t2 > 0.0:
			s += 0.7 * sin(TAU * 46.0 * t2) * exp(-t2 * 18.0)
		data.encode_s16(i * 2, int(clampf(s, -1.0, 1.0) * 30000.0))
	return _make(data, false)

static func creak(seconds: float) -> AudioStreamWAV:
	var n := int(seconds * RATE)
	var data := PackedByteArray()
	data.resize(n * 2)
	var ph := 0.0
	var y := 0.0
	for i in n:
		var t := float(i) / RATE
		var f := 170.0 + 140.0 * (0.5 + 0.5 * sin(t * 4.0)) + 30.0 * sin(t * 23.0)
		ph += TAU * f / RATE
		y += ((randf() * 2.0 - 1.0) - y) * 0.3
		var saw := fposmod(ph, TAU) / PI - 1.0
		var env := sin(PI * t / seconds)
		var s := (saw * 0.35 + sin(ph * 2.0) * 0.15 + y * 0.12) * env
		data.encode_s16(i * 2, int(clampf(s, -1.0, 1.0) * 26000.0))
	return _make(data, false)

static func breath(seconds: float) -> AudioStreamWAV:
	var n := int(seconds * RATE)
	var data := PackedByteArray()
	data.resize(n * 2)
	var y := 0.0
	var cycle := seconds / 2.0
	for i in n:
		var t := float(i) / RATE
		y += ((randf() * 2.0 - 1.0) - y) * 0.12
		var e := maxf(0.0, sin(TAU * t / cycle))
		data.encode_s16(i * 2, int(clampf(y * 1.6 * e * e, -1.0, 1.0) * 28000.0))
	return _make(data, true)

static func _pack(arr: PackedFloat32Array, loop: bool = false) -> AudioStreamWAV:
	var n := arr.size()
	var data := PackedByteArray()
	data.resize(n * 2)
	for i in n:
		data.encode_s16(i * 2, int(clampf(arr[i], -1.0, 1.0) * 30000.0))
	return _make(data, loop)

# Шаги игрока по разным поверхностям (короткие, резкие, высокие — не похожи на шаги монстра)
static func step(kind: String) -> AudioStreamWAV:
	var dur := 0.22
	if kind == "road":
		dur = 0.14
	elif kind == "swamp":
		dur = 0.5
	elif kind == "mud":
		dur = 0.32
	elif kind == "wood":
		dur = 0.26
	elif kind == "dry":
		dur = 0.26
	var n := int(dur * RATE)
	var out := PackedFloat32Array()
	out.resize(n)
	var y1 := 0.0
	var y2 := 0.0
	var gate := 1.0
	for i in n:
		var t := float(i) / RATE
		var w := randf() * 2.0 - 1.0
		var s := 0.0
		if kind == "grass":
			y1 += (w - y1) * 0.4
			s = (w - y1) * (1.0 - exp(-t * 400.0)) * exp(-t * 13.0) * 0.5 + sin(TAU * 80.0 * t) * exp(-t * 50.0) * 0.18
		elif kind == "needles":
			y1 += (w - y1) * 0.5
			y2 += (w - y2) * 0.07
			s = (y1 - y2) * (1.0 - exp(-t * 300.0)) * exp(-t * 15.0) * 0.9 + sin(TAU * 70.0 * t) * exp(-t * 45.0) * 0.15
		elif kind == "dry":
			if i % 90 == 0:
				gate = randf()
			y1 += (w - y1) * 0.45
			s = (w - y1) * gate * exp(-t * 11.0) * 0.55 + sin(TAU * 75.0 * t) * exp(-t * 50.0) * 0.12
		elif kind == "mud":
			y1 += (w - y1) * 0.12
			y2 += (w - y2) * 0.03
			s = (y1 - y2) * (1.0 - exp(-t * 60.0)) * exp(-t * 8.0) * 3.2 + sin(TAU * 62.0 * t) * exp(-t * 30.0) * 0.25
		elif kind == "road":
			y1 += (w - y1) * 0.5
			s = (w - y1) * exp(-t * 60.0) * 0.5 + sin(TAU * 125.0 * t) * exp(-t * 55.0) * 0.5
		elif kind == "swamp":
			y1 += (w - y1) * 0.25
			var t2 := maxf(0.0, t - 0.17)
			s = y1 * (1.0 - exp(-t * 40.0)) * exp(-t * 6.0) * 1.6
			if t > 0.17:
				s += sin(TAU * (300.0 + 500.0 * t2) * t2) * exp(-t2 * 30.0) * 0.12
		else:
			s = sin(TAU * 95.0 * t) * exp(-t * 26.0) * 0.6 + sin(TAU * 210.0 * t) * exp(-t * 34.0) * 0.3 + (w - y1) * exp(-t * 90.0) * 0.15
			y1 += (w - y1) * 0.3
		out[i] = s
	return _pack(out)

# Радио: помехи + морзе «DAY17», зацикленное
static func radio_loop() -> AudioStreamWAV:
	var secs := 12.0
	var n := int(secs * RATE)
	var out := PackedFloat32Array()
	out.resize(n)
	var y := 0.0
	for i in n:
		var t := float(i) / RATE
		var w := randf() * 2.0 - 1.0
		y += (w - y) * 0.45
		var s := y * (0.2 + 0.1 * sin(t * 2.3))
		if randf() < 0.0008:
			s += (randf() * 2.0 - 1.0) * 0.7
		out[i] = s
	var morse := "-.. .- -.-- .---- --..."
	var tc := 1.5
	for ch in morse:
		var d := 0.0
		if ch == ".":
			d = 0.07
		elif ch == "-":
			d = 0.21
		if d > 0.0:
			var i0 := int(tc * RATE)
			var i1 := mini(n, int((tc + d) * RATE))
			for i in range(i0, i1):
				var tt := float(i) / RATE
				out[i] += sin(TAU * 820.0 * tt) * 0.22 * minf(1.0, (tt - tc) * 200.0)
			tc += d + 0.07
		else:
			tc += 0.2
	return _pack(out, true)

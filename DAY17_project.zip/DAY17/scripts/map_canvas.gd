extends Control
# Бумажная карта: рисуется внутри SubViewport и показывается на листе в руке игрока.
var player
var world
var t_redraw := 0.0
const CELL := 40.0

func _ready() -> void:
	size = Vector2(512, 360)

func _process(delta: float) -> void:
	t_redraw -= delta
	if t_redraw <= 0.0 and player != null and player.map_up:
		t_redraw = 0.25
		queue_redraw()

func _draw() -> void:
	var w := size.x
	var h := size.y
	var font := ThemeDB.fallback_font
	draw_rect(Rect2(0, 0, w, h), Color(0.36, 0.3, 0.21))
	if world == null or player == null:
		return
	var pp: Vector3 = player.global_position
	var cx0 := w * 0.5
	var cy0 := h * 0.5
	# исследованные клетки светлее
	for k in world.explored.keys():
		var kk: Vector2i = k
		var rx := (kk.x * CELL - pp.x) + cx0
		var ry := (kk.y * CELL - pp.z) + cy0
		if rx > -CELL and rx < w and ry > -CELL and ry < h:
			draw_rect(Rect2(rx, ry, CELL + 1.0, CELL + 1.0), Color(0.8, 0.72, 0.54))
	# дорога (только по исследованному)
	var prev := Vector2.ZERO
	var prev_ok := false
	var x := pp.x - cx0
	while x < pp.x + cx0:
		var z: float = world.road_z(x)
		var cell := Vector2i(floori(x / CELL), floori(z / CELL))
		var ok: bool = world.explored.has(cell)
		var pt := Vector2(x - pp.x + cx0, z - pp.z + cy0)
		if ok and prev_ok:
			draw_line(prev, pt, Color(0.25, 0.2, 0.15), 3.0)
		prev = pt
		prev_ok = ok
		x += 8.0
	# найденные места
	for m in world.markers:
		var mp: Vector3 = m["p"]
		var sp := Vector2(mp.x - pp.x + cx0, mp.z - pp.z + cy0)
		if sp.x < 0.0 or sp.x > w or sp.y < 0.0 or sp.y > h:
			continue
		var kind := String(m["k"])
		var ink := Color(0.18, 0.1, 0.08)
		if kind == "cabin":
			draw_rect(Rect2(sp.x - 7, sp.y - 4, 14, 9), ink, false, 2.0)
			draw_colored_polygon(PackedVector2Array([Vector2(sp.x - 9, sp.y - 4), Vector2(sp.x, sp.y - 12), Vector2(sp.x + 9, sp.y - 4)]), ink)
		elif kind == "camp":
			draw_colored_polygon(PackedVector2Array([Vector2(sp.x - 7, sp.y + 5), Vector2(sp.x, sp.y - 7), Vector2(sp.x + 7, sp.y + 5)]), ink)
		elif kind == "car":
			draw_rect(Rect2(sp.x - 8, sp.y - 4, 16, 8), ink)
		else:
			draw_circle(sp, 4.0, ink)
	# игрок
	var c := Vector2(cx0, cy0)
	var has_compass: bool = player.inv_count("compass") > 0
	if has_compass:
		var f := Vector2(-sin(player.yaw), -cos(player.yaw))
		var r := Vector2(-f.y, f.x)
		draw_colored_polygon(PackedVector2Array([c + f * 13.0, c - f * 7.0 + r * 7.0, c - f * 7.0 - r * 7.0]), Color(0.65, 0.1, 0.08))
		draw_string(font, Vector2(w - 44, 34), "С", HORIZONTAL_ALIGNMENT_CENTER, 30, 24, Color(0.15, 0.08, 0.05))
		draw_line(Vector2(w - 29, 40), Vector2(w - 29, 62), Color(0.15, 0.08, 0.05), 3.0)
	else:
		draw_circle(c, 6.0, Color(0.65, 0.1, 0.08))
		draw_circle(c, 11.0, Color(0.65, 0.1, 0.08, 0.35))
	draw_rect(Rect2(3, 3, w - 6, h - 6), Color(0.15, 0.09, 0.06), false, 5.0)
	draw_string(font, Vector2(14, h - 14), "карта лесной дороги — отмечено только пройденное", HORIZONTAL_ALIGNMENT_LEFT, w - 28, 13, Color(0.18, 0.1, 0.08, 0.8))

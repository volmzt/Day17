extends RefCounted
# Настройки игры (сохраняются в user://)
const PATH := "user://day17_settings.json"
const PRESETS := [
	{"shadows": 0, "shadow_dist": 0, "view": 0, "veg": 0, "poly": 0, "fog": 0, "rain": 0, "res": 0, "aa": 0, "aniso": 0, "fps": 1},
	{"shadows": 1, "shadow_dist": 1, "view": 1, "veg": 1, "poly": 1, "fog": 1, "rain": 1, "res": 1, "aa": 0, "aniso": 1, "fps": 2},
	{"shadows": 3, "shadow_dist": 2, "view": 2, "veg": 2, "poly": 2, "fog": 2, "rain": 2, "res": 2, "aa": 1, "aniso": 2, "fps": 3},
]
const GFX_KEYS := ["shadows", "shadow_dist", "view", "veg", "poly", "fog", "rain", "res", "aa", "aniso", "fps"]
static var s := {
	"preset": 1, "shadows": 1, "shadow_dist": 1, "view": 1, "veg": 1, "poly": 1, "fog": 1, "rain": 1,
	"res": 1, "aa": 0, "aniso": 1, "fps": 2,
	"vol_master": 8, "vol_ambient": 8, "vol_creature": 9, "sens": 5, "camfx": 2, "pixel": 0,
}

static func load_settings() -> void:
	if not FileAccess.file_exists(PATH):
		return
	var f := FileAccess.open(PATH, FileAccess.READ)
	var d = JSON.parse_string(f.get_as_text())
	if d is Dictionary:
		for k in d:
			if s.has(k):
				s[k] = int(d[k])

static func save_settings() -> void:
	var f := FileAccess.open(PATH, FileAccess.WRITE)
	f.store_string(JSON.stringify(s))

static func set_value(k: String, v: int) -> void:
	s[k] = v
	if k == "preset":
		if v < 3:
			for kk in PRESETS[v]:
				s[kk] = PRESETS[v][kk]
	elif k in GFX_KEYS:
		s["preset"] = 3

static func _vol(bus: String, v: int) -> void:
	var i := AudioServer.get_bus_index(bus)
	if i >= 0:
		AudioServer.set_bus_volume_db(i, linear_to_db(maxf(v / 10.0, 0.0001)))

static func apply(vp: Viewport) -> void:
	Engine.max_fps = [30, 45, 60, 90][s["fps"]]
	if vp:
		vp.scaling_3d_mode = Viewport.SCALING_3D_MODE_BILINEAR
		vp.scaling_3d_scale = [0.6, 0.75, 1.0][s["res"]]
		vp.msaa_3d = [Viewport.MSAA_DISABLED, Viewport.MSAA_2X, Viewport.MSAA_4X][s["aa"]]
		vp.set("anisotropic_filtering_level", [0, 2, 4][s["aniso"]])
		vp.positional_shadow_atlas_size = [1024, 1024, 2048, 4096][s["shadows"]]
	_vol("Master", s["vol_master"])
	_vol("Ambient", s["vol_ambient"])
	_vol("Creature", s["vol_creature"])

extends Node3D
# Колоссальное существо. Модель — ПЛЕЙСХОЛДЕР (оригинальная процедурная форма).
# Чтобы подставить свою (лицензированную) модель, положите её в res://models/creature.glb
enum S { STAND, ROAM, OBSERVE, INVESTIGATE, APPROACH, SEARCH, LEAVE }
const AUD := "res://audio/creature/"
const FAR := ["dragon-studio-creepy-whale-song-sfx-494309.mp3", "alesiadavina-horror-sound-lurking-horror-monster-189948.mp3", "strashnyezvuki-18.mp3"]
const MID := ["dragon-studio-deep-sea-growl-401721.mp3", "chiiri-monster-13-337347.mp3", "chiiri-monster-15-337349.mp3", "freesound_community-swiss-chocolate-sea-monster-83730.mp3", "freesound_community-tripod-106078.mp3"]
const NEAR := ["alesiadavina-horror-sound-monster-breath-189934.mp3", "dragon-studio-deep-sea-growl-401721.mp3", "chiiri-monster-13-337347.mp3"]
const ROAR := ["dragon-studio-deep-sea-monster-roar-329857.mp3", "freesound_community-big-monster-shout-104325.mp3", "phatphrogstudio-dragon-voice-roar-477831.mp3", "dragon-studio-epic-dragon-roar-364481.mp3"]
const B = preload("res://scripts/builder.gd")
const HIPS := [Vector3(-7, 62, -2), Vector3(7, 62, -2), Vector3(-5, 62, 17), Vector3(5, 62, 17)]
const LEG_OFF := [0.0, 0.5, 0.75, 0.25]

var world
var player
var state := S.STAND
var next_state := -1
var state_t := 20.0
var target := Vector3.ZERO
var center := Vector3.ZERO
var search_t := 0.0
var yaw := 0.0
var speed := 0.0
var last_heard := -999.0
var dist := 1000.0
var phase := 0.0
var t := 0.0
var legs: Array = []
var knees: Array = []
var feet: Array = []
var tentacles: Array = []
var rig: Node3D
var glb_mat: ShaderMaterial
var glb_holder: Node3D
var glb_k := 14.4
var glb_on := false
var glb_leg_prev := [1.0, 1.0, 1.0, 1.0]
var glb_swing := Vector4.ZERO
var glb_knee := Vector4.ZERO
const GLB_OFF := [0.0, 0.5, 0.25, 0.75]
const MODEL_H := 78.0
var leg_prev := [1.0, 1.0, 1.0, 1.0]
var far_s: Array = []
var mid_s: Array = []
var near_s: Array = []
var roar_s: Array = []
var step_s: AudioStream
var voice: AudioStreamPlayer3D
var bed: AudioStreamPlayer
var lowpass: AudioEffectLowPassFilter
var next_voice := 15.0
var window_t := 20.0

func _load_list(names: Array) -> Array:
	var out: Array = []
	for n in names:
		if ResourceLoader.exists(AUD + n):
			out.append(load(AUD + n))
	return out

func _ready() -> void:
	far_s = _load_list(FAR)
	mid_s = _load_list(MID)
	near_s = _load_list(NEAR)
	roar_s = _load_list(ROAR)
	var sl := _load_list(["dragon-studio-deep-sea-impact-401722.mp3"])
	if sl.size() > 0:
		step_s = sl[0]
	voice = AudioStreamPlayer3D.new()
	voice.top_level = true
	voice.bus = "Creature"
	voice.attenuation_model = AudioStreamPlayer3D.ATTENUATION_DISABLED
	voice.attenuation_filter_cutoff_hz = 20500.0
	voice.max_distance = 0.0
	voice.volume_db = 0.0
	add_child(voice)
	var bs := _load_list(["dragon-studio-underwater-sounds-584745.mp3"])
	bed = AudioStreamPlayer.new()
	bed.bus = "Creature"
	bed.volume_db = -60.0
	if bs.size() > 0:
		bs[0].loop = true
		bed.stream = bs[0]
		add_child(bed)
		bed.play()
	var idx := AudioServer.get_bus_index("Creature")
	lowpass = AudioServer.get_bus_effect(idx, 0)
	_build_model()
	_set(S.STAND)

# ---------- модель ----------
# ---------- модель из GLB (models/creature.glb): сетка + анимация ног и щупалец в шейдере ----------
func _find_mesh(n: Node) -> MeshInstance3D:
	if n is MeshInstance3D:
		return n
	for c in n.get_children():
		var r := _find_mesh(c)
		if r != null:
			return r
	return null

const GLB_SHADER := """shader_type spatial;
render_mode cull_disabled;
uniform vec4 swing = vec4(0.0);
uniform vec4 knee = vec4(0.0);
uniform float tt = 0.0;
uniform sampler2D tex : source_color, repeat_enable, filter_linear_mipmap;
varying vec3 lp;
vec3 rotx(vec3 p, float a) {
	float c = cos(a);
	float s = sin(a);
	return vec3(p.x, p.y * c - p.z * s, p.y * s + p.z * c);
}
void vertex() {
	vec3 v = VERTEX;
	vec3 n = NORMAL;
	int id = int(floor(COLOR.r * 3.0 + 0.5));
	float lw = COLOR.g;
	if (lw > 0.001) {
		float sx = (id == 1 || id == 3) ? 1.0 : -1.0;
		float zc = (id >= 2) ? 0.8 : -0.65;
		vec3 kp = vec3(sx * 1.3, 1.6, zc);
		float kw = lw * (1.0 - smoothstep(1.2, 1.9, v.y));
		v = kp + rotx(v - kp, knee[id] * kw);
		n = rotx(n, knee[id] * kw);
		vec3 hp = vec3(sx * 1.25, 3.1, zc);
		v = hp + rotx(v - hp, -swing[id] * lw);
		n = rotx(n, -swing[id] * lw);
	}
	float tw = COLOR.b;
	if (tw > 0.001) {
		v.x += sin(tt * 0.9 + v.y * 2.0 + v.z) * 0.07 * tw;
		v.z += cos(tt * 0.7 + v.y * 1.6 + v.x) * 0.09 * tw;
	}
	lp = v;
	VERTEX = v;
	NORMAL = normalize(n);
}
void fragment() {
	float a = texture(tex, lp.xy * 0.35).r;
	float b = texture(tex, lp.zy * 0.35 + vec2(0.37)).r;
	float c = texture(tex, lp.xz * 0.35 + vec2(0.71)).r;
	float g = (a + b + c) / 3.0;
	ALBEDO = vec3(0.055, 0.055, 0.06) * (0.45 + g * 1.3);
	ROUGHNESS = 0.38 + g * 0.3;
	SPECULAR = 0.6;
	RIM = 0.25;
	RIM_TINT = 0.6;
}
"""

func _build_glb() -> bool:
	if not ResourceLoader.exists("res://models/creature.glb"):
		return false
	var ps = load("res://models/creature.glb")
	if not (ps is PackedScene):
		return false
	var inst: Node = ps.instantiate()
	var mi := _find_mesh(inst)
	if mi == null or mi.mesh == null:
		inst.queue_free()
		return false
	var xf := Transform3D()
	var nd: Node = mi
	while nd != null and nd != inst:
		if nd is Node3D:
			xf = (nd as Node3D).transform * xf
		nd = nd.get_parent()
	var arrays := mi.mesh.surface_get_arrays(0)
	var verts: PackedVector3Array = arrays[Mesh.ARRAY_VERTEX]
	var norms = arrays[Mesh.ARRAY_NORMAL]
	var uvs = arrays[Mesh.ARRAY_TEX_UV]
	var idx = arrays[Mesh.ARRAY_INDEX]
	inst.queue_free()
	if verts.size() == 0:
		return false
	var nv := PackedVector3Array()
	nv.resize(verts.size())
	var lo := Vector3(1e9, 1e9, 1e9)
	var hi := Vector3(-1e9, -1e9, -1e9)
	for i in verts.size():
		var p: Vector3 = xf * verts[i]
		nv[i] = p
		lo = Vector3(minf(lo.x, p.x), minf(lo.y, p.y), minf(lo.z, p.z))
		hi = Vector3(maxf(hi.x, p.x), maxf(hi.y, p.y), maxf(hi.z, p.z))
	var H := hi.y - lo.y
	var f := 5.41 / H
	# центр по стопам
	var fx := 0.0
	var fz := 0.0
	var fc := 0
	for i in nv.size():
		if (nv[i].y - lo.y) * f < 0.3:
			fx += nv[i].x
			fz += nv[i].z
			fc += 1
	if fc > 0:
		fx /= fc
		fz /= fc
	var cols := PackedColorArray()
	cols.resize(nv.size())
	var nn := PackedVector3Array()
	nn.resize(nv.size())
	for i in nv.size():
		var u := Vector3((nv[i].x - fx) * f, (nv[i].y - lo.y) * f, (nv[i].z - fz) * f)
		nv[i] = u
		if norms != null and norms.size() == nv.size():
			nn[i] = (xf.basis * (norms[i] as Vector3)).normalized()
		else:
			nn[i] = Vector3.UP
		var leg_id := (1 if u.x > 0.0 else 0) + (2 if u.z > 0.1 else 0)
		var lw := 0.0
		if u.y < 3.3:
			lw = clampf((absf(u.x) - 0.5) / 0.4, 0.0, 1.0) * (1.0 - smoothstep(2.3, 3.3, u.y))
		var tw := 0.0
		if u.z > 1.0 and absf(u.x) < 0.75:
			var edge := 3.0 + (u.z - 0.5) * 0.75
			tw = clampf((edge - 0.1 - u.y) / 1.2, 0.0, 1.0)
		cols[i] = Color(leg_id / 3.0, lw, tw, 1.0)
	var arr := []
	arr.resize(Mesh.ARRAY_MAX)
	arr[Mesh.ARRAY_VERTEX] = nv
	arr[Mesh.ARRAY_NORMAL] = nn
	arr[Mesh.ARRAY_COLOR] = cols
	if uvs != null:
		arr[Mesh.ARRAY_TEX_UV] = uvs
	if idx != null:
		arr[Mesh.ARRAY_INDEX] = idx
	var am := ArrayMesh.new()
	am.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)
	am.custom_aabb = AABB(Vector3(-4, -1, -4), Vector3(8, 8, 9))
	var sh := Shader.new()
	sh.code = GLB_SHADER
	glb_mat = ShaderMaterial.new()
	glb_mat.shader = sh
	glb_mat.set_shader_parameter("tex", world.creature_mat.albedo_texture)
	rig = Node3D.new()
	add_child(rig)
	glb_holder = Node3D.new()
	glb_k = MODEL_H / 5.41
	glb_holder.scale = Vector3.ONE * glb_k
	glb_holder.rotation.y = PI
	rig.add_child(glb_holder)
	var m := MeshInstance3D.new()
	m.mesh = am
	m.material_override = glb_mat
	m.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	glb_holder.add_child(m)
	glb_on = true
	return true

func _animate_glb(delta: float) -> void:
	phase += speed * delta / 40.0
	var amp := clampf(speed / 3.0, 0.0, 1.0) * 0.26
	var sw := [0.0, 0.0, 0.0, 0.0]
	var kn := [0.0, 0.0, 0.0, 0.0]
	for id in 4:
		var ph: float = (phase + GLB_OFF[id]) * TAU
		var c := cos(ph)
		sw[id] = sin(ph) * amp + sin(t * 0.17 + id) * 0.008
		kn[id] = maxf(0.0, c) * amp * 2.4
		if glb_leg_prev[id] > 0.0 and c <= 0.0 and speed > 0.3:
			_step_glb(id, sw[id])
		glb_leg_prev[id] = c
	glb_mat.set_shader_parameter("swing", Vector4(sw[0], sw[1], sw[2], sw[3]))
	glb_mat.set_shader_parameter("knee", Vector4(kn[0], kn[1], kn[2], kn[3]))
	glb_mat.set_shader_parameter("tt", t)
	rig.position.y = sin(phase * TAU * 2.0) * 0.5 * clampf(speed / 3.0, 0.0, 1.0)
	rig.rotation.z = sin(t * 0.2) * 0.012
	rig.rotation.x = sin(t * 0.13) * 0.008

func _step_glb(id: int, swing: float) -> void:
	var sx := 1.0 if (id == 1 or id == 3) else -1.0
	var zc := 0.8 if id >= 2 else -0.65
	var hp := Vector3(sx * 1.25, 3.1, zc)
	var foot := Vector3(sx * 1.3, 0.05, zc)
	foot = hp + Basis(Vector3.RIGHT, swing) * (foot - hp)
	var pos: Vector3 = glb_holder.global_transform * foot
	pos.y = world.ground_h(pos.x, pos.z)
	var pp: Vector3 = player.global_position
	var d := Vector2(pos.x - pp.x, pos.z - pp.z).length()
	if step_s:
		world.play_creature(step_s, pos, 12.0 + _vdb(d), randf_range(0.45, 0.7))
	player.shake = maxf(player.shake, clampf(1.0 - d / 220.0, 0.0, 1.0) * 1.2)

func _cr(p0: Vector3, p1: Vector3, p2: Vector3, p3: Vector3, t: float) -> Vector3:
	return 0.5 * ((2.0 * p1) + (-p0 + p2) * t + (2.0 * p0 - 5.0 * p1 + 4.0 * p2 - p3) * t * t + (-p0 + 3.0 * p1 - 3.0 * p2 + p3) * t * t * t)

func _mi(parent: Node3D, mesh: Mesh, mat: Material) -> MeshInstance3D:
	var m := MeshInstance3D.new()
	m.mesh = mesh
	m.material_override = mat
	parent.add_child(m)
	return m

func _build_model() -> void:
	if _build_glb():
		return
	var mat: Material = world.creature_mat
	var nz := FastNoiseLite.new()
	nz.frequency = 0.5
	nz.fractal_octaves = 3
	rig = Node3D.new()
	add_child(rig)
	# --- туловище + длинная шея одним сплошным телом ---
	var cp := [Vector3(0, 58, 32), Vector3(0, 62, 26), Vector3(0, 68, 12), Vector3(0, 73, -4), Vector3(0, 80, -16),
		Vector3(0, 92, -26), Vector3(0, 106, -35), Vector3(0, 116, -47), Vector3(0, 118, -60), Vector3(0, 111, -72), Vector3(0, 100, -77), Vector3(0, 94, -77)]
	var cr := [Vector3(1.5, 0, 0), Vector3(4.5, 0, 0), Vector3(8.0, 0, 0), Vector3(9.0, 0, 0), Vector3(8.0, 0, 0),
		Vector3(6.2, 0, 0), Vector3(5.0, 0, 0), Vector3(4.2, 0, 0), Vector3(3.6, 0, 0), Vector3(3.2, 0, 0), Vector3(2.6, 0, 0), Vector3(0.4, 0, 0)]
	var pts: Array = []
	var rad: Array = []
	for i in cp.size() - 1:
		var p0: Vector3 = cp[maxi(i - 1, 0)]
		var p1: Vector3 = cp[i]
		var p2: Vector3 = cp[i + 1]
		var p3: Vector3 = cp[mini(i + 2, cp.size() - 1)]
		var r0: Vector3 = cr[maxi(i - 1, 0)]
		var r1: Vector3 = cr[i]
		var r2: Vector3 = cr[i + 1]
		var r3: Vector3 = cr[mini(i + 2, cr.size() - 1)]
		for k in 5:
			var t := k / 5.0
			pts.append(_cr(p0, p1, p2, p3, t))
			rad.append(maxf(0.2, _cr(r0, r1, r2, r3, t).x))
	pts.append(cp[cp.size() - 1])
	rad.append(0.3)
	var body := B.MB.new()
	body.loft(pts, rad, 18, Color(0.035, 0.035, 0.04), Color(0.075, 0.07, 0.07), nz, 0.14, Vector2(4.0, 0.03))
	# позвонки / выступы вдоль спины
	for i in range(6, pts.size() - 8, 3):
		var pp: Vector3 = pts[i]
		body.sphere(pp + Vector3(0, rad[i] * 0.92, 0), Vector3(1.4, 1.1, 1.8), Color(0.1, 0.095, 0.09), 7, 4, nz, 0.3)
	_mi(rig, body.to_mesh(), mat)
	# --- ноги: бедро -> колено -> стопа, всё сочленено шарами ---
	for i in 4:
		var sx := signf(HIPS[i].x)
		var hip := Node3D.new()
		hip.position = HIPS[i]
		rig.add_child(hip)
		var up := B.MB.new()
		up.sphere(Vector3.ZERO, Vector3(5.2, 5.2, 5.2), Color(0.05, 0.05, 0.055), 10, 6, nz, 0.15)
		up.loft([Vector3(0, 0, 0), Vector3(sx * 5.0, -14, 1.5), Vector3(sx * 9.0, -29, 4)], [4.0, 3.2, 2.5], 12, Color(0.05, 0.05, 0.055), Color(0.07, 0.065, 0.065), nz, 0.2, Vector2(3.0, 0.08))
		up.sphere(Vector3(sx * 9.0, -29, 4), Vector3(3.2, 3.2, 3.2), Color(0.08, 0.075, 0.07), 9, 6, nz, 0.25)
		_mi(hip, up.to_mesh(), mat)
		var knee := Node3D.new()
		knee.position = Vector3(sx * 9.0, -29, 4)
		hip.add_child(knee)
		var lo := B.MB.new()
		lo.loft([Vector3(0, 0, 0), Vector3(-sx * 1.0, -16, 0.5), Vector3(-sx * 2.0, -33, -2)], [2.3, 1.4, 0.9], 10, Color(0.07, 0.065, 0.065), Color(0.04, 0.04, 0.045), nz, 0.18, Vector2(3.0, 0.1))
		lo.sphere(Vector3(-sx * 2.0, -32.5, -1.5), Vector3(2.4, 1.0, 3.2), Color(0.03, 0.03, 0.035), 8, 5, nz, 0.2)
		_mi(knee, lo.to_mesh(), mat)
		var foot := Node3D.new()
		foot.position = Vector3(-sx * 2.0, -33, -2)
		knee.add_child(foot)
		legs.append(hip)
		knees.append(knee)
		feet.append(foot)
	# --- щупальца: цепочки из 3 сегментов, свисают с изгиба шеи и конца ---
	var rng := RandomNumberGenerator.new()
	rng.seed = 77
	for i in 24:
		var at: Vector3
		if i < 14:
			var pi := rng.randi_range(pts.size() - 16, pts.size() - 4)
			at = (pts[pi] as Vector3) + Vector3(rng.randf_range(-1.5, 1.5), -rad[pi] * 0.85, rng.randf_range(-1.5, 1.5))
		else:
			var pj := rng.randi_range(int(pts.size() * 0.45), int(pts.size() * 0.8))
			at = (pts[pj] as Vector3) + Vector3(rng.randf_range(-1.0, 1.0), -rad[pj] * 0.9, rng.randf_range(-1.0, 1.0))
		var parent: Node3D = rig
		var pos := at
		var seg_len := rng.randf_range(13.0, 21.0)
		var chain: Array = []
		for sg in 3:
			var pv := Node3D.new()
			pv.position = pos
			parent.add_child(pv)
			var r0: float = [0.5, 0.3, 0.16][sg]
			var r1: float = [0.3, 0.16, 0.012][sg]
			var tb := B.MB.new()
			tb.loft([Vector3.ZERO, Vector3(rng.randf_range(-0.4, 0.4), -seg_len * 0.5, rng.randf_range(-0.4, 0.4)), Vector3(0, -seg_len, 0)], [r0, (r0 + r1) * 0.5, r1], 6, Color(0.05, 0.045, 0.045), Color(0.035, 0.035, 0.035), null, 0.0, Vector2(1, 0.2))
			_mi(pv, tb.to_mesh(), mat)
			chain.append(pv)
			parent = pv
			pos = Vector3(0, -seg_len, 0)
		tentacles.append(chain)

# ---------- логика ----------
func _set(s: int) -> void:
	state = s
	match s:
		S.STAND:
			state_t = randf_range(10.0, 45.0)
		S.OBSERVE:
			state_t = randf_range(8.0, 25.0)
		S.ROAM:
			state_t = 300.0
			var base := global_position
			if randf() < 0.45:
				base = player.global_position
			var a := randf() * TAU
			target = base + Vector3(cos(a), 0, sin(a)) * randf_range(250.0, 600.0)
		S.INVESTIGATE:
			state_t = 180.0
		S.APPROACH:
			state_t = 240.0
		S.SEARCH:
			state_t = randf_range(50.0, 110.0)
			search_t = 0.0
			center = target
		S.LEAVE:
			state_t = 200.0
			var a2 := randf() * TAU
			target = global_position + Vector3(cos(a2), 0, sin(a2)) * 450.0

func hear(pos: Vector3, loud: float) -> void:
	var d := Vector2(pos.x - global_position.x, pos.z - global_position.z).length()
	if d > loud * randf_range(0.6, 1.3):
		return
	last_heard = Time.get_ticks_msec() / 1000.0
	if state != S.APPROACH and state != S.INVESTIGATE:
		next_voice = minf(next_voice, randf_range(0.5, 3.0))
	target = Vector3(pos.x, 0, pos.z) + Vector3(randf_range(-20, 20), 0, randf_range(-20, 20))
	if state == S.APPROACH:
		return
	if state == S.INVESTIGATE:
		if d < 80.0 and randf() < 0.5:
			_set(S.APPROACH)
		return
	if randf() < 0.85:
		# иногда сначала замирает, потом идёт
		if randf() < 0.5:
			var tg := target
			_set(S.STAND)
			target = tg
			state_t = randf_range(3.0, 9.0)
			next_state = S.INVESTIGATE
		else:
			var tg2 := target
			_set(S.INVESTIGATE)
			target = tg2

func retreat() -> void:
	var a := randf() * TAU
	global_position = player.global_position + Vector3(cos(a), 0, sin(a)) * 500.0
	_set(S.LEAVE)
	speed = 0.0

func _yaw_to(p: Vector3) -> float:
	var to := p - global_position
	return atan2(-to.x, -to.z)

func _advance(delta: float) -> void:
	global_position += Vector3(-sin(yaw), 0, -cos(yaw)) * speed * delta
	global_position.y = world.ground_h(global_position.x, global_position.z)
	rotation.y = yaw

func _steer(delta: float, spd: float) -> bool:
	var to := Vector3(target.x - global_position.x, 0, target.z - global_position.z)
	if to.length() < 25.0:
		speed = move_toward(speed, 0.0, delta * 0.8)
		_advance(delta)
		return true
	yaw = lerp_angle(yaw, atan2(-to.x, -to.z), delta * 0.3)
	speed = move_toward(speed, spd, delta * 0.5)
	_advance(delta)
	return false

func _process(delta: float) -> void:
	if player == null:
		return
	t += delta
	var pp: Vector3 = player.global_position
	dist = Vector2(pp.x - global_position.x, pp.z - global_position.z).length()
	_ai(delta)
	_animate(delta)
	_audio(delta)

func _ai(delta: float) -> void:
	state_t -= delta
	var now := Time.get_ticks_msec() / 1000.0
	var sheltered: bool = world.player_sheltered()
	match state:
		S.STAND, S.OBSERVE:
			speed = move_toward(speed, 0.0, delta * 0.8)
			_advance(delta)
			if state == S.OBSERVE:
				yaw = lerp_angle(yaw, _yaw_to(player.global_position), delta * 0.05)
			if state_t <= 0.0:
				if next_state >= 0:
					var ns := next_state
					next_state = -1
					var tg := target
					_set(ns)
					target = tg
				else:
					var r := randf()
					if r < 0.5:
						_set(S.ROAM)
					elif r < 0.75:
						_set(S.OBSERVE)
					else:
						_set(S.STAND)
		S.ROAM:
			if _steer(delta, 3.0) or state_t <= 0.0:
				_set(S.STAND if randf() < 0.6 else S.OBSERVE)
		S.INVESTIGATE:
			if _steer(delta, 4.5):
				if now - last_heard < 15.0:
					_set(S.APPROACH)
				else:
					_set(S.SEARCH)
			elif state_t <= 0.0:
				_set(S.LEAVE)
		S.APPROACH:
			if sheltered and dist < 90.0:
				target = world.nearest_cabin_pos(player.global_position)
				_set(S.SEARCH)
			elif now - last_heard > 25.0 or state_t <= 0.0:
				_set(S.SEARCH)
			else:
				_steer(delta, 5.5)
		S.SEARCH:
			search_t -= delta
			if search_t <= 0.0:
				search_t = randf_range(8.0, 16.0)
				var a := randf() * TAU
				target = center + Vector3(cos(a), 0, sin(a)) * randf_range(30.0, 70.0)
			_steer(delta, 2.2)
			if sheltered and dist < 70.0:
				window_t -= delta
				if window_t <= 0.0:
					window_t = randf_range(25.0, 60.0)
					if randf() < 0.6:
						world.tentacle_window(player.global_position)
			if state_t <= 0.0:
				_set(S.LEAVE)
		S.LEAVE:
			if _steer(delta, 3.5) or state_t <= 0.0:
				_set(S.STAND)
	# поймал?
	if dist < 13.0 and state != S.LEAVE and not sheltered and player.control and not world.caught_busy:
		world.on_caught()

func _animate(delta: float) -> void:
	if glb_on:
		_animate_glb(delta)
		return
	phase += speed * delta / 36.0
	var amp := clampf(speed / 3.0, 0.0, 1.0) * 0.24
	for i in legs.size():
		var ph: float = (phase + LEG_OFF[i]) * TAU
		legs[i].rotation.x = sin(ph) * amp
		legs[i].rotation.z = -cos(ph) * amp * 0.12 * signf(HIPS[i].x)
		var c := cos(ph)
		knees[i].rotation.x = -maxf(0.0, c) * amp * 2.2
		if leg_prev[i] > 0.0 and c <= 0.0 and speed > 0.3:
			_step(i)
		leg_prev[i] = c
	if rig:
		rig.position.y = sin(phase * TAU * 2.0) * 0.5 * clampf(speed / 3.0, 0.0, 1.0)
		rig.rotation.z = sin(t * 0.2) * 0.012
		rig.rotation.x = sin(t * 0.13) * 0.008
	for i in tentacles.size():
		var chain: Array = tentacles[i]
		for sg in chain.size():
			chain[sg].rotation = Vector3(sin(t * 0.5 + i * 1.7 + sg * 0.8) * 0.12 * (1.0 + sg * 0.5), 0, cos(t * 0.4 + i * 2.3 + sg * 0.9) * 0.12 * (1.0 + sg * 0.5))

func _vdb(d: float) -> float:
	return -20.0 * log(1.0 + d / 35.0) / log(10.0) - d * 0.022

func _step(i: int) -> void:
	var pos: Vector3 = feet[i].global_position
	pos.y = world.ground_h(pos.x, pos.z)
	var pp: Vector3 = player.global_position
	var d := Vector2(pos.x - pp.x, pos.z - pp.z).length()
	if step_s:
		world.play_creature(step_s, pos, 12.0 + _vdb(d), randf_range(0.45, 0.7))
	player.shake = maxf(player.shake, clampf(1.0 - d / 220.0, 0.0, 1.0) * 1.2)

func _audio(delta: float) -> void:
	lowpass.cutoff_hz = lerpf(16000.0, 600.0, smoothstep(30.0, 800.0, dist))
	var rv := clampf(1.0 - dist / 450.0, 0.0, 1.0)
	bed.volume_db = lerpf(-60.0, -10.0, rv * rv)
	world.wind_boost = clampf(1.0 - dist / 500.0, 0.0, 1.0) * 0.3
	if dist < 130.0 and speed > 0.5:
		player.shake = maxf(player.shake, clampf(1.0 - dist / 130.0, 0.0, 1.0) * 0.3)
	if voice.playing:
		voice.volume_db = 8.0 + _vdb(dist)
	next_voice -= delta
	if next_voice > 0.0:
		return
	var pool: Array
	if dist > 450.0:
		pool = far_s + mid_s
		next_voice = randf_range(12.0, 30.0)
	elif dist > 160.0:
		pool = far_s + mid_s + mid_s
		next_voice = randf_range(8.0, 20.0)
	elif dist > 60.0:
		pool = mid_s + near_s
		next_voice = randf_range(6.0, 14.0)
	else:
		pool = near_s + mid_s
		next_voice = randf_range(4.0, 10.0)
	if state == S.INVESTIGATE or state == S.APPROACH:
		next_voice *= 0.6
	if dist < 300.0 and randf() < 0.18 and roar_s.size() > 0:
		pool = roar_s
	if pool.is_empty():
		return
	var pos := global_position + Vector3(0, 55, 0)
	if randf() < 0.12:
		var pp: Vector3 = player.global_position
		pos = pp - (pos - pp)
	voice.stream = pool[randi() % pool.size()]
	voice.global_position = pos
	voice.pitch_scale = randf_range(0.75, 1.0)
	voice.volume_db = 8.0 + _vdb(dist)
	voice.play()

extends Node3D
# Колоссальное существо. Модель — ПЛЕЙСХОЛДЕР (оригинальная процедурная форма).
# Чтобы подставить свою (лицензированную) модель, положите её в res://models/creature.glb
enum S { STAND, ROAM, OBSERVE, INVESTIGATE, APPROACH, SEARCH, LEAVE }
const AUD := "res://audio/creature/"
const FAR := ["dragon-studio-creepy-whale-song-sfx-494309.mp3", "alesiadavina-horror-sound-lurking-horror-monster-189948.mp3", "strashnyezvuki-18.mp3"]
const MID := ["dragon-studio-deep-sea-growl-401721.mp3", "chiiri-monster-13-337347.mp3", "chiiri-monster-15-337349.mp3", "freesound_community-swiss-chocolate-sea-monster-83730.mp3", "freesound_community-tripod-106078.mp3"]
const NEAR := ["alesiadavina-horror-sound-monster-breath-189934.mp3", "dragon-studio-deep-sea-growl-401721.mp3", "chiiri-monster-13-337347.mp3"]
const ROAR := ["dragon-studio-deep-sea-monster-roar-329857.mp3", "freesound_community-big-monster-shout-104325.mp3", "phatphrogstudio-dragon-voice-roar-477831.mp3", "dragon-studio-epic-dragon-roar-364481.mp3"]
const LEG_X := [-11.0, 11.0, -11.0, 11.0]
const LEG_Z := [-17.0, -17.0, 17.0, 17.0]
const LEG_OFF := [0.0, 0.5, 0.75, 0.25]
const LEG_LEN := 68.0

var world
var player
var state := S.STAND
var next_state := -1
var state_t := 20.0
var target := Vector3.ZERO
var center := Vector3.ZERO
var search_t := 0.0
var yaw := 0.0
var speed := 0.0
var last_heard := -999.0
var dist := 1000.0
var phase := 0.0
var t := 0.0
var legs: Array = []
var tentacles: Array = []
var leg_prev := [0.0, 0.0, 0.0, 0.0]
var far_s: Array = []
var mid_s: Array = []
var near_s: Array = []
var roar_s: Array = []
var step_s: AudioStream
var voice: AudioStreamPlayer3D
var bed: AudioStreamPlayer
var lowpass: AudioEffectLowPassFilter
var next_voice := 15.0
var window_t := 20.0

func _load_list(names: Array) -> Array:
	var out: Array = []
	for n in names:
		if ResourceLoader.exists(AUD + n):
			out.append(load(AUD + n))
	return out

func _ready() -> void:
	far_s = _load_list(FAR)
	mid_s = _load_list(MID)
	near_s = _load_list(NEAR)
	roar_s = _load_list(ROAR)
	var sl := _load_list(["dragon-studio-deep-sea-impact-401722.mp3"])
	if sl.size() > 0:
		step_s = sl[0]
	voice = AudioStreamPlayer3D.new()
	voice.top_level = true
	voice.bus = "Creature"
	voice.unit_size = 45.0
	voice.max_distance = 1500.0
	voice.volume_db = 6.0
	add_child(voice)
	var bs := _load_list(["dragon-studio-underwater-sounds-584745.mp3"])
	bed = AudioStreamPlayer.new()
	bed.bus = "Creature"
	bed.volume_db = -60.0
	if bs.size() > 0:
		bs[0].loop = true
		bed.stream = bs[0]
		add_child(bed)
		bed.play()
	var idx := AudioServer.get_bus_index("Creature")
	lowpass = AudioServer.get_bus_effect(idx, 0)
	_build_model()
	_set(S.STAND)

# ---------- модель ----------
func _mat() -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(0.07, 0.065, 0.065)
	m.roughness = 0.92
	return m

func _tube(parent: Node3D, a: Vector3, b: Vector3, r0: float, r1: float, mat: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.height = a.distance_to(b)
	cm.bottom_radius = r0
	cm.top_radius = r1
	cm.radial_segments = 8
	cm.rings = 1
	mi.mesh = cm
	mi.material_override = mat
	var up := (b - a).normalized()
	var ref := Vector3.RIGHT if absf(up.dot(Vector3.RIGHT)) < 0.9 else Vector3.FORWARD
	var x := up.cross(ref).normalized()
	var z := x.cross(up).normalized()
	mi.transform = Transform3D(Basis(x, up, z), (a + b) / 2.0)
	parent.add_child(mi)
	return mi

func _build_model() -> void:
	if ResourceLoader.exists("res://models/creature.glb"):
		var ps: PackedScene = load("res://models/creature.glb")
		add_child(ps.instantiate())
		return
	var mat := _mat()
	for i in 4:
		var pv := Node3D.new()
		pv.position = Vector3(LEG_X[i], LEG_LEN, LEG_Z[i])
		add_child(pv)
		_tube(pv, Vector3(0, -LEG_LEN, 0), Vector3(0, 0, 0), 0.9, 2.2, mat)
		legs.append(pv)
	var body := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 1.0
	sm.height = 2.0
	sm.radial_segments = 12
	sm.rings = 6
	body.mesh = sm
	body.material_override = mat
	body.scale = Vector3(14, 9, 26)
	body.position = Vector3(0, LEG_LEN + 4, 0)
	add_child(body)
	_tube(self, Vector3(0, 76, -20), Vector3(0, 98, -34), 4.5, 3.0, mat)
	_tube(self, Vector3(0, 98, -34), Vector3(0, 90, -48), 3.0, 2.2, mat)
	var head := MeshInstance3D.new()
	var hm := SphereMesh.new()
	hm.radius = 3.5
	hm.height = 7.0
	head.mesh = hm
	head.material_override = mat
	head.position = Vector3(0, 88, -50)
	add_child(head)
	for i in 14:
		var pv := Node3D.new()
		var a := TAU * i / 14.0
		pv.position = Vector3(cos(a) * 2.5, 87, -49 + sin(a) * 2.5)
		add_child(pv)
		_tube(pv, Vector3(0, -randf_range(30.0, 46.0), 0), Vector3.ZERO, 0.08, 0.4, mat)
		tentacles.append(pv)

# ---------- логика ----------
func _set(s: int) -> void:
	state = s
	match s:
		S.STAND:
			state_t = randf_range(10.0, 45.0)
		S.OBSERVE:
			state_t = randf_range(8.0, 25.0)
		S.ROAM:
			state_t = 300.0
			var base := global_position
			if randf() < 0.45:
				base = player.global_position
			var a := randf() * TAU
			target = base + Vector3(cos(a), 0, sin(a)) * randf_range(250.0, 600.0)
		S.INVESTIGATE:
			state_t = 180.0
		S.APPROACH:
			state_t = 240.0
		S.SEARCH:
			state_t = randf_range(50.0, 110.0)
			search_t = 0.0
			center = target
		S.LEAVE:
			state_t = 200.0
			var a2 := randf() * TAU
			target = global_position + Vector3(cos(a2), 0, sin(a2)) * 450.0

func hear(pos: Vector3, loud: float) -> void:
	var d := Vector2(pos.x - global_position.x, pos.z - global_position.z).length()
	if d > loud * randf_range(0.6, 1.3):
		return
	last_heard = Time.get_ticks_msec() / 1000.0
	target = Vector3(pos.x, 0, pos.z) + Vector3(randf_range(-20, 20), 0, randf_range(-20, 20))
	if state == S.APPROACH:
		return
	if state == S.INVESTIGATE:
		if d < 80.0 and randf() < 0.5:
			_set(S.APPROACH)
		return
	if randf() < 0.85:
		# иногда сначала замирает, потом идёт
		if randf() < 0.5:
			var tg := target
			_set(S.STAND)
			target = tg
			state_t = randf_range(3.0, 9.0)
			next_state = S.INVESTIGATE
		else:
			var tg2 := target
			_set(S.INVESTIGATE)
			target = tg2

func retreat() -> void:
	var a := randf() * TAU
	global_position = player.global_position + Vector3(cos(a), 0, sin(a)) * 500.0
	_set(S.LEAVE)
	speed = 0.0

func _yaw_to(p: Vector3) -> float:
	var to := p - global_position
	return atan2(-to.x, -to.z)

func _advance(delta: float) -> void:
	global_position += Vector3(-sin(yaw), 0, -cos(yaw)) * speed * delta
	global_position.y = world.ground_h(global_position.x, global_position.z)
	rotation.y = yaw

func _steer(delta: float, spd: float) -> bool:
	var to := Vector3(target.x - global_position.x, 0, target.z - global_position.z)
	if to.length() < 25.0:
		speed = move_toward(speed, 0.0, delta * 0.8)
		_advance(delta)
		return true
	yaw = lerp_angle(yaw, atan2(-to.x, -to.z), delta * 0.3)
	speed = move_toward(speed, spd, delta * 0.5)
	_advance(delta)
	return false

func _process(delta: float) -> void:
	if player == null:
		return
	t += delta
	var pp: Vector3 = player.global_position
	dist = Vector2(pp.x - global_position.x, pp.z - global_position.z).length()
	_ai(delta)
	_animate(delta)
	_audio(delta)

func _ai(delta: float) -> void:
	state_t -= delta
	var now := Time.get_ticks_msec() / 1000.0
	var sheltered: bool = world.player_sheltered()
	match state:
		S.STAND, S.OBSERVE:
			speed = move_toward(speed, 0.0, delta * 0.8)
			_advance(delta)
			if state == S.OBSERVE:
				yaw = lerp_angle(yaw, _yaw_to(player.global_position), delta * 0.05)
			if state_t <= 0.0:
				if next_state >= 0:
					var ns := next_state
					next_state = -1
					var tg := target
					_set(ns)
					target = tg
				else:
					var r := randf()
					if r < 0.5:
						_set(S.ROAM)
					elif r < 0.75:
						_set(S.OBSERVE)
					else:
						_set(S.STAND)
		S.ROAM:
			if _steer(delta, 3.0) or state_t <= 0.0:
				_set(S.STAND if randf() < 0.6 else S.OBSERVE)
		S.INVESTIGATE:
			if _steer(delta, 4.5):
				if now - last_heard < 15.0:
					_set(S.APPROACH)
				else:
					_set(S.SEARCH)
			elif state_t <= 0.0:
				_set(S.LEAVE)
		S.APPROACH:
			if sheltered and dist < 90.0:
				target = world.nearest_cabin_pos(player.global_position)
				_set(S.SEARCH)
			elif now - last_heard > 25.0 or state_t <= 0.0:
				_set(S.SEARCH)
			else:
				_steer(delta, 5.5)
		S.SEARCH:
			search_t -= delta
			if search_t <= 0.0:
				search_t = randf_range(8.0, 16.0)
				var a := randf() * TAU
				target = center + Vector3(cos(a), 0, sin(a)) * randf_range(30.0, 70.0)
			_steer(delta, 2.2)
			if sheltered and dist < 70.0:
				window_t -= delta
				if window_t <= 0.0:
					window_t = randf_range(25.0, 60.0)
					if randf() < 0.6:
						world.tentacle_window(player.global_position)
			if state_t <= 0.0:
				_set(S.LEAVE)
		S.LEAVE:
			if _steer(delta, 3.5) or state_t <= 0.0:
				_set(S.STAND)
	# поймал?
	if dist < 13.0 and state != S.LEAVE and not sheltered and player.control and not world.caught_busy:
		world.on_caught()

func _animate(delta: float) -> void:
	phase += speed * delta / 36.0
	var amp := clampf(speed / 3.0, 0.0, 1.0) * 0.25
	for i in legs.size():
		var s := sin((phase + LEG_OFF[i]) * TAU)
		legs[i].rotation.x = s * amp
		if leg_prev[i] > 0.0 and s <= 0.0 and speed > 0.3:
			_step(i, s)
		leg_prev[i] = s
	for i in tentacles.size():
		tentacles[i].rotation = Vector3(sin(t * 0.35 + i) * 0.14, 0, cos(t * 0.28 + i * 1.3) * 0.14)

func _step(i: int, _s: float) -> void:
	var local := Vector3(LEG_X[i], 0, LEG_Z[i] - LEG_LEN * sin(legs[i].rotation.x))
	var pos := global_transform * local
	pos.y = world.ground_h(pos.x, pos.z)
	if step_s:
		world.play3d(step_s, pos, 8.0, 1500.0, 45.0, "Creature", randf_range(0.45, 0.7))
	var d := Vector2(pos.x - player.global_position.x, pos.z - player.global_position.z).length()
	player.shake = maxf(player.shake, clampf(1.0 - d / 220.0, 0.0, 1.0) * 1.2)

func _audio(delta: float) -> void:
	lowpass.cutoff_hz = lerpf(16000.0, 700.0, smoothstep(40.0, 700.0, dist))
	var rv := clampf(1.0 - dist / 450.0, 0.0, 1.0)
	bed.volume_db = lerpf(-60.0, -10.0, rv * rv)
	world.wind_boost = clampf(1.0 - dist / 500.0, 0.0, 1.0) * 0.3
	if dist < 130.0 and speed > 0.5:
		player.shake = maxf(player.shake, clampf(1.0 - dist / 130.0, 0.0, 1.0) * 0.3)
	next_voice -= delta
	if next_voice > 0.0:
		return
	var pool: Array
	if dist > 450.0:
		pool = far_s
		next_voice = randf_range(30.0, 80.0)
	elif dist > 160.0:
		pool = far_s + mid_s
		next_voice = randf_range(15.0, 45.0)
	elif dist > 60.0:
		pool = mid_s + near_s
		next_voice = randf_range(10.0, 28.0)
	else:
		pool = near_s
		next_voice = randf_range(6.0, 18.0)
	if dist < 140.0 and randf() < 0.1 and roar_s.size() > 0:
		pool = roar_s
	if pool.is_empty():
		return
	var pos := global_position + Vector3(0, 55, 0)
	if randf() < 0.12:
		var pp: Vector3 = player.global_position
		pos = pp - (pos - pp)
	voice.stream = pool[randi() % pool.size()]
	voice.global_position = pos
	voice.pitch_scale = randf_range(0.7, 1.0)
	voice.play()

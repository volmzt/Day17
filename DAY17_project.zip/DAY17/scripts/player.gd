extends CharacterBody3D
const Synth = preload("res://scripts/synth.gd")
const Settings = preload("res://scripts/settings.gd")
const FL_E := 9.0
var beam: MeshInstance3D
var beam_mat: ShaderMaterial
var world
var ui
var head: Node3D
var cam: Camera3D
var flash_pivot: Node3D
var flash: SpotLight3D
var flash_on := true
var battery := 1.0
var spare_batteries := 1
var stamina := 1.0
var tension := 0.0
var yaw := 0.0
var pitch := 0.0
var look_vel := Vector2.ZERO
var bob_t := 0.0
var step_t := 0.0
var shake := 0.0
var inside := false
var control := false
var intro_t := 0.0
var interact_target = null
var hold_t := 0.0
var was_held := false
var tired := false
var sens := 0.004
var cam_intensity := 1.0
var resting := false
var steps := {}
var step_player: AudioStreamPlayer
var heart: AudioStreamPlayer
var breath_p: AudioStreamPlayer
var click: AudioStreamPlayer
var heart_t := 0.0
var flicker := 0.0

func _ready() -> void:
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.35
	cap.height = 1.7
	cs.shape = cap
	cs.position.y = 0.85
	add_child(cs)
	head = Node3D.new()
	head.position.y = 1.65
	add_child(head)
	cam = Camera3D.new()
	cam.fov = 75.0
	cam.near = 0.05
	cam.far = 260.0
	head.add_child(cam)
	flash_pivot = Node3D.new()
	head.add_child(flash_pivot)
	flash = SpotLight3D.new()
	flash.position = Vector3(0.15, -0.12, -0.2)
	flash.spot_range = 55.0
	flash.spot_angle = 27.0
	flash.spot_attenuation = 0.55
	flash.spot_angle_attenuation = 0.7
	flash.light_energy = FL_E
	flash.light_specular = 1.5
	flash.light_color = Color(1.0, 0.94, 0.8)
	flash.shadow_enabled = Settings.s["shadows"] > 0
	flash.shadow_blur = 1.5
	flash_pivot.add_child(flash)
	# видимый луч в тумане (имитация объёмного света)
	var sh := Shader.new()
	sh.code = """shader_type spatial;
render_mode unshaded, blend_add, cull_disabled, depth_draw_never, fog_disabled;
uniform float strength = 0.1;
varying float v;
void vertex() { v = clamp((VERTEX.y + 10.0) / 20.0, 0.0, 1.0); }
void fragment() {
	float f = pow(clamp(abs(dot(normalize(NORMAL), normalize(VIEW))), 0.0, 1.0), 1.5);
	float a = f * strength * (0.2 + 0.8 * v);
	ALBEDO = vec3(1.0, 0.93, 0.78) * a;
	ALPHA = 1.0;
}
"""
	beam_mat = ShaderMaterial.new()
	beam_mat.shader = sh
	var bc := CylinderMesh.new()
	bc.height = 20.0
	bc.top_radius = 0.03
	bc.bottom_radius = 6.0
	bc.radial_segments = 24
	bc.rings = 1
	bc.cap_top = false
	bc.cap_bottom = false
	beam = MeshInstance3D.new()
	beam.mesh = bc
	beam.material_override = beam_mat
	beam.position = flash.position + Vector3(0, 0, -10.0)
	beam.rotation.x = PI / 2.0
	beam.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	flash_pivot.add_child(beam)
	sens = 0.001 + Settings.s["sens"] * 0.0006
	cam_intensity = [0.0, 0.5, 1.0, 1.5][Settings.s["camfx"]]
	# модель фонарика и рука (упрощённо)
	var fm := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.035
	cm.bottom_radius = 0.03
	cm.height = 0.22
	fm.mesh = cm
	fm.rotation.x = PI / 2.0
	fm.position = Vector3(0.2, -0.2, -0.35)
	var fmat := StandardMaterial3D.new()
	fmat.albedo_color = Color(0.08, 0.08, 0.09)
	fmat.metallic = 0.6
	fmat.roughness = 0.4
	fm.material_override = fmat
	flash_pivot.add_child(fm)
	var hand := MeshInstance3D.new()
	var hb := BoxMesh.new()
	hb.size = Vector3(0.07, 0.07, 0.32)
	hand.mesh = hb
	hand.position = Vector3(0.21, -0.28, -0.2)
	hand.rotation.x = 0.3
	var hmat := StandardMaterial3D.new()
	hmat.albedo_color = Color(0.2, 0.15, 0.12)
	hand.material_override = hmat
	flash_pivot.add_child(hand)
	# звуки
	steps["mud"] = [Synth.noise(0.3, 0.18, 0.9, 12.0), Synth.noise(0.3, 0.14, 0.9, 10.0), Synth.noise(0.35, 0.2, 0.9, 9.0)]
	steps["road"] = [Synth.noise(0.2, 0.45, 0.7, 20.0), Synth.noise(0.2, 0.4, 0.7, 18.0)]
	steps["swamp"] = [Synth.noise(0.5, 0.3, 0.8, 5.0), Synth.noise(0.55, 0.25, 0.8, 4.5)]
	step_player = _mk_player(Synth.noise(0.2, 0.2, 0.5, 10.0), -4.0)
	heart = _mk_player(Synth.heartbeat(), -10.0)
	breath_p = _mk_player(Synth.breath(4.0), -50.0)
	breath_p.play()
	click = _mk_player(Synth.thump(0.05, 900.0, 90.0, 0.5), -8.0)

func _mk_player(s: AudioStream, db: float) -> AudioStreamPlayer:
	var p := AudioStreamPlayer.new()
	p.stream = s
	p.volume_db = db
	p.bus = "SFX"
	add_child(p)
	return p

func toggle_flash() -> void:
	flash_on = not flash_on
	click.play()
	if ui:
		ui.show_hud()

func use_battery() -> void:
	if spare_batteries > 0 and battery < 0.9:
		spare_batteries -= 1
		battery = 1.0
		click.play()
		world.make_noise(global_position, 12.0)
		ui.toast("Батарея заменена")
	elif spare_batteries == 0:
		ui.toast("Нет запасных батарей")
	ui.show_hud()

func add_battery() -> void:
	spare_batteries += 1
	ui.toast("Найдена батарея")
	ui.show_hud()

func show_note(t: String) -> void:
	ui.note = t

func rest() -> void:
	if resting:
		return
	resting = true
	control = false
	var tw := create_tween()
	tw.tween_property(ui, "fade", 1.0, 2.0)
	await get_tree().create_timer(3.0).timeout
	ui.msg = "..."
	await get_tree().create_timer(10.0).timeout
	stamina = 1.0
	tension *= 0.5
	world.rest_event()
	ui.msg = ""
	var tw2 := create_tween()
	tw2.tween_property(ui, "fade", 0.0, 3.0)
	control = true
	resting = false

func _physics_process(delta: float) -> void:
	if world == null or ui == null:
		return
	intro_t += delta
	var mv: Vector2 = ui.move
	var look: Vector2 = ui.consume_look()
	mv.x += float(Input.is_key_pressed(KEY_D)) - float(Input.is_key_pressed(KEY_A))
	mv.y += float(Input.is_key_pressed(KEY_S)) - float(Input.is_key_pressed(KEY_W))
	look.x += (float(Input.is_key_pressed(KEY_RIGHT)) - float(Input.is_key_pressed(KEY_LEFT))) * 6.0
	look.y += (float(Input.is_key_pressed(KEY_DOWN)) - float(Input.is_key_pressed(KEY_UP))) * 6.0
	mv = mv.limit_length(1.0)
	if not control:
		mv = Vector2.ZERO
		look = Vector2.ZERO
	# вступление: лежим на дороге и встаём
	var base_h := 1.65
	if intro_t < 8.0 and not control and not resting:
		var k := clampf((intro_t - 2.5) / 5.0, 0.0, 1.0)
		k = k * k * (3.0 - 2.0 * k)
		base_h = lerpf(0.3, 1.65, k)
		pitch = lerpf(0.8, 0.0, k)
		if intro_t >= 8.0:
			control = true
	elif intro_t >= 8.0 and not control and not resting and ui.fade < 0.5 and not world.caught_busy:
		control = true
	# взгляд с инерцией
	look_vel = look_vel.lerp(look, clampf(delta * 18.0, 0.0, 1.0))
	yaw -= look_vel.x * sens
	pitch = clampf(pitch - look_vel.y * sens, -1.4, 1.4)
	rotation.y = yaw
	# движение
	var running := mv.length() > 0.92 and stamina > 0.0 and not tired
	var spd := 2.3
	if running:
		spd = 4.4
	if tired:
		spd = 1.6
	if world.surface_at(global_position) == "swamp":
		spd *= 0.75
	var dir := transform.basis.x * mv.x + transform.basis.z * mv.y
	velocity = dir * spd
	velocity.y = 0.0
	move_and_slide()
	world.push_out(self)
	var gy: float = world.ground_h(global_position.x, global_position.z)
	global_position.y = lerpf(global_position.y, gy, clampf(delta * 12.0, 0.0, 1.0))
	var moving := mv.length() > 0.1
	if running:
		stamina = maxf(0.0, stamina - delta * 0.12)
		if stamina <= 0.0:
			tired = true
	else:
		stamina = minf(1.0, stamina + delta * (0.06 if moving else 0.12))
		if tired and stamina > 0.3:
			tired = false
	# шаги
	if moving:
		step_t -= spd * delta * mv.length()
		if step_t <= 0.0:
			step_t = 2.0 if running else 1.4
			_do_step(running)
	inside = world.is_inside(global_position)
	# голова: покачивание, дрожь, толчки
	if moving:
		bob_t += delta * spd * 1.6
	var amp := (0.06 if running else 0.03) * cam_intensity
	var by := sin(bob_t * 2.0) * amp if moving else 0.0
	shake = maxf(0.0, shake - delta * 0.5)
	var trem := tension * 0.004 + shake * 0.02
	head.position.y = base_h + by + randf_range(-1.0, 1.0) * shake * 0.03
	head.rotation = Vector3(pitch + randf_range(-trem, trem), 0.0, sin(bob_t) * 0.01 * cam_intensity + randf_range(-trem, trem))
	flash_pivot.rotation = flash_pivot.rotation.lerp(Vector3(-look_vel.y * 0.01, -look_vel.x * 0.01, 0.0), clampf(delta * 6.0, 0.0, 1.0))
	_update_flash(delta)
	_update_tension(delta)
	_scan_interact(delta)

func _do_step(running: bool) -> void:
	var s: String = world.surface_at(global_position)
	var arr: Array = steps[s]
	step_player.stream = arr[randi() % arr.size()]
	step_player.pitch_scale = randf_range(0.85, 1.15)
	step_player.volume_db = -2.0 if running else -9.0
	step_player.play()
	if randf() < (0.8 if running else 0.4):
		world.make_noise(global_position, 110.0 if running else 24.0)

func _update_flash(delta: float) -> void:
	if flash_on and battery > 0.0:
		battery = maxf(0.0, battery - delta / 1200.0)
	flash.visible = flash_on and battery > 0.0
	beam.visible = flash.visible
	flicker = maxf(0.0, flicker - delta * 4.0)
	if randf() < delta * (0.02 + maxf(0.0, tension - 0.5) * 0.6 + (0.5 if battery < 0.08 else 0.0)):
		flicker = 0.8
	var fe := smoothstep(0.0, 0.15, battery) * (1.0 - flicker)
	flash.light_energy = FL_E * fe
	beam_mat.set_shader_parameter("strength", clampf(world.env.fog_density * 1.3, 0.06, 0.24) * fe)

func _update_tension(delta: float) -> void:
	var target := 0.0
	if world.creature:
		target = clampf(1.0 - world.creature.dist / 240.0, 0.0, 1.0) * 0.95
	if target > tension:
		tension = minf(target, tension + delta * 0.25)
	else:
		var rate := 0.04
		if inside:
			rate = 0.12
		if world.creature and world.creature.dist < 150.0:
			rate *= 0.25
		tension = maxf(target, tension - delta * rate)
	if tension > 0.25:
		heart_t -= delta
		if heart_t <= 0.0:
			heart.volume_db = lerpf(-24.0, -4.0, tension)
			heart.play()
			heart_t = lerpf(1.1, 0.45, tension)
	breath_p.volume_db = lerpf(-50.0, -12.0, clampf((tension - 0.3) * 1.5, 0.0, 1.0))

var _held_prev := false
func _scan_interact(delta: float) -> void:
	interact_target = null
	var best := 2.6
	var fwd := -head.global_transform.basis.z
	for n in get_tree().get_nodes_in_group("interact"):
		if not is_instance_valid(n):
			continue
		var to: Vector3 = n.global_position - head.global_position
		var d := to.length()
		if d < best and (d < 1.0 or to.normalized().dot(fwd) > 0.4):
			best = d
			interact_target = n
	ui.prompt = interact_target.prompt if (interact_target and control) else ""
	var held: bool = ui.interact_held or Input.is_key_pressed(KEY_E)
	if held:
		hold_t += delta
	elif _held_prev:
		if interact_target and control:
			interact_target.interact(self, hold_t > 0.5)
		hold_t = 0.0
	_held_prev = held

extends CharacterBody3D
const Synth = preload("res://scripts/synth.gd")
const Settings = preload("res://scripts/settings.gd")
const Items = preload("res://scripts/items.gd")
const MapCanvas = preload("res://scripts/map_canvas.gd")
const FL_E := 9.0
var world
var ui
var inv_ui
var head: Node3D
var cam: Camera3D
var flash_pivot: Node3D
var flash: SpotLight3D
var beam: MeshInstance3D
var beam_mat: ShaderMaterial
var flash_on := true
var battery := 1.0
var stamina := 1.0
var tension := 0.0
var health := 1.0
var hunger := 1.0
var thirst := 1.0
var fatigue := 0.0
var inv: Array = []
var yaw := 0.0
var pitch := 0.0
var look_vel := Vector2.ZERO
var bob_t := 0.0
var step_t := 0.0
var shake := 0.0
var step_kick := 0.0
var roll_s := 0.0
var t_all := 0.0
var inside := false
var control := false
var intro_t := 0.0
var interact_target = null
var hold_t := 0.0
var tired := false
var crouched := false
var crouch_k := 0.0
var sens := 0.004
var cam_intensity := 1.0
var resting := false
var map_up := false
var map_k := 0.0
var map_vp: SubViewport
var map_canvas
var map_node: Node3D
var steps := {}
var step_player: AudioStreamPlayer
var heart: AudioStreamPlayer
var breath_p: AudioStreamPlayer
var click: AudioStreamPlayer
var sfx_p: AudioStreamPlayer
var rustle_s: AudioStreamWAV
var grumble_s: AudioStreamWAV
var heart_t := 0.0
var flicker := 0.0
var grumble_t := 30.0
var warn_hunger := false
var warn_thirst := false
var warn_tired := false
var _held_prev := false
var _scan_t := 0.0

var spare_batteries: int:
	get:
		return inv_count("battery")

func _ready() -> void:
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.35
	cap.height = 1.7
	cs.shape = cap
	cs.position.y = 0.85
	add_child(cs)
	head = Node3D.new()
	head.position.y = 1.65
	add_child(head)
	cam = Camera3D.new()
	cam.fov = 75.0
	cam.near = 0.05
	cam.far = 260.0
	head.add_child(cam)
	flash_pivot = Node3D.new()
	head.add_child(flash_pivot)
	flash = SpotLight3D.new()
	flash.position = Vector3(0.15, -0.12, -0.2)
	flash.spot_range = 55.0
	flash.spot_angle = 27.0
	flash.spot_attenuation = 0.55
	flash.spot_angle_attenuation = 0.7
	flash.light_energy = FL_E
	flash.light_specular = 1.5
	flash.light_color = Color(1.0, 0.94, 0.8)
	flash.shadow_enabled = Settings.s["shadows"] > 0
	flash.shadow_blur = 1.5
	flash_pivot.add_child(flash)
	_make_beam()
	sens = 0.001 + Settings.s["sens"] * 0.0006
	cam_intensity = [0.0, 0.5, 1.0, 1.5][Settings.s["camfx"]]
	# модель фонарика и рука
	var fm := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.035
	cm.bottom_radius = 0.03
	cm.height = 0.22
	fm.mesh = cm
	fm.rotation.x = PI / 2.0
	fm.position = Vector3(0.2, -0.2, -0.35)
	var fmat := StandardMaterial3D.new()
	fmat.albedo_color = Color(0.08, 0.08, 0.09)
	fmat.metallic = 0.6
	fmat.roughness = 0.4
	fm.material_override = fmat
	flash_pivot.add_child(fm)
	var hand := MeshInstance3D.new()
	var hb := BoxMesh.new()
	hb.size = Vector3(0.07, 0.07, 0.32)
	hand.mesh = hb
	hand.position = Vector3(0.21, -0.28, -0.2)
	hand.rotation.x = 0.3
	var hmat := StandardMaterial3D.new()
	hmat.albedo_color = Color(0.2, 0.15, 0.12)
	hand.material_override = hmat
	flash_pivot.add_child(hand)
	_make_map(hmat)
	# звуки
	for k in ["grass", "needles", "dry", "mud", "road", "swamp", "wood"]:
		steps[k] = [Synth.step(k), Synth.step(k), Synth.step(k)]
	rustle_s = Synth.step("dry")
	grumble_s = Synth.thump(1.3, 52.0, 2.2, 0.7)
	step_player = _mk_player(Synth.step("grass"), -4.0)
	heart = _mk_player(Synth.heartbeat(), -10.0)
	breath_p = _mk_player(Synth.breath(4.0), -50.0)
	breath_p.play()
	click = _mk_player(Synth.thump(0.05, 900.0, 90.0, 0.5), -8.0)
	sfx_p = _mk_player(rustle_s, -10.0)

func _make_beam() -> void:
	var sh := Shader.new()
	sh.code = """shader_type spatial;
render_mode unshaded, blend_add, cull_disabled, depth_draw_never, fog_disabled;
uniform float strength = 0.1;
varying float v;
void vertex() { v = clamp((VERTEX.y + 10.0) / 20.0, 0.0, 1.0); }
void fragment() {
	float f = pow(clamp(abs(dot(normalize(NORMAL), normalize(VIEW))), 0.0, 1.0), 1.5);
	float a = f * strength * (0.2 + 0.8 * v);
	ALBEDO = vec3(1.0, 0.93, 0.78) * a;
	ALPHA = 1.0;
}
"""
	beam_mat = ShaderMaterial.new()
	beam_mat.shader = sh
	var bc := CylinderMesh.new()
	bc.height = 20.0
	bc.top_radius = 0.03
	bc.bottom_radius = 6.0
	bc.radial_segments = 24
	bc.rings = 1
	bc.cap_top = false
	bc.cap_bottom = false
	beam = MeshInstance3D.new()
	beam.mesh = bc
	beam.material_override = beam_mat
	beam.position = flash.position + Vector3(0, 0, -10.0)
	beam.rotation.x = PI / 2.0
	beam.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	flash_pivot.add_child(beam)

func _make_map(hand_mat: Material) -> void:
	map_vp = SubViewport.new()
	map_vp.size = Vector2i(512, 360)
	map_vp.transparent_bg = false
	map_vp.set("disable_3d", true)
	map_vp.render_target_update_mode = SubViewport.UPDATE_DISABLED
	add_child(map_vp)
	map_canvas = MapCanvas.new()
	map_canvas.player = self
	map_canvas.world = world
	map_vp.add_child(map_canvas)
	map_node = Node3D.new()
	map_node.visible = false
	head.add_child(map_node)
	var paper := MeshInstance3D.new()
	var qm := QuadMesh.new()
	qm.size = Vector2(0.46, 0.33)
	paper.mesh = qm
	var pm := StandardMaterial3D.new()
	pm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	pm.albedo_texture = map_vp.get_texture()
	pm.cull_mode = BaseMaterial3D.CULL_DISABLED
	paper.material_override = pm
	map_node.add_child(paper)
	for sx in [-0.24, 0.24]:
		var hnd := MeshInstance3D.new()
		var hb := BoxMesh.new()
		hb.size = Vector3(0.07, 0.07, 0.2)
		hnd.mesh = hb
		hnd.material_override = hand_mat
		hnd.position = Vector3(sx, -0.13, 0.08)
		map_node.add_child(hnd)

func _mk_player(s: AudioStream, db: float) -> AudioStreamPlayer:
	var p := AudioStreamPlayer.new()
	p.stream = s
	p.volume_db = db
	p.bus = "SFX"
	add_child(p)
	return p

# ---------- кнопки ----------
func toggle_flash() -> void:
	flash_on = not flash_on
	click.play()
	if ui:
		ui.show_hud()

func toggle_crouch() -> void:
	if control:
		crouched = not crouched
		ui.toast("Присел" if crouched else "Встал")

func toggle_bag() -> void:
	if inv_ui != null and control:
		inv_ui.toggle()

func toggle_map() -> void:
	if not control:
		return
	if inv_count("map") == 0:
		ui.toast("У тебя нет карты")
		return
	map_up = not map_up
	map_vp.render_target_update_mode = SubViewport.UPDATE_ALWAYS if map_up else SubViewport.UPDATE_DISABLED
	map_canvas.queue_redraw()
	sfx_rustle()

func use_battery() -> void:
	if inv_count("battery") > 0 and battery < 0.9:
		inv_remove("battery", 1)
		battery = 1.0
		click.play()
		world.make_noise(global_position, 12.0)
		ui.toast("Батарея заменена")
	elif inv_count("battery") == 0:
		ui.toast("Нет запасных батарей")
	else:
		ui.toast("Фонарик ещё заряжен")
	ui.show_hud()

func show_note(t: String) -> void:
	ui.note = t

func sfx_rustle() -> void:
	sfx_p.stream = rustle_s
	sfx_p.pitch_scale = randf_range(0.5, 0.7)
	sfx_p.volume_db = -8.0
	sfx_p.play()

func sfx_pick() -> void:
	sfx_p.stream = rustle_s
	sfx_p.pitch_scale = randf_range(0.9, 1.2)
	sfx_p.volume_db = -14.0
	sfx_p.play()

# ---------- инвентарь ----------
func inv_weight() -> float:
	var w := 0.0
	for s in inv:
		w += float(Items.ITEMS[s["id"]]["w"]) * int(s["n"])
	return w

func inv_count(id: String) -> int:
	var c := 0
	for s in inv:
		if s["id"] == id:
			c += int(s["n"])
	return c

func inv_add(id: String, n: int = 1) -> bool:
	var def: Dictionary = Items.ITEMS[id]
	if inv_weight() + float(def["w"]) * n > Items.MAX_W:
		return false
	var left := n
	for s in inv:
		if left <= 0:
			break
		if s["id"] == id and int(s["n"]) < int(def["stack"]):
			var add := mini(left, int(def["stack"]) - int(s["n"]))
			s["n"] = int(s["n"]) + add
			left -= add
	while left > 0:
		if inv.size() >= Items.SLOTS:
			return false
		var add2 := mini(left, int(def["stack"]))
		inv.append({"id": id, "n": add2})
		left -= add2
	return true

func inv_remove(id: String, n: int = 1) -> void:
	var left := n
	var i := inv.size() - 1
	while i >= 0 and left > 0:
		if inv[i]["id"] == id:
			var take := mini(left, int(inv[i]["n"]))
			inv[i]["n"] = int(inv[i]["n"]) - take
			left -= take
			if int(inv[i]["n"]) <= 0:
				inv.remove_at(i)
		i -= 1

func use_item(id: String) -> void:
	if id == "battery":
		use_battery()
	elif id == "food":
		if hunger > 0.85:
			ui.toast("Не хочется есть")
		else:
			inv_remove("food", 1)
			hunger = minf(1.0, hunger + 0.45)
			world.make_noise(global_position, 8.0)
			ui.toast("Ты поел")
			sfx_pick()
	elif id == "water":
		if thirst > 0.85:
			ui.toast("Не хочется пить")
		else:
			inv_remove("water", 1)
			thirst = minf(1.0, thirst + 0.55)
			ui.toast("Ты напился")
			sfx_pick()
	elif id == "bandage":
		if health > 0.95:
			ui.toast("Ран нет")
		else:
			inv_remove("bandage", 1)
			health = minf(1.0, health + 0.4)
			ui.toast("Рана перевязана")
	elif id == "map":
		if inv_ui != null:
			inv_ui.toggle()
		toggle_map()
	else:
		ui.toast(String(Items.ITEMS[id]["desc"]))

func drop_item(id: String) -> void:
	inv_remove(id, 1)
	var fwd := -global_transform.basis.z
	world.spawn_drop(id, global_position + fwd * 0.9 + Vector3(0, 0.3, 0))
	world.make_noise(global_position, 35.0)
	sfx_pick()
	ui.toast("Выброшено")

# ---------- сохранение ----------
func save_state() -> Dictionary:
	return {"battery": battery, "stamina": stamina, "health": health, "hunger": hunger, "thirst": thirst,
		"fatigue": fatigue, "inv": inv}

func load_state(d: Dictionary) -> void:
	battery = float(d.get("battery", 1.0))
	stamina = float(d.get("stamina", 1.0))
	health = float(d.get("health", 1.0))
	hunger = float(d.get("hunger", 1.0))
	thirst = float(d.get("thirst", 1.0))
	fatigue = float(d.get("fatigue", 0.0))
	inv = []
	for s in d.get("inv", []):
		inv.append({"id": String(s["id"]), "n": int(s["n"])})

func rest() -> void:
	if resting:
		return
	resting = true
	control = false
	var tw := create_tween()
	tw.tween_property(ui, "fade", 1.0, 2.0)
	await get_tree().create_timer(3.0).timeout
	ui.msg = "..."
	await get_tree().create_timer(10.0).timeout
	stamina = 1.0
	fatigue = 0.0
	hunger = maxf(0.0, hunger - 0.06)
	thirst = maxf(0.0, thirst - 0.08)
	tension *= 0.5
	world.rest_event()
	ui.msg = ""
	var tw2 := create_tween()
	tw2.tween_property(ui, "fade", 0.0, 3.0)
	control = true
	resting = false

# ---------- основной цикл ----------
func _physics_process(delta: float) -> void:
	if world == null or ui == null:
		return
	t_all += delta
	intro_t += delta
	var blocked: bool = inv_ui != null and inv_ui.open
	ui.blocked = blocked
	var mv: Vector2 = ui.move
	var look: Vector2 = ui.consume_look()
	mv.x += float(Input.is_key_pressed(KEY_D)) - float(Input.is_key_pressed(KEY_A))
	mv.y += float(Input.is_key_pressed(KEY_S)) - float(Input.is_key_pressed(KEY_W))
	look.x += (float(Input.is_key_pressed(KEY_RIGHT)) - float(Input.is_key_pressed(KEY_LEFT))) * 6.0
	look.y += (float(Input.is_key_pressed(KEY_DOWN)) - float(Input.is_key_pressed(KEY_UP))) * 6.0
	mv = mv.limit_length(1.0)
	if not control or blocked:
		mv = Vector2.ZERO
		look = Vector2.ZERO
	var base_h := 1.65
	if intro_t < 8.0 and not control and not resting:
		var k := clampf((intro_t - 2.5) / 5.0, 0.0, 1.0)
		k = k * k * (3.0 - 2.0 * k)
		base_h = lerpf(0.3, 1.65, k)
		pitch = lerpf(0.8, 0.0, k)
	elif intro_t >= 8.0 and not control and not resting and ui.fade < 0.5 and not world.caught_busy:
		control = true
	crouch_k = move_toward(crouch_k, 1.0 if crouched else 0.0, delta * 4.0)
	if control or resting:
		base_h = lerpf(1.65, 0.95, crouch_k)
	look_vel = look_vel.lerp(look, clampf(delta * 18.0, 0.0, 1.0))
	yaw -= look_vel.x * sens
	pitch = clampf(pitch - look_vel.y * sens, -1.4, 1.4)
	rotation.y = yaw
	var moving := mv.length() > 0.1
	var running := mv.length() > 0.92 and stamina > 0.0 and not tired and not crouched
	var spd := 2.3
	if running:
		spd = 4.4
	if crouched:
		spd = 1.3
	if tired:
		spd = minf(spd, 1.6)
	if hunger < 0.1 or thirst < 0.1:
		spd *= 0.85
	if map_up:
		spd *= 0.8
	var surf: String = world.surface_at(global_position)
	if surf == "swamp":
		spd *= 0.75
	var dir := transform.basis.x * mv.x + transform.basis.z * mv.y
	velocity = dir * spd
	velocity.y = 0.0
	move_and_slide()
	world.push_out(self)
	var gy: float = world.ground_h(global_position.x, global_position.z)
	global_position.y = lerpf(global_position.y, gy, clampf(delta * 12.0, 0.0, 1.0))
	# выносливость, усталость
	var regen := 0.06 if moving else 0.12
	regen *= (1.0 - 0.5 * fatigue)
	if hunger < 0.15 or thirst < 0.15:
		regen *= 0.5
	if running:
		stamina = maxf(0.0, stamina - delta * 0.12)
		fatigue = minf(1.0, fatigue + delta * 0.002)
		if stamina <= 0.0:
			tired = true
	else:
		stamina = minf(1.0, stamina + delta * regen)
		if tired and stamina > 0.3:
			tired = false
	fatigue = minf(1.0, fatigue + delta * 0.0004)
	_survival(delta)
	# шаги
	if moving:
		step_t -= spd * delta * mv.length()
		if step_t <= 0.0:
			step_t = 2.0 if running else (1.1 if crouched else 1.4)
			_do_step(running, surf)
	inside = world.is_inside(global_position)
	_update_camera(delta, mv, running, moving, base_h)
	_update_flash(delta)
	_update_tension(delta)
	_scan_interact(delta)

func _survival(delta: float) -> void:
	hunger = maxf(0.0, hunger - delta / 2400.0)
	thirst = maxf(0.0, thirst - delta / 1500.0)
	if hunger < 0.3 and not warn_hunger:
		warn_hunger = true
		ui.toast("Хочется есть")
	if hunger > 0.5:
		warn_hunger = false
	if thirst < 0.3 and not warn_thirst:
		warn_thirst = true
		ui.toast("Хочется пить")
	if thirst > 0.5:
		warn_thirst = false
	if fatigue > 0.7 and not warn_tired:
		warn_tired = true
		ui.toast("Ты устал. Нужен отдых")
	if fatigue < 0.4:
		warn_tired = false
	if hunger < 0.3:
		grumble_t -= delta
		if grumble_t <= 0.0:
			grumble_t = randf_range(40.0, 90.0)
			sfx_p.stream = grumble_s
			sfx_p.pitch_scale = 1.0
			sfx_p.volume_db = -14.0
			sfx_p.play()
			world.make_noise(global_position, 12.0)
	if hunger < 0.03 or thirst < 0.03:
		health -= delta / 400.0
	elif hunger > 0.4 and thirst > 0.4 and health < 1.0:
		health = minf(1.0, health + delta / 900.0)
	if health <= 0.0 and not world.caught_busy:
		health = 0.4
		world.on_caught()

func _do_step(running: bool, surf: String) -> void:
	var arr: Array = steps[surf]
	step_player.stream = arr[randi() % arr.size()]
	step_player.pitch_scale = randf_range(0.88, 1.12)
	step_player.volume_db = -3.0 if running else (-14.0 if crouched else -9.0)
	step_player.play()
	step_kick = 0.05 if running else 0.025
	var loud := 110.0 if running else (8.0 if crouched else 24.0)
	if randf() < (0.8 if running else 0.4):
		world.make_noise(global_position, loud)

func _update_camera(delta: float, mv: Vector2, running: bool, moving: bool, base_h: float) -> void:
	if moving:
		bob_t += delta * (7.5 if running else 5.0) * (0.7 if crouched else 1.0)
	var amp := (0.065 if running else 0.032) * cam_intensity
	if crouched:
		amp *= 0.6
	var by := 0.0
	var bx := 0.0
	if moving:
		by = sin(bob_t * 2.0) * amp
		bx = cos(bob_t) * amp * 0.7
	var breathe := sin(t_all * 1.5) * 0.004 * (1.0 + tension * 2.0 + fatigue) * cam_intensity
	shake = maxf(0.0, shake - delta * 0.5)
	step_kick = lerpf(step_kick, 0.0, clampf(delta * 8.0, 0.0, 1.0))
	var trem := (tension * 0.004 + shake * 0.02 + (fatigue * 0.002 if fatigue > 0.6 else 0.0)) * clampf(cam_intensity, 0.3, 1.5)
	head.position = Vector3(bx, base_h + by - step_kick * cam_intensity + randf_range(-1.0, 1.0) * shake * 0.03, 0.0)
	var lean := -mv.x * 0.035 - look_vel.x * 0.0015
	roll_s = lerpf(roll_s, lean * cam_intensity, clampf(delta * 6.0, 0.0, 1.0))
	var sway := 0.0
	if moving:
		sway = sin(bob_t) * 0.012 * cam_intensity
	head.rotation = Vector3(pitch + breathe + step_kick * 0.5 + randf_range(-trem, trem), 0.0, roll_s + sway + randf_range(-trem, trem))
	var fov_t := 75.0
	if running:
		fov_t += 10.0 * minf(cam_intensity, 1.5)
	cam.fov = lerpf(cam.fov, fov_t, clampf(delta * 4.0, 0.0, 1.0))
	var lag := Vector3(-look_vel.y * 0.01, -look_vel.x * 0.01, 0.0)
	if moving:
		lag += Vector3(sin(bob_t * 2.0) * 0.01, cos(bob_t) * 0.01, 0.0)
	flash_pivot.rotation = flash_pivot.rotation.lerp(lag, clampf(delta * 6.0, 0.0, 1.0))
	# карта в руке
	map_k = move_toward(map_k, 1.0 if map_up else 0.0, delta * 2.2)
	map_node.visible = map_k > 0.02
	var ek := map_k * map_k * (3.0 - 2.0 * map_k)
	map_node.position = Vector3(-0.1 + bx * 0.5, lerpf(-0.7, -0.17, ek) + by * 0.5, -0.46)
	map_node.rotation = Vector3(-0.3, 0.12, 0.04)

func _update_flash(delta: float) -> void:
	if flash_on and battery > 0.0:
		battery = maxf(0.0, battery - delta / 1200.0)
	flash.visible = flash_on and battery > 0.0
	beam.visible = flash.visible
	flicker = maxf(0.0, flicker - delta * 4.0)
	if randf() < delta * (0.02 + maxf(0.0, tension - 0.5) * 0.6 + (0.5 if battery < 0.08 else 0.0)):
		flicker = 0.8
	var fe := smoothstep(0.0, 0.15, battery) * (1.0 - flicker)
	flash.light_energy = FL_E * fe
	beam_mat.set_shader_parameter("strength", clampf(world.env.fog_density * 1.3, 0.06, 0.24) * fe)

func _update_tension(delta: float) -> void:
	var target := 0.0
	if world.creature:
		target = clampf(1.0 - world.creature.dist / 240.0, 0.0, 1.0) * 0.95
	if target > tension:
		tension = minf(target, tension + delta * 0.25)
	else:
		var rate := 0.04
		if inside:
			rate = 0.12
		if world.creature and world.creature.dist < 150.0:
			rate *= 0.25
		tension = maxf(target, tension - delta * rate)
	if tension > 0.25:
		heart_t -= delta
		if heart_t <= 0.0:
			heart.volume_db = lerpf(-24.0, -4.0, tension)
			heart.play()
			heart_t = lerpf(1.1, 0.45, tension)
	breath_p.volume_db = lerpf(-50.0, -12.0, clampf((tension - 0.3) * 1.5, 0.0, 1.0))

func _scan_interact(delta: float) -> void:
	var blocked: bool = inv_ui != null and inv_ui.open
	_scan_t -= delta
	if _scan_t <= 0.0 or interact_target == null:
		_scan_t = 0.1
		interact_target = null
		var best := 2.6
		var fwd := -head.global_transform.basis.z
		for n in get_tree().get_nodes_in_group("interact"):
			if not is_instance_valid(n):
				continue
			var to: Vector3 = n.global_position - head.global_position
			var d := to.length()
			if d < best and (d < 1.0 or to.normalized().dot(fwd) > 0.4):
				best = d
				interact_target = n
	elif not is_instance_valid(interact_target):
		interact_target = null
	if interact_target != null and control and not blocked:
		var p3: Vector3 = interact_target.global_position + Vector3(0, 0.1, 0)
		if not cam.is_position_behind(p3):
			var sp: Vector2 = cam.unproject_position(p3)
			var vs := get_viewport().get_visible_rect().size
			sp.x = clampf(sp.x, 100.0, vs.x - 100.0)
			sp.y = clampf(sp.y, 120.0, vs.y - 130.0)
			ui.interact_pos = sp
			ui.interact_vis = true
			ui.prompt = String(interact_target.prompt)
		else:
			ui.interact_vis = false
	else:
		ui.interact_vis = false
	ui.hold_ratio = clampf(hold_t / 0.5, 0.0, 1.0)
	var held: bool = ui.interact_held or Input.is_key_pressed(KEY_E)
	if held:
		hold_t += delta
	elif _held_prev:
		if interact_target != null and is_instance_valid(interact_target) and control and not blocked:
			interact_target.interact(self, hold_t > 0.5)
		hold_t = 0.0
	_held_prev = held

extends RefCounted
# Процедурная геометрия: лофт-трубы, деревья, камни, трава, папоротник.

class MB:
	var v := PackedVector3Array()
	var n := PackedVector3Array()
	var c := PackedColorArray()
	var u := PackedVector2Array()
	var tg := PackedFloat32Array()
	var idx := PackedInt32Array()

	func vert(p: Vector3, nrm: Vector3, col: Color, uv: Vector2) -> int:
		v.append(p)
		n.append(nrm)
		c.append(col)
		u.append(uv)
		var t := nrm.cross(Vector3.UP)
		if t.length() < 0.01:
			t = Vector3.RIGHT
		t = t.normalized()
		tg.append(t.x)
		tg.append(t.y)
		tg.append(t.z)
		tg.append(1.0)
		return v.size() - 1

	func tri(a: int, b: int, d: int) -> void:
		idx.append(a)
		idx.append(b)
		idx.append(d)

	func loft(pts: Array, radii: Array, sides: int, col_a: Color, col_b: Color, nz: FastNoiseLite = null, amp: float = 0.0, uvs: Vector2 = Vector2(2.0, 0.15), caps: bool = false) -> void:
		var cnt := pts.size()
		var base := v.size()
		var t0: Vector3 = (pts[1] - pts[0]).normalized()
		var ref := Vector3.RIGHT if absf(t0.dot(Vector3.RIGHT)) < 0.9 else Vector3.FORWARD
		var nrm: Vector3 = t0.cross(ref).normalized()
		var acc := 0.0
		for i in cnt:
			var t: Vector3
			if i == 0:
				t = (pts[1] - pts[0]).normalized()
			elif i == cnt - 1:
				t = (pts[i] - pts[i - 1]).normalized()
			else:
				t = (pts[i + 1] - pts[i - 1]).normalized()
			nrm = (nrm - t * nrm.dot(t)).normalized()
			var bn: Vector3 = t.cross(nrm)
			if i > 0:
				acc += (pts[i] as Vector3).distance_to(pts[i - 1])
			var col := col_a.lerp(col_b, float(i) / float(cnt - 1))
			for a in sides + 1:
				var ang := TAU * a / sides
				var dir: Vector3 = nrm * cos(ang) + bn * sin(ang)
				var r: float = radii[i]
				var p: Vector3 = pts[i]
				if nz != null:
					r *= 1.0 + amp * nz.get_noise_3d(p.x + dir.x * 1.5, p.y + dir.y * 1.5, p.z + dir.z * 1.5)
				vert(p + dir * r, dir, col, Vector2(uvs.x * a / sides, acc * uvs.y))
		for i in cnt - 1:
			for a in sides:
				var i0 := base + i * (sides + 1) + a
				var i2 := i0 + sides + 1
				tri(i0, i2, i0 + 1)
				tri(i0 + 1, i2, i2 + 1)
		if caps:
			var tstart: Vector3 = (pts[1] - pts[0]).normalized()
			var tend: Vector3 = (pts[cnt - 1] - pts[cnt - 2]).normalized()
			var c0 := vert(pts[0], -tstart, col_a, Vector2(0.5, 0.5))
			var c1 := vert(pts[cnt - 1], tend, col_b, Vector2(0.5, 0.5))
			for a in sides:
				tri(c0, base + a, base + a + 1)
				var lb := base + (cnt - 1) * (sides + 1)
				tri(c1, lb + a, lb + a + 1)

	func sphere(center: Vector3, scl: Vector3, col: Color, seg: int = 10, rings: int = 6, nz: FastNoiseLite = null, amp: float = 0.0) -> void:
		var base := v.size()
		for j in rings + 1:
			var phi := PI * j / rings
			for i in seg + 1:
				var th := TAU * i / seg
				var d := Vector3(sin(phi) * cos(th), cos(phi), sin(phi) * sin(th))
				var r := 1.0
				if nz != null:
					r += amp * nz.get_noise_3d(center.x + d.x * 2.0, center.y + d.y * 2.0, center.z + d.z * 2.0)
				vert(center + d * scl * r, d, col, Vector2(float(i) / seg * 2.0, float(j) / rings * 2.0))
		for j in rings:
			for i in seg:
				var a := base + j * (seg + 1) + i
				tri(a, a + seg + 1, a + 1)
				tri(a + 1, a + seg + 1, a + seg + 2)

	func to_mesh() -> ArrayMesh:
		var arr := []
		arr.resize(Mesh.ARRAY_MAX)
		arr[Mesh.ARRAY_VERTEX] = v
		arr[Mesh.ARRAY_NORMAL] = n
		arr[Mesh.ARRAY_COLOR] = c
		arr[Mesh.ARRAY_TEX_UV] = u
		arr[Mesh.ARRAY_TANGENT] = tg
		arr[Mesh.ARRAY_INDEX] = idx
		var m := ArrayMesh.new()
		m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)
		return m

static func pine(rng: RandomNumberGenerator, H: float, detail: int, nz: FastNoiseLite) -> ArrayMesh:
	var mb := MB.new()
	var pts := []
	var radii := []
	var steps := 8
	for i in steps + 1:
		var k := float(i) / steps
		pts.append(Vector3(sin(k * 3.0 + rng.randf()) * 0.12 * k, H * k, cos(k * 2.0) * 0.1 * k))
		var r := lerpf(0.5, 0.07, pow(k, 0.8))
		if i == 0:
			r *= 1.7
		elif i == 1:
			r *= 1.2
		radii.append(r)
	mb.loft(pts, radii, 7 + detail * 2, Color(0.11, 0.08, 0.06), Color(0.07, 0.05, 0.04), nz, 0.25, Vector2(3.0, 0.2), true)
	var layers := 6 + detail * 2
	var teeth := 8 + detail * 3
	for l in layers:
		var k := float(l) / layers
		var y := H * 0.15 + k * H * 0.82
		var R := lerpf(3.7, 0.7, k) * rng.randf_range(0.9, 1.15)
		var hc := lerpf(3.0, 1.6, k)
		var apex := Vector3(0, y + hc, 0)
		var phase := rng.randf() * TAU
		var dark := rng.randf_range(0.8, 1.15)
		var ca := Color(0.03 * dark, 0.065 * dark, 0.04 * dark)
		var cb := Color(0.055 * dark, 0.105 * dark, 0.065 * dark)
		var ring := []
		for j in teeth * 2:
			var a := phase + TAU * j / (teeth * 2)
			var tip := (j % 2 == 0)
			var rr := R if tip else R * 0.55
			var yy := y - (0.55 if tip else 0.05)
			ring.append(Vector3(cos(a) * rr, yy, sin(a) * rr))
		var ia := mb.vert(apex, Vector3.UP, ca, Vector2(0.5, 0.0))
		var rid := []
		for j in ring.size():
			var p: Vector3 = ring[j]
			var nn := Vector3(p.x, 0.9, p.z).normalized()
			rid.append(mb.vert(p, nn, cb, Vector2(p.x * 0.35 + 0.5, p.z * 0.35 + 0.5)))
		for j in ring.size():
			mb.tri(ia, rid[j], rid[(j + 1) % ring.size()])
		if detail >= 1 and l < layers - 2:
			for b in 5:
				var a2 := rng.randf() * TAU
				var dirv := Vector3(cos(a2), 0, sin(a2))
				var L := R * 0.9
				mb.loft([Vector3(0, y, 0), dirv * L * 0.5 + Vector3(0, y - 0.1, 0), dirv * L + Vector3(0, y - 0.7, 0)], [0.07, 0.05, 0.015], 4, Color(0.09, 0.07, 0.05), Color(0.06, 0.05, 0.04), null, 0.0, Vector2(1, 0.3))
	return mb.to_mesh()

static func dead_tree(rng: RandomNumberGenerator, H: float, detail: int, nz: FastNoiseLite) -> ArrayMesh:
	var mb := MB.new()
	var pts := []
	var radii := []
	var steps := 10
	var lean := Vector2(rng.randf_range(-0.4, 0.4), rng.randf_range(-0.4, 0.4))
	for i in steps + 1:
		var k := float(i) / steps
		pts.append(Vector3(lean.x * k * k * 3.0 + sin(k * 7.0) * 0.15, H * k, lean.y * k * k * 3.0 + cos(k * 5.0) * 0.15))
		radii.append(lerpf(0.42, 0.05, pow(k, 0.7)) * (1.6 if i == 0 else 1.0))
	mb.loft(pts, radii, 6 + detail * 2, Color(0.2, 0.18, 0.15), Color(0.13, 0.11, 0.09), nz, 0.3, Vector2(3.0, 0.2), true)
	var nb := 6 + detail * 3
	for b in nb:
		var k := rng.randf_range(0.3, 0.95)
		var bp: Vector3 = pts[int(k * steps)]
		var a := rng.randf() * TAU
		var L := rng.randf_range(1.5, 3.4) * (1.2 - k * 0.5)
		var d := Vector3(cos(a), rng.randf_range(0.1, 0.7), sin(a)).normalized()
		var p1 := bp + d * L * 0.5 + Vector3(0, 0.2, 0)
		var p2 := bp + d * L + Vector3(0, rng.randf_range(-0.4, 0.8), 0)
		mb.loft([bp, p1, p2], [0.12, 0.08, 0.02], 4 + detail, Color(0.18, 0.16, 0.13), Color(0.12, 0.1, 0.08), null, 0.0, Vector2(1, 0.3))
		if detail >= 1:
			var d2 := Vector3(cos(a + 0.9), 0.5, sin(a + 0.9)).normalized()
			mb.loft([p1, p1 + d2 * L * 0.35, p1 + d2 * L * 0.6], [0.05, 0.035, 0.01], 3, Color(0.15, 0.13, 0.1), Color(0.1, 0.08, 0.07), null, 0.0, Vector2(1, 0.3))
	return mb.to_mesh()

static func rock(rng: RandomNumberGenerator, nz: FastNoiseLite, detail: int) -> ArrayMesh:
	var mb := MB.new()
	var g := rng.randf_range(0.7, 1.1)
	mb.sphere(Vector3.ZERO, Vector3(1.0, rng.randf_range(0.55, 0.85), rng.randf_range(0.8, 1.1)), Color(0.15 * g, 0.15 * g, 0.155 * g), 8 + detail * 3, 5 + detail * 2, nz, 0.4)
	for i in mb.v.size():
		var pv: Vector3 = mb.v[i]
		if pv.y < -0.05:
			pv.y *= 0.3
			mb.v[i] = pv
	return mb.to_mesh()

static func fallen_log(rng: RandomNumberGenerator, nz: FastNoiseLite, detail: int) -> ArrayMesh:
	var mb := MB.new()
	var pts := []
	var radii := []
	var L := rng.randf_range(5.0, 8.0)
	for i in 7:
		var k := float(i) / 6.0
		pts.append(Vector3((k - 0.5) * L, sin(k * 3.0) * 0.12, cos(k * 2.0) * 0.15))
		radii.append(lerpf(0.42, 0.28, k) * (1.15 if i == 0 or i == 6 else 1.0))
	mb.loft(pts, radii, 8 + detail * 2, Color(0.13, 0.1, 0.07), Color(0.1, 0.08, 0.06), nz, 0.25, Vector2(3.0, 0.25), true)
	for b in 3:
		var p: Vector3 = pts[rng.randi_range(1, 5)]
		var a := rng.randf_range(0.3, 2.8)
		mb.loft([p, p + Vector3(cos(a) * 0.5, 0.6, sin(a) * 0.5), p + Vector3(cos(a) * 1.1, 0.9, sin(a) * 1.1)], [0.1, 0.07, 0.02], 4, Color(0.12, 0.09, 0.07), Color(0.1, 0.08, 0.06), null, 0.0, Vector2(1, 0.3))
	return mb.to_mesh()

static func grass(rng: RandomNumberGenerator, blades: int, h: float, arch: float, col_a: Color, col_b: Color, w: float) -> ArrayMesh:
	var mb := MB.new()
	for b in blades:
		var a := rng.randf() * TAU
		var off := Vector3(rng.randf_range(-0.2, 0.2), 0, rng.randf_range(-0.2, 0.2))
		var hh := h * rng.randf_range(0.6, 1.2)
		var d := Vector3(cos(a), 0, sin(a))
		var p0 := off
		var p1 := off + d * arch * 0.2 + Vector3(0, hh * 0.45, 0)
		var p2 := off + d * arch * 0.6 + Vector3(0, hh * 0.85, 0)
		var p3 := off + d * arch + Vector3(0, hh * 0.9, 0)
		var g := rng.randf_range(0.8, 1.2)
		mb.loft([p0, p1, p2, p3], [w, w * 0.85, w * 0.5, 0.0], 3, Color(col_a.r * g, col_a.g * g, col_a.b * g), Color(col_b.r * g, col_b.g * g, col_b.b * g), null, 0.0, Vector2(1, 0.5))
	return mb.to_mesh()
